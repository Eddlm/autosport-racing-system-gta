# ARS Refactor Audit (deepseek)

Scope: `Racer.cs`, `AutosportRacingSystem.cs`, `DataStructures.cs`. Read end to end; nothing behavior-changing is proposed in Goals 1–3 — every item below is either safe-to-delete dead code, a pure rename, or comment stripping.

---

## GOAL 1 — Simplify (behavior-preserving)

### 1.1 Dead-by-constant / disabled blocks (delete wholesale)
| Location | What it is |
|---|---|
| `Racer.cs:743–764` | `#if false` “Steer-angle speed limiter — disabled. Kept for reference.” |
| `Racer.cs:766–781` | `if (Brain.Corner.Valid && 1==2)` “Extra limiter for cars pointing outward in a corner”. |
| `Racer.cs:784–798` | “Risk factor for grip … NOT active.” block — computes `speedAdjust` then discards it. |
| `Racer.cs:867–887` | `if (RacePosition > ARS.catchupPos && 1 == 0)` catchup force block, disabled. |
| `Racer.cs:1372` | `if (1 == 1 || !Brain.Corner.Valid || Brain.Corner.sToEntrance > 4)` — the `1==1` makes the test tautological; simplify to `true`. |
| `ARS.cs:5528–5541` | `if (1 == 1)` wrapper around an `if (1==2 && new Model(m).IsValid)` branch — the live `else` is the only reachable path; delete the dead branch. |
| `ARS.cs:5963` (`arsbuildcarlist` cheat path) and `ARS.cs:1570, 1616` | `|| 1 == 1` “radar enabled” fallback comment — either keep the native or delete; the always-true short-circuit hides intent. |
| `ARS.cs:1638–1644` | `if (1==2 && CanWeUse(playerVeh)…)` KnownVehicleModels auto-add — never fires. |
| `ARS.cs:2560–2602` | `if (SettingsFile.GetValue<bool>("GENERAL_SETTINGS","Ghosts",false) && 1 == 2)` ghosting block (already flagged in project memory as removed). |
| `ARS.cs:3805–3831` | `if (hash == Game.GenerateHash("prop_mp_repair_01") && 1 == 2)` garage/repair block — never runs. |
| `ARS.cs:6028` | `//keywords.AddRange(nameAutotag.Split(' '));` commented line inside live code — drop. |
| `ARS.cs:2071–2072`, `ARS.cs:2083–2084` | `if (1 == 1)` wrappers around instructional-button scaleform — collapse. |
| `ARS.cs:722`, `ARS.cs:750` | `else if (1 == 1)` inside `SetThrottle`/`SetBrakes` — just `else`. |
| `ARS.cs:2420–2419 (LoadAndRace)` | Entirely commented-out `LoadAndRace` method block (ARS.cs:2402–2419) — delete. |
| `ARS.cs:2788–2896` | Giant commented-out `for (int ph = 0; …)` prop-spawn loop inside `SpawnTrackLimits`. |
| `ARS.cs:2511–2530`, `ARS.cs:5195–5200`, `ARS.cs:5403–5417`, `ARS.cs:6266–6274` | Commented-out tuning/accel/neon/`Project` blocks. |
| `ARS.cs:1314–1327`, `ARS.cs:1392` | Commented-out experimental draw + `DrawMiniaturizedPath` call. |
| `ARS.cs:1156–1173` | Block comment inside `HandlePlayerDebugStuff` (`/* List<Vector3> roads = … */`). |
| `ARS.cs:844` | `// Removed: OpenRaceOptionsMenu() and OpenRaceOptionsMenu()...` — delete stale removal note (also a Goal-3 item). |

### 1.2 Unused enums / enum members
| Item | File |
|---|---|
| `OptionValues` enum (only `ShowAggression`) | `ARS.cs:44–47` — never referenced |
| `CameraTransition` enum | `ARS.cs:54–57` — never referenced |
| `Mistake` enum | `ARS.cs:29–32` — never referenced |
| `Decision` enum | `ARS.cs:25–28` — never referenced |
| `Racer.eLookAheads.SteerInRef` | `Racer.cs:44` — declared, never written or read |
| `BrakeStabilityStrat.Checking`, `BrakeStabilityStrat.Checked` | `DataStructures.cs:17` — only `.Invalid` ever appears |

### 1.3 Write-only / never-read fields (delete field + any setter)
| Field | Where | Evidence |
|---|---|---|
| `Racer.Traffic` | `Racer.cs:47` | assigned `new List<Vehicle>()` once, never read or written elsewhere |
| `Racer.MaxLeftLane`, `Racer.MaxRightLane` | `Racer.cs:49–50` | `= 0`, never touched |
| `Racer.LocalSpdLimiter` | `Racer.cs:51` | `= 0`, never touched |
| `Racer.SteerTarget` | `Racer.cs:48` | set in `SteerTrack`; only comment reads it (“Keep SteerTarget valid for debug drawing”). No draw path actually reads it. |
| `Racer.TorqueMult` | `Racer.cs:97` | reassigned every `ProcessTick` but never read |
| `Racer.DebugText`, `Racer.AddDebugText` | `Racer.cs:79`, `Racer.cs:1326` | list never enumerated; `AddDebugText` never called |
| `Racer.HeadingPID` | `Racer.cs:35` | created + `SetValue(0f)` once in `Launch`; `Update/SetTarget/IsClose` never called for this instance |
| `PID.SetTarget / ModifyTarget / IsClose / Update(float) / GetTarget / GetValue` | `ARS.cs:141–176` | none called outside PID itself |
| `Racer.CountersteerFullSeverityMult`, `Racer.CountersteerRecoveryRate`, `Racer._countersteerBlend` | `Racer.cs:109–111` | constants & field never read |
| `Racer.DistToInside` | `Racer.cs:552` | never called |
| `Racer.DistToOutside` | `Racer.cs:546` | only called from the `1==2` disabled block (1.1) — dies with it |
| `Racer.RiskFactorForGrip`, `Racer.RiskFactorForBrake` | `Racer.cs:1621–1628` | both `return 1f;` and never called |
| `Racer.UpdateFollowLaneTrail`, `DrawFollowLaneTrail`, `DrawRawFollowLaneTrail`, `GetFollowLaneTrailPoint`, `GetRawFollowLaneTrailPoint`, `FollowLaneTrail`, `RawFollowLaneTrail`, `LastFollowLaneTrailNode`, `TrailSample` (still used) | `Racer.cs:91–94, 1108–1181` | none of the listed methods are called; the two trail lists are only mutated by `UpdateFollowLaneTrail` (dead). Once `UpdateFollowLaneTrail` is deleted, the lists and the two `Get…TrailPoint` helpers are dead too. (Careful: `TrailSamples` / `DrawInputTrails` *are* live — keep those.) |
| `VehicleControl.SteerStabilityCorrection` | `DataStructures.cs:163` | only ever initialized, never read or written |
| `VehicleControl.SteerMax` | `DataStructures.cs:165` | same |
| `VehicleControl.FollowLane` | `DataStructures.cs:166` | same |
| `VehicleControl.ThrottleOffset` | `DataStructures.cs:171` | same |
| `VehicleControl.CurrentLockupLimiter` | `DataStructures.cs:174` | same |
| `VehicleControl.SteerManeuver` | `DataStructures.cs:164` | set to `0f` only in init of `SteerTranslateInput` (NaN guard) and never read for control |
| `VehData.Understeer` | `DataStructures.cs:38` | never read/written |
| `Memory.Data.CurveRadiusPhysicalGs` | `DataStructures.cs:81` | written in `UpdatePercievedGrip`, never read |
| `Memory.Data.FollowPoint` | `DataStructures.cs:80` | written in `UpdateFollowTrack`, never read |
| `Rival.AvoidStr` | `DataStructures.cs:110` | never read/written |
| `Rival.OvertakeLane` | `DataStructures.cs:109` | never read/written |
| `ARS.TracjectoryProjectionSeconds` | `ARS.cs:184` | `= 1`, never read |
| `ARS.FlareFX` is used; `ARS.FireRandCams`? — n/a. |
| `ARS.ExhaustOffsets` | `ARS.cs:1103` | never read or written |
| `ARS.DistToPercent` | `ARS.cs:3219` | never read or written |
| `ARS.NextInLine`/`GameTimeNextInLine` | `ARS.cs:1287–1288` | used in OnTick — keep; listed only to clarify *not* dead. |
| `ARS.Random` (`rnd`) | `ARS.cs:4825` | OK; note only — the per-Racer `Random Random` field is unused |
| `Racer.Random` | `Racer.cs:98` | never used (callers go through `ARS.GetRandomInt`) |
| `ARS.debugFrontend`, `ARS.racertext`, `ARS.floatingtext` | `ARS.cs:794–796` | `debugFrontend` only used by dead `DrawStats`; `racertext` referenced in `OnAbort`; `floatingtext` unused |
| `ARS.DrawStats` (both overloads) | `ARS.cs:4593–4638` | never called externally |
| `ARS.DrawDirectionalBoundingBox` | `ARS.cs:4434` | never called |
| `ARS.GenerateCubicBezier`, `ARS.Bezier3` | `ARS.cs:1875`, `ARS.cs:4705` | never called (only `Bezier2`/`QuadraticBezier` used) |
| `ARS.Lerp`, `ARS.LerpDelta`, `ARS.LerpByDistance` | `ARS.cs:768`, `ARS.cs:1239`, `ARS.cs:4751` | none referenced externally |
| `ARS.GetModelFlags`, `ARS.SetDefMultiplier`, `ARS.SetGearRatio` (private) | `ARS.cs:5101`, `ARS.cs:5123`, `ARS.cs:5132` | `GetModelFlags` not called; `SetDefMultiplier`, `SetGearRatio` not called |
| `ARS.OffsetByAngle` | `ARS.cs:4799` | never called |
| `ARS.IsBitSet`, `ARS.IsBetweenRange`, `ARS.IsRoadBusy`, `ARS.IsAhead`, `ARS.HasArrived` | `ARS.cs:3301`, `ARS.cs:6258`, `ARS.cs:4763`, `ARS.cs:4874`, `ARS.cs:4879` | none called |
| `ARS.GetXfromPosInDirection`, `ARS.Project` | `ARS.cs:4756`, `ARS.cs:6262` | none called |
| `ARS.WarnPlayer` | `ARS.cs:4955` | not called |
| `ARS.ToggleSPLVisibility` (no-arg) | `ARS.cs:1672` | not called; `SetSPLVisibility` is |
| `ARS.PlaceOnGround(Prop)` | `ARS.cs:2648` | empty body, never called |
| `ARS.AdjustMenuOption` | `ARS.cs:839` | empty body, only called from `HandleMenuAdjust` which already checks `OnAdjust == null` first — remove and drop the call site |
| `ARS.LaneSelectionApproachCorner` | `ARS.cs:4732` | `return 0f;` stub |
| `ARS.GetMoreShit` | `ARS.cs:4517` | never called; also vulgar |
| `ARS.GetWheelsPower`, `GetWheelInternalDownforceMod`, `GetWheelsAvgWheelspin`, `GetWheelsWetgrip`, `GetWheelSkidmark`, `GetWheelSlippage` | `ARS.cs:4491, 4505, 4567, 4542, 4579, 4640` | none referenced outside the file (search confirms) |
| `ARS.GetHillGsLossAtCurrentTrackPoint`, `ARS.GetHillGripMultiplierAtCurrentTrackPoint` | `ARS.cs:4302`, `ARS.cs:4354` | only the `…AtCurrentVelocityVector` variants are used |
| `ARS.GetSteerInput` | `ARS.cs:684` | never called externally |
| `ARS.GetColorFromRedYellowGreenGradient` | `ARS.cs:1985` | never called |
| `ARS.DrawBlackBars` | `ARS.cs:1188` | never called |
| `ARS.DrawMiniaturizedPath`, `ARS.MiniaturizedPath` | `ARS.cs:1195` | never called (only the dead comment invokes it) |
| `ARS.HandleImmersiveJoins` (call site commented out), `ImmersiveJoins` (kept by `FillKnownTracks`) | `ARS.cs:1250` | `OnTick` line 1304 only calls it inside a `//HandleImmersiveJoins();` comment. Decide: either re-enable or delete the method **and** `NeabyImmersiveJoins`/`secInteval` together |
| `ARS.HandlePlayerDebugStuff` | `ARS.cs:1104` | only call site is `//HandlePlayerDebugStuff(v);` (commented, ARS.cs:1303); the method itself is mostly commented-out body |
| `ARS.debugTrailer` + passenger-related comment block | `ARS.cs:1102–1143` | only mutated by the previous dead method |
| `ARS.AccelerationVector`, `lSpeed` (module-level `ARS` instance fields) | `ARS.cs:1282–1283` | unused duplicates of `VehData.AccelerationVector` / `Racer.LastSpeed` |
| `ARS.GsClamp`, `ARS.directionClamp` | `ARS.cs:1290–1291` | `= new Vector3(1,1,1)`, never read |
| `ARS.LoadDriver`/`CreateDriver` clothes/props serialization | `ARS.cs:5228–5363` | `LoadDriver` is called from `CreateDriverPed`; `CreateDriver` only via cheat `arssavedriver`. Keep if cheat is kept; otherwise both go. (Driver XML skills section writes dummy `"ExampleSkill"` — already dead weight either way.) |
| `ARS.LoadVehicle(string,Vector3)` | `ARS.cs:5364–5429` | not called |
| `ARS.GridSort` enum + `PlaceCars` switch | `ARS.cs:2420–2444` | `GridSort` is live (sorting runs), but the `foreach(GridSort g …)` loop body line 2432 `g.ToString()…Contains(...);` is a statement with no effect (missing assignment to a `bool`) — see appendix. The switch itself still runs because `sort = g` is set every iteration. After fixing the no-op, the loop simplifies to a single `Enum.TryParse`/lookup. |

### 1.4 Copy-paste → one helper
1. **Wheel-pointer readers** (`GetWheelsPower`, `GetWheelInternalDownforceMod`, `GetMoreShit`, `GetWheelsGrip`, `GetWheelsWetgrip`, `GetWheelSlippage`, `GetWheelSkidmark`, plus the avg/max variants) — all identical except for the offset constant and the per-element reduction. Collapse to:
   ```csharp
   static unsafe List<float> ReadWheelFloats(Vehicle v, ulong offset, int round = -1)
   static unsafe float ReadWheelFloatReduction(Vehicle v, ulong offset, Func<float,float,float> reduce)
   ```
   `GetWheelsMaxWheelspin` and `GetWheelsAvgWheelspin` then become `ReadWheelFloatReduction(..., Math.Max)` and `… .Sum / count`.
2. **Native-pattern scan + offset cache** in `SetSteerInput`, `SetSteerAngle`, `SetThrottle`, `SetBrakes` — all four share the same `\x74\x0A\xF3…` pattern, an offset arithmetic (`+6`, `+6+8`, `+6+0x10`, `+6+0x14`), and the same `else if (offset == 0x0) addr=FindPattern(...)` shape. Collapse to:
   ```csharp
   static unsafe void WriteVehicleFloat(Vehicle v, ref ulong offset, int offsetDelta, float value, string label)
   ```
3. **XML load-with-null-retry** (`GetTrackTags`, `GetTrackStartPos`, `GetRacerTags`) all open with the literally identical:
   ```csharp
   XmlDocument document = new XmlDocument();
   document.Load(path);
   int pat = 0;
   while (document == null && pat < 1000) { pat++; document.Load(path); }
   ```
   The `while (document == null)` can never run (`new XmlDocument()` never returns null). Delete the loop everywhere; optionally extract a single `LoadXmlOrThrow(path)`.
4. **`XmlElement info = …; X/Y/Z/Wide` block** appears in `SaveRoute` (≈3536–3593), `UpdateRoute` (≈3334–3381), and again as the read counterpart in `LoadTrack`. Extract one `WritePointElement(XmlNode parent, Vector3 pos, float wide)` and one `ReadPointElement(XmlElement) → (Vector3 pos, float wide)`.
5. **`DrawPath` and `DrawSection`** in `ARS.cs` (2941–3051 and 3054–3147) are near-identical loops — `oldpos`/`pos`/`w`/`oldw`/`rWidepos`/`lWidepos` calculation is byte-for-byte the same; they diverge only in the inner draw call. Extract `ComputePathEdge(nodes, widedict, ph, dd, …)` returning a struct, then both methods become 5-line wrappers.
6. **OnTick radar `|| 1==1` gate + leaderboard `|| 1==1` gate** (ARS.cs:1570, 1616) — same redundant fallback written twice; replace both with a single `bool ShouldDrawLeaderboard` property.
7. **`Path.Clear()`/`Angles.Clear()`/`WideDict.Clear()`** appears 2× in `CleanEverything` (lines 1080–1082 and again 1094–1096); `TrackLimits` props are iterated and deleted twice (1077 and 1092). Collapse to one pass.
8. **`foreach (Racer r in Racers)` reset loops** appear several times (e.g. `Launch` in countdown at ARS.cs:1453 and 1473). Not strictly duplicate, but the menu `OpenMenuFromContext` / `EnsureMenuItemDefinitions` pair spawns similar Option-key lookups; only one place actually mutates `OptionsList`. Out of scope for “no behavior change” beyond dead code.

### 1.5 Redundant logic (delete)
- `Racer.SpeedTrack` has `if (float.IsNaN(cornerSpd) || IsInfinity)` then `if (cornerSpd <= 5)` recomputes — fine, but the second branch silently overwrites a `cornerSpd` of 4 with the recompute; that branch is reachable and changes behavior, so leave it. Mark for the bug appendix instead.
- `ARS.NumericUpDown`-style `foreach (GridSort g …)` no-op (see appendix).
- `ARS.DrawText(Vector3, ...)` and the second `DrawText(Vector2, ...)` share the `Hash._SET_TEXT_ENTRY`/`_ADD_TEXT_COMPONENT_STRING` prologue; minor.
- `Rival.Update` recomputes `BoundingBoxTotal.Y` from `Model.GetDimensions().Y` every tick for the same pair of models — cache on first call per Rival or move to `Racer.Initialize`. (Behavior-preserving if前提 frequency preserved.)
- `Memory` constructor hard-codes `Rivals.Add(new Rival()); Rivals.Add(new Rival()); Rivals.Add(new Rival())` — replace with a list initializer or `Enumerable.Repeat`. No observable change.
- `ARS.PlaceCars` line 2432: `g.ToString().ToLowerInvariant().Contains(...)` is an expression statement (returns bool, result discarded). Pure no-op; deleting the whole loop iteration and using a direct `Enum.TryParse` is behavior-equivalent given the `sort = g` assignment below already sets `sort` to the *last* enum value regardless. Item flagged in bug appendix too.

---

## GOAL 2 — Rename inventory (per file)

Convention applied: public types/methods/properties = PascalCase; private fields = `_camelCase`; static readonly = PascalCase; enums = PascalCase (no `e` prefix, no plural for non-flags).

### `DataStructures.cs`
| Current | Proposed | Reason |
|---|---|---|
| `Memory` (class) | `RacerBrain` | vague (“Memory”); the file comment even says “The AI brain” |
| `Memory.data` | `Brain.Perception` | lowercase field violates C# convention; name conveys role |
| `Memory.intention` | `Brain.Target` | lowercase; “intention” is awkward |
| `Memory.Intention.IntendedSpdChangeGs` | `TargetLongitudinalGs` | abbreviation `Spd`, inconsistent casing |
| `Memory.Intention.MaxSpeed` | keep | — |
| `Memory.Intention.Speed` → keep |
| `Memory.Intention.Direction` → keep |
| `BrakeStabilityStrat` | delete (per 1.2) — remaining users become `bool` flags |
| `Rival.relativePos` | `RelativePosition` | lowercase field |
| `Rival.rPos` | `RelativeOffset` | cryptic abbreviation |
| `Rival.sToReach` | `SecondsToReach` | `s` prefix ambiguous (seconds? seconds-along-path?) |
| `Rival.sToRear` | `SecondsToRear` | same |
| `Rival.BoundingBoxTotal` | `CombinedDimension` | vague; “total” of what |
| `Rival.OccupiedLane` | keep |
| `Rival.OccupiedLaneWidth` | keep |
| `Rival.AvoidStr` | delete (dead) |
| `Rival.OvertakeLane` | delete (dead) |
| `VehicleControl.SteerTrackDegrees` | keep |
| `VehicleControl.SteerStabilityCorrection / .SteerMax / .FollowLane / .ThrottleOffset / .CurrentLockupLimiter / .SteerManeuver` | delete (dead, 1.3) |
| `VehData` field `Gs` | `AccelerationGs` | collides with English-vs-acronym; computed prop `LongitudinalGs` already lives in same class |
| `VehData.Understeer` | delete |
| `Memory.Data.CurveRadiusPhysicalGs`, `…FollowPoint` | delete (dead) |
| `CornerPoint.LenghtEnd` | `LengthEnd` | typo |
| `CornerPoint.LengthStart` | keep |
| `CornerPoint.OG` (in `Corner`) | `CornerDef` or `Definition` | two-letter name |
| `Corner.sToEntrance` | `SecondsToEntrance` | same `s` prefix |
| `Corner.stabilityStrat` | delete with `BrakeStabilityStrat` (or `BrakeStabilityState`) |
| `Approach.CheckedForImpediment`, `HoldDeviation` | delete (no readers) — or rename `Approach` to `CornerApproachState` and keep if reintroduced |
| `AIData.SpeedToInput` | keep but consider `AIData.ComputeThrottleFromSpeed` | vague wrapper |
| `HandlingData.TRlateral` | `LateralTractionCurve` | matches GTA-handling semantics; the `TR` is unreadable in callers |
| `HandlingData.Power` | `Acceleration` | `Power` collides with memory of `EnginePowerMultiplier`; current meaning is `GET_VEHICLE_ACCELERATION` |
| `TrackPoint` `Node/Position/Angle/Direction/GeneralCurveRadius/PreciseCurveRadius/Elevation/TrackWide` | all keep |

### `Racer.cs`
| Current | Proposed | Reason |
|---|---|---|
| `eLookAheads` (enum, with `e` prefix) | `LookAhead` (singular — each value picks one point) | non-PascalCase enum name; `e` Hungarian prefix |
| `RacerBaseBehavior` | keep |
| `CornerPhase` | keep |
| `Racer.SteerTarget` | delete (write-only) |
| `Racer.MaxLeftLane`/`MaxRightLane`, `LocalSpdLimiter`, `Traffic` | delete (dead) |
| `Racer.TorqueMult`, `Random` | delete (dead) |
| `Racer.DebugText`, `AddDebugText` | delete |
| `Racer.HeadingPID` | delete (HeadingPID never invoked) |
| `Racer._countersteerBlend`, `CountersteerFullSeverityMult`, `CountersteerRecoveryRate` | delete (dead) |
| `Racer.TractionControl` | keep |
| `Racer.SteerTrack()` | `ComputeSteering()` | `SteerTrack` reads as a noun/verb-mash |
| `Racer.SpeedTrack()` | `ComputeTargetSpeed()` | same |
| `Racer.SpeedToThrottleBrake()` | `ConvertSpeedToPedals()` | vague direction |
| `Racer.SteerTranslateInput()` | `TranslateSteeringToControl()` | vague |
| `Racer.SteerApplyCorrections()` | `ApplySpeedBasedSteerLimit()` | describes what it does |
| `Racer.ClampTargetLaneForAvoidance()` | `ApplyRivalWalls()` | the method both maintains walls and clamps |
| `Racer.ComputeCornerTargetLane()` | keep |
| `Racer.TryGetSteerContext()` (nested) | keep |
| `Racer.UpdatePercievedGrip()` | `UpdatePerceivedGrip()` | typo |
| `Racer.UpdateDynamicBoundingBox()` | keep |
| `Racer.UpdateCornerInfo()` | keep |
| `Racer.UpdatePassengerize()` | keep |
| `Racer.UpdateRivalInfo()` / `UpdateRivals()` | keep |
| `Racer.UpdateFollowTrack()` | keep |
| `Racer.UpdateTickData()` / `RunTimedCore()` / `ProcessTick()` / `ProcessAI()` / `ProcessTimedAI()` | keep |
| `Racer.OutOfTrackDistance()` | keep |
| `Racer.Launch()` / `Initialize()` / `Delete()` | keep |
| `Racer.DistToOutside`, `DistToInside` | delete (dead after removing 1.1 disabled blocks) |
| `Racer.RiskFactorForGrip`, `RiskFactorForBrake` | delete (dead) |
| `Racer.UpdateFollowLaneTrail` etc. | delete (dead) |
| `Racer.HalfSecondTick` / `OneSecondTick` / `LastCoreTick` / `TimeSinceLastCoreTick` | keep |
| `Racer.StuckCheckTimeMs` / `StuckRecoveryTimeMs` / `StuckRecoveryAttemptsNow` / `IsRecoveringFromStuckNow` | keep |
| private fields `_cornerPhase`, `_avoidLiftOff`, `_avoidLeftWall`, `_avoidRightWall`, `_isPassengerized` | keep — and migrate the legacy PascalCase private fields (`HalfSecondTick`, `TorqueMult`, `Random`, `HeadingPID`, `LastSpeed`, `TrailSamples`, `FollowLaneTrail`, `RawFollowLaneTrail`, `LastFollowLaneTrailNode`, `TorqueMult`) to the same `_camelCase` convention. This is the main convention drift across the file. |
| `Racer.HalfSecondTick` / `OneSecondTick` | (after migration) `_halfSecondTick`, `_oneSecondTick` |
| `Racer.LastCoreTick` | `_lastCoreTick` |
| `LastSpeed` | delete (dead, see Goal 1) |

### `AutosportRacingSystem.cs`
| Current | Proposed | Reason |
|---|---|---|
| `ARS.TracjectoryProjectionSeconds` | delete (dead) — otherwise `TrajectoryProjectionSeconds` (typo) |
| `RelativePos` enum | `RelativePosition` | abbreviation |
| `RaceState.NotInitiated` | keep (or `PreGrid`) — “NotInitiated” is a double-negative |
| `Options.ShowAggro` | `Options.ShowAggression` (then `OptionValues` enum deleted) |
| `DebugDisplay` | keep |
| `CameraTransition` | delete (dead) |
| `PID` class methods `Update()` / `Update(float externalD)` / `SetTarget` / `SetValue` / `GetValue` / `GetTarget` / `ModifyTarget` / `IsClose` | trim to `Update(float externalD = 0f)`, `SetValue`, `SetTarget`, `IsClose`; delete the rest after confirming HeadingPID is dead |
| `ARS.map()` | `Remap()` | the built-in LINQ `.Select` is conventionally called `map` in functional code, so `map` collides conceptually; `Remap` is unambiguous |
| `ARS.mapGamma()` | `RemapGamma()` | same |
| `ARS.rad2deg()` / `deg2rad()` | `RadToDeg()` / `DegToRad()` | digit-in-name anti-pattern |
| `ARS.Clamp()` | keep (matches `Math.Clamp` shape) |
| `ARS.GetDownforceGsAtSpeed()` | keep |
| `ARS.GetTRCurveLat()` / `GetTRCurveMax()` | `GetLateralTractionCurve()` / `GetMaxTractionCurve()` | matches `HandlingData.LateralTractionCurve` rename |
| `ARS.GetSteerLock()` | keep |
| `ARS.GetWheelsPtr/GetNumWheels/GetWheelPtrs` | keep; or collapse to `WheelMemory` nested class |
| `ARS.GetMoreShit()` | delete (dead + vulgar) |
| `ARS.GetWheelSkidmark`, `GetWheelSlippage`, `GetWheelInternalDownforceMod`, `GetWheelsPower`, `GetWheelsAvgWheelspin`, `GetWheelsWetgrip` | delete (dead) |
| `ARS.GetWheelsMaxWheelspin`, `GetWheelsGrip` | keep, but back onto the collapse helper (1.4) |
| `ARS.SetThrottle` / `SetBrakes` / `SetSteerInput` / `SetSteerAngle` | keep; consolidate impl (1.4) |
| `ARS.FindPattern` | keep |
| `ARS.SetloadingPromptText()` | `SetLoadingPromptText()` | typo in casing |
| `ARS.SetSPLVisibility` / `ToggleSPLVisibility` | keep `SetSPLVisibility` only |
| `ARS.FillKnownTracks` / `FillKnownDisciplines` / `ReFilterKnownTracks` / `FillCachedCandidates` | keep |
| `ARS.GetTrackTags` / `GetTrackStartPos` / `GetRacerTags` / `GetRacerModel` | keep |
| `ARS.ParsedEnum` | keep |
| `ARS.OptionValuesList` (Dictionary<Options,bool>) | keep |
| `ARS.Cheats()` | `HandleCheats()` | reads as noun |
| `ARS.CleanEverything` / `CleanRacers` | keep |
| private field `intendedOpponents` | `IntendedOpponents` (or migrate to `_intendedOpponents` consistent with new code) | camelCase drift on a non-static field |
| private field `routeEditMode` | `_routeEditorActive` (bool) | camelCase + awkward `mode` suffix |
| private field `listenmode` | `_listenMode` | one-word camelCase |
| private field `debugTrailer` | `_debugTrailer` (or delete with `HandlePlayerDebugStuff`) |
| field `rBezier`, `scale`, `wide`, `PathDisplayFidelity`, `RouteSection` | `_startBezier`, `_bezierScale`, `_pathWidth`, `_pathDisplayFidelity`, `_routeSection` |
| `IsDroneMode` (private) | `_droneMode` |
| `TimeToFinishRace`, `TimeScale`, `IdealTimeScale`, `GameTimeRef`, `GametimerefLong`, `GameTimeShort`, `GametimeCountDown`, `CountDown`, `MaxCountDown` | `RaceTimedFinishMs`, `_timeScale`, `_idealTimeScale`, `_posUpdateTickMs`, `_longTickMs`, `_shortTickMs`, `_countdownTickMs`, `_countdown`, `MaxCountdown` | inconsistent casing (mixed `GametimerefLong`, `GametimeCountDown`); the names also mush game-time-ms and countdown-state |
| `ARS.StartCoundown()` | `StartCountdown()` | typo |
| `ARS.OnAbort(object sourc, EventArgs e)` | `OnAbort(object sender, EventArgs e)` | typo |
| local `menOffexts` | `memOffsets` | typo |
| `ARS.FreeCam…` series: `FreecCamRide` | `FreeCamRide` | double `c` typo |
| `secInteval` | `_secInterval` | typo + camelCase drift |
| `NeabyImmersiveJoins` | `_nearbyImmersiveJoins` | typo + casing |
| `Scaleform` static fields `scaleform`, `racertext`, `debugFrontend`, `floatingtext`, `SCCountdown` | `_instructionalButtons`, delete, delete, delete, `_countdownScaleform` (only `scaleform`/`SCCountdown` actually used) | lowercase static fields |
| `ARS.GetHillGsLossAtCurrentVelocityVector` / `GetHillGripMultiplierAtCurrentVelocityVector` | `GetHillGsLossFromVelocity` / `GetHillGripMultiplierFromVelocity` | verbose; drop the `AtCurrent…Vector` tail |
| `ARS.GripGainLossElChange` | `GripDeltaFromElevationChange` | `ElChange` is not parseable |
| `ARS.GetDirectionalBoundingBox()` | keep |
| `ARS.MapIdealSpeedForDistance()` | keep |
| `ARS.GetSpeedForCorner()` | keep |
| `ARS.LaneSelectionApproachCorner()` | delete (returns 0) |
| `ARS.LoadDriver` | `LoadDriverXml` | clarify returns XmlDocument |
| `ARS.CreateDriver` (serializes to Driver xml) | keep |
| `ARS.CreateVehicle(Vehicle, bool auto)` vs `CreateVehicleFromHash` | keep; differing second arg `auto` is fine |
| `ARS.CachedCandidates`, `RacerTags`, `TrackTags` | keep; `RacerTags`/`TrackTags` are private-instance fields holding string dicts; rename `RacerTags` → `_racerTagLookup`, `TrackTags` → `_trackTags`? Lower-cost to leave private. |
| `ARS.GetColorFromRedYellowGreenGradient` | delete (dead) |
| `ARS.World3DToScreen2d` | `World3DToScreen2D` | casing |
| `ARS.menuOffexts` → `memOffsets` (already noted) |
| `LoadScriptTask`/`IsLoadingScript`/`Loaded` | keep |
| `_droneMode` etc. enforce `_camelCase` for all instance members going forward; the prior code mixes `Loaded`/`IsDroneMode` (PascalCase, no underscore) with `routeEditMode`/`listenmode` (camelCase, no underscore). Standardizing on `_camelCase` removes the drift. |

(Enumerating every local `int c`, `int i`, `int r`, `string dir`, `float hAboveGround` etc. is out of scope; only fields/methods/types above are listed, per the instruction.)

---

## GOAL 3 — Remove all comments

### Categories present (with concrete instances)
1. **Empty `<summary>` blocks** (no body text) — `Racer.cs:543–545` (`DistToOutside`), `Racer.cs:662–664` (`SteerTranslateInput`), `Racer.cs:1221–1223` (`OutOfTrackDistance`), `Racer.cs:368–372` has text but the `<returns>` is empty, `ARS.cs:4780–4781` (`MapIdealSpeedForDistance` has body, fine), `DataStructures.cs:24–25` (`YawRotationPerSecondDegrees`), `DataStructures.cs:28–31` (`BaseMechanicalGrip`). Strip the empty tags; if a method genuinely needs a summary, keep one concise sentence, otherwise drop.
2. **Stale “removed X / kept for …” notes** — `ARS.cs:844` (`// Removed: OpenRaceOptionsMenu() and OpenRaceSetupMenu() — no longer needed.`), `ARS.cs:965` (`// Create Track — kept for cheat code access, not in any menu`), `Racer.cs:744` (`// Steer-angle speed limiter — disabled. Kept for reference.`).
3. **Section banners** (single-line region labels inline in the body) — pervasive:
   - `Racer.cs`: `// Identity and runtime references.` (23), `// Core controller/memory.` (32), `// Vehicle dynamics/perception state.` (37), `// Navigation and lane-following state.` (43), `// Race lifecycle and position.` (53), `// Timers/ticks.` (61), `// Stuck/recovery state.` (67), `// Debug and draw caches.` (78), `// Misc tuning/runtime helpers.` (96), `// Route curvature window …` (100), `// Corner racing line state.` (104), `// Countersteer state (GodotRace-style).` (108), `// Avoidance state.` (113), `// Passengerize state …` (118), `// Personality: 0-100 …` (122), `// ── Local helpers ───` (344).
   - `ARS.cs`: `//offsets` (228), `//Terrain hashes` (236), `//AI racers, and the player if they participate` (247), `//Route info` (252), `//Freecam` (217), `//Menu` (810), `//Immersive joins` (1246), `/// TOOLS ///` (4890), `//Priority, anticrash checks` (1331), `//Drawing and GUI stuff` (1343), `//Scaleforms` (1349), `//Info & Tips` (1352), `//Timescale control` (1369), `//Create the menu on key inputs` (1405), `//Handle the countdown` (1427), `//While the countdown is on, you can enter the opponents’ vehicles` (1442), `//Where the magic happens.` (1499), `//Handle the racing positions` (1515), `//Configure the leaderboard and handle lapping logic` (1546), `//Draw the leaderboard positions` (1615), `//Visuals` (1685 — `//If cool, the track is closed…` is an explanatory banner mixing with comment), `//Already started` (1731), `//Placing the Start Line` (1782), `//Add section` (1773), `//Section rendering` (1793), `//Reference marker` (1798), `//Controls` (1738, 1906-block, etc), `//Never really used` (1392), `//Catchup` (864), `//Slow checks` (1346), `//Rocket boost` (1371). All deletable.
4. **`// Constructor`** and obvious restatements — `ARS.cs:71` (`// Constructor` above PID ctor), `ARS.cs:140` (`// Set target value with clamping`), `ARS.cs:146` (`// Set current value and reset velocity and integral`), `ARS.cs:154` (`// Get current value`), `ARS.cs:160` (`// Get target value`), `ARS.cs:166` (`// Modify target value with clamping`), `ARS.cs:172` (`// Check if close to target within threshold`), `ARS.cs:90` (`// Update method - advances the controller by dt seconds`), `ARS.cs:140–176` entire PID block — the method names are sufficient.
5. **Disabled-feature notes** — `Racer.cs:596` (`//Limit the th the input to the car’s top speed…`), `Racer.cs:588` (`//Keep still with throttle up when waiting for the launch`), `Racer.cs:784–785` (`// Risk factor for grip … NOT active.`), `Racer.cs:744` (`// Steer-angle speed limiter — disabled. Kept for reference.`), `ARS.cs:1394` (`//Prevents the world from generating population. The AI cannot handle traffic yet`), `ARS.cs:1392` (`//Never really used / //if (Path.Count > 20 && MiniMap…)`).
6. **Inline math narration** inside `SteerTrack` (`Racer.cs:258–340`): `// 1) Heading error …`, `// 2) Compute target lane …`, `// 3) Rival avoidance …`, `// 4) Off-track recovery …`, `// 5) Convert target lane …`, `// 6) Total heading target …`, `// 7) GodotRace-style PD …`, `// 8) Slide countersteer …`, plus the per-step one-liners (`// Scale down the heading error so steering response is gentler.`, `// Only acts if the natural lane falls inside the zone.`, `// Single bias from the clamped lane (respects walls).`, `// Keep SteerTarget valid for debug drawing.`). Also `SpeedTrack` (`Racer.cs:712–715`, `730–731`, `732–733`), `UpdatePercievedGrip` (`//Base vehicle grip GetVehicleMaxTraction`, `//Hill grip calc uses the same route window.`), `UpdateRivals`/`UpdateFollowTrack` (`//Get our current track point data`, `//Lap counting`, `// Local curvature from a configurable speed-based window (raw speed, not grip-scaled).`), `ComputeCornerTargetLane` (`// Corner direction: SignedAngle(pre, fut, up) …`, `// For a right turn …`, `// 2s→1s before apex: lerp from outside to inside.`, etc.), `ClampTargetLaneForAvoidance` (`// Aggression-scaled buffer: 0 aggro = 2m gap, 100 aggro = 0.25m gap.`, `// Each side independently: snap when constrained, decay to track edge when clear.`, `// Check if there’s room for our car.`, `// Clamp target lane so our car’s edge (not center) stays at the wall.`), `UpdateStuckCheck` (`//Force reverse with centered steering during the whole recovery window.`), `ProcessTick` (`//Catchup`), `SpeedToThrottleBrake` (`// If the car is still rolling backward, stop it first before applying forward throttle.`, `// Transition to reverse: brake while moving forward …`).
7. **Inline conversion/`radians` narration** — `Racer.cs:791–793` (`// Simple approximation (angle must be in RADIANS)`, `// Convert to degrees/sec`), `ARS.cs:4813` (`// Quaternion.RotationAxis takes radian angles`), `ARS.cs:102` (`// advances the controller by dt seconds`).
8. **Terrain-hash notes** — `ARS.cs:237–241` (`//Road`, `//Dirt`, `//Sand`, `//-1286696947<grass`, `//-461750719`), `ARS.cs:285` (`MoreTarmac //Concrete`), `ARS.cs:2745–2747` (`// RaycastResult terrainRaycast = …`, `//int _GET_SHAPE_TEST_RESULT_EX …`).
9. **`//load collision`** native-call asides — `Racer.cs:194` (`//load collision`), `ARS.cs:1400` (`//Actively forces deletion of anything unwanted`).
10. **`//For catchup stuff only` / `//radar enabled` / `//List of nodes that conform the race path.` / `//Grip multiplier on each node …` / `//How wide (meters) each node is.` / `//Generic per-trackpoint float storage.` / `//Trackside props, placed automatically.` / `//Cache for any per-trackpoint float`/etc.** — `ARS.cs:249`, `253–257`, `261`.
11. **Filled-but-redundant summaries with `<summary>`** where the description just repeats the method name — e.g. `Racer.cs:1332` (“// Processes AI logic that works on slow (500ms - 2000ms) cycles.” is fine, keep one sentence; but `Racer.cs:1387` “// Runs Speeding and Steering logic.” is a name restatement), `Racer.cs:849` (“// Gathers and runs tick-sensitive stuff”), `Racer.cs:12234` etc.
12. **Big block-commented-out code regions** — listed in 1.1 (LoadAndRace, SpawnTrackLimits inner loop, acc-tune loop, neon lights, Project body). Remove along with the dead code.
13. **`// blip creation failed, non-critical`** in a catch — `Racer.cs:191`. Replace with no comment (the empty catch is intentional).
14. **`//Scaleforms` // `//Info & Tips`** banner pair ARS.cs:1349/1352.
15. **`//Throttle side:` / `//Brake side:`** asides in `DrawInputTrails` (`Racer.cs:1206, 1211`).
16. **`//Center of Gs` / `//Gs`** draw labels in `DrawStuff` (`Racer.cs:1005, 1008`).
17. **`//Start chevron / Middle (apex) chevron / End chevron`** — `Racer.cs:1079–1083`, repeated for player 1100–1102.
18. **`//Draw avoidance walls on the ground, relative to track center.` / `//Debug: show wall values and lane info.`** — `Racer.cs:1045, 1054`.
19. **`// Extra limiter for cars pointing outward in a corner.`** —Racer.cs:765.
20. **`//` above blank lines** scattered (`Racer.cs:638` blank with `// `, `Racer.cs:671`, `Racer.cs:670`, etc.)

### Exception to keep
Zero. Every comment found falls into a category above and either dies with dead code in Goal-1, becomes redundant after the Goal-2 renames (a `Stb` banner saying what `ApplyRivalWalls()` already says), or was narrating math/intent that the renamed methods now convey. The one candidate I considered — the **املة Flares XML schema string** in `SaveRoute` (`ARS.cs:3499`, the `c.InnerText` content body) — is not a code comment; it is data stored into the output XML. It survives Goal 3 untouched.

If the team insists on a single exception for posterity, the strongest candidate is `ARS.cs:4780–4782` block above `MapIdealSpeedForDistance`, recording the kinematic braking equation `v₀ = √(vTarget² + 2·decel·distance)` — but that equation already belongs in the method name (`ComputeBrakingSpeedFromDistance`) or a constant, so even that is removable.

---

## Appendix — Bugs spotted during the audit (NOT part of Goals 1–3, listed separately)

1. **`ARS.PlaceCars` GridSort loop is a no-op expression statement.** `ARS.cs:2432`:
   ```csharp
   g.ToString().ToLowerInvariant().Contains(DevSettingsFile.GetValue<string>("RACERS","GridSorting","Power").ToLowerInvariant());
   ```
   This returns a bool, never assigned, never used. The next line `sort = g;` therefore runs for *every* `GridSort` value, leaving `sort` equal to the last enum member (`Random`). The intended `if (.Contains(…)) { sort = g; break; }` is missing. **Behavioral bug**, do not silently fix in Goal 1.
2. **Memory vs code drift in corner braking distance.** Project notes say `Distance = corner node - 30m safety`; `MapIdealSpeedForDistance` uses `c.Node - c.LengthStart) - r.CurrentTrackPoint.Node - 10f` (ARS.cs:4786) — 10 m, not 30 m. Either the memory note is stale or the code under-brakes by 20 m.
3. **`Rival.Update` recomputes `BoundingBoxTotal.Y` from `Model.GetDimensions().Y / 2` every tick** even though the model pair never changes — perf concern, not a bug, but cheap to cache.
4. **`Bezier2(Start, End, t)` (ARS.cs:4721)** uses `Vector3.Zero` as the middle control point of a quadratic Bezier. For world-space `Start`/`End` vectors that are far from origin this is geometrically a Bezier *through the world origin*, not a smooth blend between Start and End. `GenerateBezier` works in practice because it adds `middlePoint +` to the result, but the math is misleading and brittle.
5. **`CleanEverything` clears/deletes `Path`, `WideDict`, `TrackLimits` twice.** Behavior-neutral (idempotent) but sloppy — it can throw `InvalidOperationException` if iterating `TrackLimits` while deleting inside the same foreach (the two `foreach (Prop p in TrackLimits) if (CanWeUse(p)) p.Delete();` calls are at `ARS.cs:1077` and `1092` — second is safe, but it indicates copy-paste).
6. **`VehicleData.Gs` computed with a stray `/ 2`.** `Racer.cs:1574`: `AccelerationVector.Aggregate(...) / Count / 2`. The `/ 2` is unexplained; produces a “Gs” value that is half of the rolling average acceleration. Consistent with the display math elsewhere? Possibly intentional (averaging rather than accumulating) but undocumented.
7. **`ARS.GetWheelsGrip(Car).Average()`** (Racer.cs:1541) throws on a car with no wheels resolved (empty list). No defensive count check before `.Average()`.
8. **`Racer.SpeedTrack` recomputes corner speed at `cornerSpd <= 5`:** the `if (cornerSpd <= 5) cornerSpd = ARS.GetSpeedForCorner(…)` branch silently overrides the result of `MapIdealSpeedForDistance` when the planned speed is ≤5 m/s. At a very tight corner this re-evaluates with grip usage 1.0 (no margin) — could produce a higher target than the kinematic braking plan intended.
9. **`OnTick` `GametimerefLong` block (ARS.cs:1638–1644)** is gated by `1==2`, but the help-message drain lives in the same 3-second tick. If the dead block were ever re-enabled the `KnownVehicleModels.Add` path calls `CreateVehicle(playerVeh, true)` — which writes a new XML on every trim change. Latent footgun.
10. **`UpdateFollowTrack` building `points`** (`Racer.cs:1244–1248`): the `for (int i = refTrackpoint - 6; points.Count <= 12; i++)` uses `<= 12`, so it runs until `points.Count == 13`, and the wrap `if (i < 0 || i >= TrackPoints.Count) i = 0;` resets `i` to 0 *after* the increment — meaning on tiny tracks (<13 nodes) this loop will jam `points` with duplicates of node 0 forever? Actually the `if (i < 0 || i >= TrackPoints.Count) i = 0;` does reset, and `points.Add(TrackPoints[i])` keeps adding, so it terminates at 13 entries — but `OrderBy(t => t.Position.DistanceTo(Car.Position)).First()` later selects the closest, which on a tiny wrap-around track may return a far-side node. Not catastrophic; flag for review.
11. **`LookForCornerAhead` uses `Skip(refNode).Take(spd*5)`** (`ARS.cs:4741`): `Skip` walks the list from index 0, performing O(n) work on every 500 ms tick. Cheap relative to the rest, but the semantics are wrong when `refNode` exceeds the collection — `Skip` beyond the end yields empty, so corner scanning silently no-ops at the end of a point-to-point route. Use `CornerPoints.Count` clamp or wraparound.
12. **`SpeedToThrottleBrake` `Brain.intention.IntendedSpdChangeGs = 999`** during the first 3 s (`Racer.cs:603`) — magic number, not a bug, but re-expose as `MaxIntendedGs`.
13. **`AdjustMenuOption`** is an empty stub (`ARS.cs:839–842`) yet `HandleMenuAdjust` calls it as the fallback when `OnAdjust` is null. After removing the dead stub, the empty default is preserved (the call just does nothing). Behavior-preserving.