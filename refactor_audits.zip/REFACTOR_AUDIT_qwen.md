# ARS Refactoring Audit

Scope: `Racer.cs`, `AutosportRacingSystem.cs` (ARS), `DataStructures.cs` (DS).
This audit has exactly three sections, matching the three refactor goals. A short bug appendix follows at the end.

---

## GOAL 1 — Simplify the code, keeping the behavior

Everything listed here, if removed, leaves the observable runtime behavior unchanged. Grouped by kind.

### 1.1 Disabled-by-constant blocks (delete outright)

| Location | Construct | Why dead |
|---|---|---|
| Racer.cs 743–764 | `#if false … #endif` steer-angle speed limiter | never compiled |
| Racer.cs 766–781 | `if (Brain.Corner.Valid && 1==2) { … }` outward-pointing corner limiter | `1==2` always false |
| Racer.cs 786–798 | "Risk factor for grip" block — computes `speedAdjust`, never reads it | result discarded |
| Racer.cs 865–887 | `if (RacePosition > ARS.catchupPos && 1 == 0) { … }` catchup force/grip push | `1==0` always false |
| ARS 1372 | `if (1 == 1 \|\| !Brain.Corner.Valid \|\| …)` rocket-boost guard | `1==1` makes the rest unreachable |
| ARS 1569–1570, 1616 | `… \|\| 1 == 1` "radar enabled" branches | `1==1` makes the native call unreachable |
| ARS 1638–1644 | `if (1==2 && CanWeUse(playerVeh) …)` add-known-model block | `1==2` always false |
| ARS 2560–2602 | `if (… && 1 == 2)` ghosting block | `1==2` always false |
| ARS 3805–3831 | `if (hash == … && 1 == 2) //Garage stuff, never used` | `1==2` always false |
| Racer/ARS `else if (1 == 1)` in `SetThrottle`, `SetBrakes`, `SetSteerAngle` learn-offset branches | tautology guard | reduce to plain `else` |
| `if (1 == 1)` bodies in `HandleFreecam` scaleform (2069, 2083), `DrawPath`/`DrawSection` (`if (count >= countmax \|\| 1 == 1)`, `if (1 == 1)`) | tautology guard | collapse |

### 1.2 Dead enums and enum members

- `Decision` (ARS 25–28): never referenced anywhere.
- `Mistake` (ARS 29–32): never referenced.
- `OptionValues` (ARS 44–47): never referenced (`OptionValuesList` is keyed by `Options`).
- `CameraTransition` (ARS 54–57): never referenced.
- `RaceState.PostRace` (ARS 35): never assigned or tested.
- `RacerBaseBehavior` is fine but `eLookAheads.SteerInRef` (Racer 44) is declared and never added to the dictionary.
- `BrakeStabilityStrat` (DS 17) and `Corner.stabilityStrat` (DS 219): field is initialized to `Invalid` and never read or changed.

### 1.3 Dead classes and dead class members

DataStructures.cs:
- `VehicleControl.SteerStabilityCorrection`, `.SteerManeuver`, `.SteerMax`, `.FollowLane`, `.ThrottleOffset`, `.CurrentLockupLimiter` — never read.
- `VehData.CurrentDownforce`, `VehData.Understeer`, `VehData.CurveRadiusPhysicalGs` (written once, never read), `VehData.LongitudinalGs` is used — keep.
- `Approach` class (DS 227–233) and `Corner.Approach` field: none of `Valid`/`CheckedForImpediment`/`HoldDeviation` are read anywhere.
- `AIData.SpeedToInput` (DS 12–15): never called.
- `CornerPoint.FullAngle`, `CornerPoint.Speed` (DS 204–205): never assigned meaningfully / never read.
- `Corner.sToEntrance` (DS 218) and `Corner.Speed` are distinct from `CornerPoint.Speed` — `CornerPoint.Speed` is dead; `Corner.Speed` is alive.

Racer.cs:
- `LocalSpdLimiter` (51), `MaxLeftLane`, `MaxRightLane` (49–50), `Traffic` (47) — never used.
- `TorqueMult` (97): assigned in `ProcessTick`, never read.
- `_countersteerBlend`, `CountersteerFullSeverityMult`, `CountersteerRecoveryRate` (109–111): never assigned after init, never read.
- `TrailSamples`/`DrawInputTrails` are alive (called from `DrawStuff`); `FollowLaneTrail`, `RawFollowLaneTrail`, `LastFollowLaneTrailNode`, `UpdateFollowLaneTrail`, `GetFollowLaneTrailPoint`, `GetRawFollowLaneTrailPoint`, `DrawFollowLaneTrail`, `DrawRawFollowLaneTrail` form a complete subsystem that is never invoked — the only writes are the `.Clear()` calls in `Initialize`/`Launch`. Delete the whole lane-trail subsystem.
- `DistToOutside` (546) and `DistToInside` (552): `DistToInside` never called; `DistToOutside` only called inside the `1==2` block above, so both are dead after §1.1 removal.
- `RiskFactorForGrip` (1621), `RiskFactorForBrake` (1625): return 1; never called.
- `StuckRecoveryAttemptsNow`, `IsRecoveringFromStuckNow` public properties: expose private fields but no caller reads them.
- `DebugText` list and `AddDebugText`: populated, never rendered.

AutosportRacingSystem.cs:
- `TracjectoryProjectionSeconds` (184): never read.
- Static terrain-hash lists `Other`, `Road`, `Dirt`, `Sand` (237–241): never enumerated. Only the `TerrainTypes` enum (273) is consulted during track stats. Lists are dead.
- `ImmersiveJoins`/`NeabyImmersiveJoins`/`HandleImmersiveJoins` (1248, 1250–1279): `HandleImmersiveJoins` call is commented out in `OnTick` (1304); whole subsystem dead.
- `AccelerationVector` on ARS (1282), `lSpeed` (1283), `GsClamp` (1290), `directionClamp` (1291): never used.
- `debugTrailer` + `HandlePlayerDebugStuff` (1102, 1104–1179): call site commented out (1303); entire method and field dead.
- `DrawBlackBars` (1188), `DrawMiniaturizedPath` + `MiniaturizedPath` (1195–1237): never called.
- `GetSpeedVector` (1181): no callers.
- `LerpDelta` (768), `RotateDir` (567), `GetXfromPosInDirection` (4756), `IsRoadBusy` (4763), `LerpByDistance` (4751), `OffsetByAngle` (4799), `Project` (6262), `IsBetweenRange` (6258), `IsBitSet` (3301), `GetColorFromRedYellowGreenGradient` (1985), `LaneSelectionApproachCorner` (4732), `HasArrived` (4879), `IsAhead` (4874): no callers.
- `GetRoadHeading` (4654), `GetRoadOutOfBoundsX` (4672), `GetRoadPos` (4690): no live callers.
- Wheel memory helpers: `GetWheelsPower` (4491), `GetMoreShit` (4517), `GetWheelInternalDownforceMod` (4505), `GetWheelsWetgrip` (4542), `GetWheelSkidmark` (4579), `GetWheelSlippage` (4640), `GetWheelsAvgWheelspin` (4567): never called. (`GetWheelsGrip`, `GetWheelsMaxWheelspin`, `GetNumWheels`, `GetWheelsPtr`, `GetWheelPtrs` are live.)
- `GetModelFlags` (5101), `GetTRCurveMax` (5066), `SetDefMultiplier` (5123), `SetGearRatio` (5132): never called.
- `DrawStats` both overloads (4593, 4620): never called.
- `Notify` (3164), `WarnPlayer` (4955): never called.
- `LoadVehicle` (5364–5429): superseded by the nested `LoadVehicleModel` in `LoadGrid`; never called.
- `FillCachedCandidates` block: the `if (1 == 1) { if (1 == 2) {…} else {…} }` wrapper reduces to just the `else` body.
- Scaleforms `racertext`, `debugFrontend`, `floatingtext`: `racertext` always null and never rendered; `debugFrontend` only used by dead `DrawStats`; `floatingtext` never used.
- `PID` class (58–177): the only consumer is `Racer.HeadingPID`, and `HeadingPID.Update` is never called — only `SetValue` runs in `Launch`, which is a no-op for behavior. So the entire `PID` class plus `HeadingPID` are behaviorally dead.
- `eLookAheads.SteerInRef` enum member (44): dead.
- `MiniaturizedPath` field: dead.

### 1.4 Redundant logic / copy-paste that collapses into one helper

- **XmlDocument load pattern**: `GetTrackTags` (396), `GetTrackStartPos` (420), `GetRacerTags` (457) each repeat `new XmlDocument(); document.Load(path);` plus the impossible `while (document == null && pat < 1000) { … document.Load(path); }` retry. Extract one `LoadXmlOrThrow(path)` helper (the retry loop is dead code: `Load` either succeeds or throws, never returns null).
- **Wheel-scalar readers**: `GetWheelsPower`, `GetWheelsWetgrip`, `GetWheelsAvgWheelspin`, `GetWheelSkidmark`, `GetWheelSlippage`, `GetMoreShit`, `GetWheelsGrip`, `GetWheelInternalDownforceMod` are byte-for-byte the same loop with a different `offset` and rounding. One helper `List<float> ReadWheelScalars(Vehicle, ulong offset, int round)` covers all live ones; the dead ones go away under §1.3.
- **Handling-address readers**: `GetTRCurveLat`, `GetTRCurveMax`, `GetSteerLock`, `GetDownforce`, `GetHandlingFlags`, `GetModelFlags` are identical apart from the offset and the cast type. One helper `T ReadHandlingField<T>(Vehicle, ulong offset)` covers them.
- **Hill grip / G-loss**: `GetHillGsLossAtCurrentTrackPoint` and `GetHillGsLossAtCurrentVelocityVector` are near-identical (only the angle source differs: track geometry vs velocity). Same for `GetHillGripMultiplierAtCurrentTrackPoint`/`AtCurrentVelocityVector`. Parameterize on the angle source: one pair instead of four.
- **DrawPath vs DrawSection** (2941, 3054): the two methods share their entire skeleton — bounds setup, `PlayerOrCameraNearPos`, `GetPerpendicular` for `rWidepos`/`lWidepos`, `oldrWidepos`/`oldlWidepos`. The only differences are the `end-1` branch markers and the modulo (`ph % 5` vs `ph % 6`). One `DrawPathSegment(nodes, widedict, edgeStep, drawEndCaps)` covers both.
- **XML point+wide write boilerplate**: in `SaveRoute` (3567–3594), `UpdateRoute` (3342–3381) and overlapping code in `LoadTrack` (3847–3880). One `WriteRoutePoint(document, Vector3 pos, float wide)` and one `ParseRoutePoint(XmlElement)` helper.
- **XML prop write boilerplate**: in `SaveRoute` (3610–3665) and `UpdateRoute` (3404–3461) are byte-equivalent prop-write blocks. One `WritePropElement(document, Prop)` helper.
- **Vehicle XML write boilerplate**: `CreateVehicle` (5964) and `CreateVehicleFromHash` (6166) share the disciplines+model write block. One helper.
- **CleanEverything double-clear**: `WideDict.Clear(); EditWideDict.Clear(); Path.Clear();` appears at 1080–1082 and again at 1094–1096; the `foreach (Prop p in TrackLimits) … Delete()` appears at 1077 and again at 1092. Collapse to a single reset sequence.
- **OptionHovered wraparound**: clamped identically at 1035–1036 and at 1049–1050 inside `HandleMenu`. One clamp is enough.
- **`SpeedToThrottleBrake` symmetric clamp**: `if (newBrake > 0.0) newThrottle = 0;` then `if (Math.Abs(newThrottle) > 0.0f) newBrake = 0;` — collapse to a single "whichever is stronger wins" expression.
- **`DrawPath`/`DrawSection` `count`/`countmax` machinery**: with `if (count >= countmax \|\| 1 == 1)` the condition is always true, so `count++` and `count = 0` are pure noise. Remove the counter entirely.
- **`PlaceOnGround(Prop p)`** (2648): empty method body; remove.

### 1.5 Other pure-simplification opportunities

- `Racer.UpdateFollowTrack` (1244–1248): the `for` loop resets `i = 0` when out of range, which can loop forever if `TrackPoints.Count < 13`. Safer and shorter with a clamped `Enumerable.Range`. Counts as behavior-preserving only if track always has ≥ 13 points; treat cautiously (see bug appendix).
- `AdjustMenuOption` (839–842): empty method invoked as the fallback of `HandleMenuAdjust` once `OnAdjust` is null. Inline the fallback (which is a no-op) and remove the method.
- The `if (routeEditMode) { … if (routeEditMode) { … } }` nested tautology in `EnsureMenuItemDefinitions` for `Options.CreateTrack` (970–976): drop the inner check.

---

## GOAL 2 — Improve clarity through better names

Grouped by file. Casing notes: C# convention invoked is — public types/fields/methods PascalCase; private instance fields `_camelCase` or `camelCase`; private static fields `s_camelCase`/`_PascalCase`. The new ARS code uses `_camelCase` for instance state (e.g. `_cornerPhase`); the older code mixes raw PascalCase instance fields and lowercase public static fields — that is the convention drift to fix.

### AutosportRacingSystem.cs

**Typos / vague**
- `TracjectoryProjectionSeconds` → `TrajectoryProjectionSeconds` (also dead, see Goal 1)
- `FreecCamRide` → `FreeCamRide` (and field `InFreeCam` is fine; the `Freec` is a typo)
- `GametimerefLong` → `GameTimeRefLong` (case + typo)
- `GametimeCountDown` → `GameTimeCountdown`
- `MaxCountDown` → `MaxCountdown`
- `CountDown` → `Countdown`
- `GameTimeShort` is fine, but `GameTimeRef` vs `GametimerefLong` drift — unify on `GameTime…` prefix
- `secInteval` → `SecondInterval`
- `NeabyImmersiveJoins` → `NearbyImmersiveJoins`
- `steeroffset` → `SteerOffset`
- `steerAngle` (static ulong) → `SteerAngleOffset` (it stores an offset, not an angle)
- `numwheelsoffset` → `NumWheelsOffset`
- `scaleform` (public static Scaleform) → `InstructionalButtonsScaleform` (or at least PascalCase `Scaleform`)
- `racertext`, `debugFrontend`, `floatingtext` → `RacerText`, `DebugFrontend`, `FloatingText` (all dead anyway)
- `rnd` (4825) → `_random` / `s_random`
- `rBezier` → `BezierStartAnchor` (or delete — also dead)
- `catchupPos` → `CatchupPosition`
- `map` → `Remap` (the user-suggested name; matches Arduino `map()` naming but C# public method should be PascalCase)
- `mapGamma` → `RemapGamma`
- `GetMoreShit` → (delete; also dead) — keep no in-memory name
- `ReFilterKnownTracks` → `FilterKnownTracks`
- `ParsedEnum` → `FormatEnumName`
- `StartCoundown` → `StartCountdown` (method typo)

**PID class (58–177) — lowercase "kP/kD/kI" parameters + fields**
- `kP, kD, kI` (constructor params) → `proportionalGain, derivativeGain, integralGain`; private fields `kP, kD, kI` → `_proportionalGain, _derivativeGain, _integralGain`
- `value, target, velocity` (private) → `_value, _target, _velocity`
- `maxSpeed, maxAccel` → `_maxSpeed, _maxAccel`
- `integral` → `_integral`
- `lastTick` → `_lastTickTime`
- `Update(float externalD)` → `Update(float externalDerivative)` — clarify sign use instead of the comment.

**Static memory-offset fields (case drift)**
- `static public ulong steeroffset; static public ulong throttleOffset; static public ulong brakeOffset;` — inconsistent case across adjacent lines. Unify to `SteerOffset, ThrottleOffset, BrakeOffset`.
- `handlingPtr, wheelsPtr` → `HandlingPointer, WheelsPointer`.

**Enum/type renames**
- `RacerBaseBehavior` (Racer.cs, see below) → `RacerPhase` (rename lives in Racer.cs but the type is referenced from ARS too).

**Dead-but-if-kept casing fixes**
- `RaceState.PostRace` — delete.

### Racer.cs

**Typos / vague / casing drift**
- `RacerBaseBehavior` → `RacerPhase` (the values `GridWait, Race, FinishedRace, FinishedStandStill` are phases, not behaviors; and "StandStill" is two words)
- `FinishedStandStill` → `FinishedStandstill`
- `RCStatus` (Racer field, typed `RaceState`) → `RacerRaceState` (avoid colliding with static `ARS.RaceStatus`)
- `BaseBehavior` (field) → `Phase`
- `eLookAheads` → `LookAhead` (drop the `e` Hungarian prefix; enum PascalCase)
- `eLookAheads.SteerInRef` (dead) → delete; if kept, `SteerInputRef`
- `SteerTrack()` → `ComputeSteering()` (user-requested; the method computes `Control.SteerTrackDegrees`, not a "track")
- `SpeedTrack()` → `ComputeTargetSpeed()`
- `SpeedToThrottleBrake()` → `ApplySpeedToThrottleBrake()`
- `SteerTranslateInput()` → `TranslateSteerToInput()`
- `SteerApplyCorrections()` → `ApplySteerLimits()` (it only applies the speed-based steer limiter)
- `UpdatePercievedGrip()` → `UpdatePerceivedGrip()` (typo)
- `Memory Brain = new Memory();` → `RacerBrain Brain = new RacerBrain();` (per user request; rename the type in DS too). Or keep the field name and drop the class rename — but the user explicitly asked for `Memory → RacerBrain`.
- `HeadingPID` → if kept, `HeadingPid` (2-letter acronym stays caps; ≥3-letter acronyms become `Pid`). But Goal 1 deletes it.
- `LocalSpdLimiter` → (delete; also `Spd` abbreviation inconsistent with `Speed`)
- `MaxLeftLane`, `MaxRightLane` → delete.
- `Traffic` → delete.
- `TorqueMult` → delete.
- `_countersteerBlend`, `CountersteerFullSeverityMult`, `CountersteerRecoveryRate` → delete.
- `Control.SteerTrackDegrees` → `Control.SteerDegrees` (already a degrees-valued field; "Track" is the misleading half-word from `SteerTrack`)
- `Control.LastAppliedSteerTrackDegrees` → `Control.LastAppliedSteerDegrees`
- `LastSpeed` → `_lastSpeed` (private instance field; match the `_camelCase` convention used by the newer code)
- `HalfSecondTick`, `OneSecondTick`, `LastCoreTick` → `_halfSecondTick`, `_oneSecondTick`, `_lastCoreTickTime`
- `Random` (field, line 98) → `_random` (don't shadow type name `Random`)
- `TrailSample`, `TrailSamples` are fine; the dead trail subsystem goes away under Goal 1.
- `LocalSpdLimiter` etc already covered.

**Rider: `intendedOpponents` only lives on ARS** (ARS 4888) → `IntendedOpponents` (private, but exposed via cheat/menu; if改为 PascalCase make consistent).

### DataStructures.cs

**Class and field casing/names**
- `Memory` → `RacerBrain` (per user request)
- `Memory.data` (public field, lowercase) → `RacerBrain.State` (PascalCase; data is vague)
- `Memory.intention` → `RacerBrain.Intention` (PascalCase); nested `Intention` class is fine
- `Intention.IntendedSpdChangeGs` → `IntendedSpeedChangeGs` (`Spd` inconsistent with sibling `Speed`)
- `Intention.Speed`, `.MaxSpeed`, `.Direction` — keep.
- `Rival.relativePos` (camelCase public) → `RelativePos` (PascalCase public field)
- `Rival.rPos` → `RelativePosition` (and rename `rPos` used internally too)
- `Rival.sToReach` → `SecondsToReach`
- `Rival.sToRear` → `SecondsToRear`
- `Rival.Distance` → keep (or `DistanceTo`); `Rival.DirectionDiff` → `DirectionDiffDegrees` (it's degrees; sibling fields already suffix with units elsewhere — e.g. `YawRotationPerSecondDegrees`)
- `Rival.OccupiedLane`, `.OccupiedLaneWidth` → keep.
- `Rival.BoundingBoxTotal` → `CombinedBoundingBox` (it is the sum of two boxes)
- `Rival.AvoidStr`, `Rival.OvertakeLane` → delete (never read — flagged in Goal 1 if confirmed dead; spot-check shows no reads)
- `Corner.OG` (the "original" CornerPoint) → `Corner.Point`
- `Corner.sToEntrance` → `SecondsToEntrance`
- `Corner.Speed` → `TargetSpeed` (distinguish from `CornerPoint.Speed`)
- `Corner.stabilityStrat` → delete with `BrakeStabilityStrat` enum.
- `Corner.Approach` field → delete with `Approach` class.
- `CornerPoint.LenghtEnd` → `LengthEnd` (typo)
- `CornerPoint.Speed`, `CornerPoint.FullAngle` → delete (dead)
- `CornerPoint.LengthStart` → keep
- `CornerPoint.IsKey` → keep.
- `TrackPoint.TrackWide` → `TrackWidth` (adjective vs noun; "TrackWide" reads as a boolean)
- `TrackPoint.GeneralCurveRadius` / `PreciseCurveRadius` → keep
- `VehData` → `VehicleState` (matches `Racer.VehicleData` field name which then becomes the accessor)
- `VehData.Gs` → `AccelerationGsHorizontal` (vague; the aggregate is used as `AccelerationVector` average / 2)
- `VehData.LocalGs` → `LocalAcceleration`
- `VehData.YawRotationPerSecondDegrees` — keep (verbose but clear)
- `VehData.CurrentDownforce`, `Understeer`, `CurveRadiusPhysicalGs` → delete
- `HandlingData.TRlateral` → `TractionCurveLateral` (matches GTA handling "TRcurve"); also `Power = 1` (untyped) → `Power = 1f` (float consistency)
- `VehicleControl.SteerTrackDegrees` → `SteerDegrees` (matching Racer.cs)
- `VehicleControl.LastAppliedSteerTrackDegrees` → `LastAppliedSteerDegrees`
- `VehicleControl.SteerStabilityCorrection`, `.SteerManeuver`, `.SteerMax`, `.FollowLane`, `.ThrottleOffset`, `.CurrentLockupLimiter` → delete
- `VehicleControl.TCSThrottle` → keep; `HandBrakeTime` → `HandbrakeTime` (GTA API uses `HandbrakeOn`, so unify to lowercase `brake`); minor, optional.
- `AIData` (DS 7) → `AiConstants` (only holds `MaxSpeed`/`MinSpeed`)
- `AIData.SpeedToInput` → delete.

### Convention-drift summary (old vs new)

| Construct | Old (in repos) | Newer code elsewhere | Recommendation |
|---|---|---|---|
| private instance field | `HalfSecondTick`, `LastCoreTick`, `RouteSection` | `_cornerPhase`, `_avoidLeftWall`, `_isPassengerized` | `_camelCase` |
| private static field | `rnd`, `randomcolors` | n/a | `_PascalCase` / `s_PascalCase` |
| public static field | `scaleform`, `steeroffset`, `numwheelsoffset` | `Racers`, `Path` (PascalCase) | PascalCase uniformly |
| public instance field on data class | `Rival.sToReach`, `Memory.data`, `Rival.rPos` (camelCase) | `Rival.Distance`, `Corner.OG` (PascalCase) | PascalCase uniformly |
| enum | `eLookAheads` (Hungarian `e`) | `RaceState`, `Team` (no prefix) | drop `e` prefix |
| method | `map`, `mapGamma` (lowercase) | `ParseToTimeSpan`, `GetCurveRadius` | PascalCase uniformly |
| multi-word acronym | `MaxCountDown`, `GametimerefLong` | `GameTimeRef`, `GameTimeShort` | camelCase interior words, not flattened |

---

## GOAL 3 — Remove all comments

The three files contain the following categories of comments. Goal 3 removes every one; the rename pass in Goal 2 makes the code self-documenting. The single borderline exception is called out at the end.

### 3.1 Empty / stub XML `<summary>` tags

- Racer.cs 543–545 (`DistToOutside`), 662–663 (`SteerTranslateInput`), 1221–1223 (`OutOfTrackDistance`) — summary has no body or only `<returns></returns>`.
- DataStructures.cs 24–25 (before `YawRotationPerSecondDegrees`).

### 3.2 Content XML `///` summaries (remove under Goal 3, deriving docs from names instead)

- Racer.cs 368–372 (`ComputeCornerTargetLane`), 441–452 (`ClampTargetLaneForAvoidance`), 684–686 (`SpeedTrack`), 802–804 (`TractionControl`), 849–851 (`ProcessTick`), 902–904 (`UpdateDynamicBoundingBox` — also typo "percieved"), 927–932 (`UpdatePassengerize`), 1234–1236 (`UpdateFollowTrack`), 1332–1334 (`ProcessTimedAI`), 1387–1389 (`ProcessAI`).
- DataStructures.cs 28–31 (VehData brake stability, typo "percieved"), 60–62 (`Memory` "The AI brain." — becomes redundant once renamed `RacerBrain`), 180–182 (`TrackPoint` "Pure, precise data"), 195–197 (`CornerPoint` "Context aware data").
- AutosportRacingSystem.cs 4258–4261 (`GripGainLossElChange`), 4298–4301, 4327–4330, 4349–4353, 4379–4383 (Hill grip family).

### 3.3 Section banners (decorative)

Racer.cs region headers at lines 23 ("// Identity and runtime references."), 32, 37, 43, 53, 61, 67, 78, 96, 100, 104, 108, 113, 118, 122, 344 (`// ── Local helpers ─────────`).
ARS.cs banners: 217 (`//Freecam`), 228 (`//offsets`), 236 (`//Terrain hashes`), 247, 252 ("//Route info"), 776 ("//Route Creator active section"), 810 ("//Menu"), 1246 ("//Immersive joins"), 1343 (`//Drawing and GUI stuff`), 1349 (`//Scaleforms`), 1352 (`//Info & Tips`), 1369 (`//Timescale control`), 1405 (`//Create the menu on key inputs`), 1427 (`//Handle the countdown`), 1442 (`//While the countdown is on…`), 1499 (`//Where the magic happens.`), 1515 (`//Handle the racing positions`), 1546 (`//Configure the leaderboard…`), 1615 (`//Draw the leaderboard positions`), 1633 (`// long tick`), 4890 (`/// TOOLS ///`).

### 3.4 Stale "removed X" / TODO notes

- ARS 844: `// Removed: OpenRaceOptionsMenu() and OpenRaceSetupMenu() — no longer needed.`
- Racer 1120–1122: `// With angle-based steering there is no lane-offset PID output. // Draw centerline trail for now; restore lane-offset trail when racing line bias is added.`
- ARS 1391–1392: `//Never really used //if (Path.Count > 20 && MiniMap != Vector3.Zero)…` (references an undefined `MiniMap`).
- ARS 2511–2530: commented-out `/* acceleration tuning loop */` block in `SetupRace`.
- ARS 2402–2419: block-commented `/* void LoadAndRace … */` whole method.
- ARS 2788–2896: block-commented `/* cone/barrier placement loop */` in `SpawnTrackLimits`.
- ARS 6266–6275: block-commented body of `Project`.

### 3.5 Disabled-feature / `#if false` / `1==2` narration

- Racer 743–764 `// Steer-angle speed limiter — disabled. Kept for reference.` and the inner `// …` lines inside the `#if false`.
- Racer 765 `// Extra limiter for cars pointing outward in a corner.` (heads the `1==2` block removed in Goal 1).
- Racer 784–785 `// Risk factor for grip. The more we are at the limit… NOT active.`
- ARS 2071, 2083 `if (1 == 1) {` surrounding instruction-buttons scaleform — commentary above is the intended banner; the block itself disappears in Goal 1.
- ARS 3805 `//Garage stuff, never used` above the `1==2` block.
- ARS 2560 `DisplayHelpTextTimed("Ghosting cars...", 10000);` block's surrounding commentary.
- ARS 2402 `/* … LoadAndRace … */` already listed.

### 3.6 Inline math / algorithm narration (remove once names document it)

The densest cluster is `SteerTrack`/`ComputeCornerTargetLane`/`ClampTargetLaneForAvoidance` (Racer 258–528) — every numbered step has a `// 1) Heading error …`, `// 2) Compute target lane …`, up to `// 8) Slide countersteer …`, plus inline restatements such as `// Positive = right of center…`, `// For a right turn (cornerDir=-1): Outside=left… Apex=right…`, `// Aggression-scaled buffer: 0 aggro = 2m gap…`, `// Each side independently: snap when constrained, decay…`, `// Clamp target lane so our car's edge (not center) stays at the wall.`.
`SpeedToThrottleBrake` 588, 596, 616, 627, 644–645.
`SpeedTrack` 713, 732–733, 765, 784–785.
`ProcessTick` 864 (`//Catchup`).
`UpdateTickData` 833 (`// Sample trail for input visualization …`).
`UpdatePercievedGrip` 1537 (`//Base vehicle grip GetVehicleMaxTraction`), 1565 (`//Checks for Z movement to judge wether the car is stable…`), `//VehicleData.CurrentMechanicalGrip += GsLoss;`.
`ARS MapIdealSpeedForDistance` 4780–4791 (`// Returns the max speed (m/s)… Uses the kinematic braking equation: v₀ = √(vTarget² + 2·decel·distance)` etc.).
`GenerateRouteInfo` 3925, 3941, 3984, 4022–4089 (comments `// 1) Compute a span…`, `// 2) Remove any key corner ahead…`, `// 3) Build per-node lane bias…`, `// Build an absolute lane target from a quadratic Bezier…`, `// For each node in this corner span, project to the closest Bezier sample…`).
`GetSpeedForCorner` 4404 (`// Find the tightest radius across all nodes in the corner.`), 4415 (`//Error handling - return max and be done with it`), 4418 (`//Base percieved grip`).
`GetDownforceGsAtSpeed` 5029 (`//Downforce at that speed`).
`Rival.Update` 155 (`//TODO`-style dead code `// me.Car.Position.DistanceTo2D…`).
Hill/grip methods 4266, 4277, 4306, 4317, 4351, 4372 (`// 0..1 for 0..90 deg`).

### 3.7 Terrain-hash inline notes (ARS 236–241, 281)

- `//Terrain hashes` banner.
- Trailing `//-1286696947<grass` on the `Road` list line (238).
- Trailing `//-461750719` on the `Dirt` list line (240).
- `MoreTarmac = 1187676648, //Concrete` (281).
These all die with the static hash lists under Goal 1 §1.3.

### 3.8 Obvious restatements / "Constructor"-style

PID class (ARS 58–177): `// Fields` (60), `// Constructor` (71), `// Update method - advances the controller by dt seconds` (90), `// Clamp acceleration to maxAccel` (114), `// Clamp velocity to maxSpeed` (122), `// Snap to target if close enough` (130), `// Set target value with clamping` (140), `// Set current value and reset velocity and integral` (146), `// Get current value` (154), `// Get target value` (160), `// Modify target value with clamping` (166), `// Check if close to target within threshold` (172).

Other restatements:
- Racer 62 `//500ms`, 63 `//1000ms`.
- ARS 249 `//For catchup stuff only`.
- ARS 597 (`// scale to 1.0;`), 598 (`//original 0.4f`).
- ARS 1227–1228, 2968, 3026 etc — many trailing `// DrawLine(vm,last, Color.Black);`-style dead remarks after `World.DrawMarker` calls.
- Several `//if (…)` one-liners inside `OnTick` blocks (1303, 1304, 1314–1327 `/* … */`, 1392, 2492–2496, 2511–2530, 5524-ish).
- Trailing XML-comma narration in TrackCreator/Save/Update (`//document.SelectSingleNode("Data/Route").AppendChild(element);` at 3345, `//void _SET_OBJECT_TEXTURE_VARIANT(Object object, int paintIndex)` at 3412, 3618).
- ARS 3504-3508: surrounding comment blocks about Flares and Frozen attributes (already in XML schema; redundant).

### 3.9 Exception (zero or one)

Zero comments kept. The single tempting candidate is the PID sign-convention note (ARS 96–99):

```
// Update with external derivative input (e.g. yaw rate).
// When externalD is non-zero, it replaces the internal velocity derivative.
// Sign convention: positive externalD = turning left, which should reduce
// right-steering error, so derivative = -externalD * kD.
```

This documents the only non-obvious arithmetic sign in the codebase. Under this audit, however, the comment is removed and the convention is encoded in the rename `externalD` → `externalDerivative` plus the existing `-externalDerivative * kD` expression: a reader who knows `kD` is "derivative gain" sees the negation directly. No other comment is worth keeping.

---

## Appendix — bugs noticed during the read (informational; outside the three goals)

These are noted for later; the refactor goals above must not change them.

1. `GetTrackTags`/`GetTrackStartPos`/`GetRacerTags` (ARS 402–406, 426–430, 463–467): `while (document == null && pat < 1000) { document.Load(path); }` is unreachable — `XmlDocument.Load` either returns successfully (document non-null) or throws. The retry loop never executes. Not a runtime bug, but dead-code that will go under Goal 1.
2. `Racer.UpdateFollowTrack` (1244–1248): `for (int i = refTrackpoint - 6; points.Count <= 12; i++)` with `if (i < 0 || i >= TrackPoints.Count) i = 0;` — if `TrackPoints.Count < 13`, this loop never terminates (it resets `i` to 0 and keeps adding `TrackPoints[0]`). Possible infinite loop on short circuits; protect with a count cap.
3. `GetCurveRadius2D` (4210–4237): `slope1 = (point2.Y - point1.Y) / (point2.X - point1.X); perpendicularSlope1 = -1 / slope1;` — vertical chord (equal X) divides by zero, producing `±Infinity`/`NaN` that propagates as a bogus radius instead of falling back. Surrounding callers NaN-guard the radius afterward, but `Infinity` clamps to `AIData.MaxSpeed`; a zero-division guard at the source would be clearer.
4. `Rival.Update` (DS 119–155): `BoundingBoxTotal.Y` mixes half-lengths with a `+2f` fudge and is then compared with `rPos.Y` (which is signed forward offset from `GET_OFFSET_FROM_ENTITY_GIVEN_WORLD_COORDS`). The thresholds conflate longitudinal distance with bounding-box half-length; `RelativePos.Ahead` will be set too easily. Verify the fudge value is intended as meters, not units.
5. `SetupRace` ghosting block (ARS 2560) is gated by `&& 1 == 2`. If the ghosts setting is ever re-enabled, the nested `for (int i = orig.IndexOf…)` loop has O(n²) duplicate detection that walks past `break;` only on handle mismatch — duplicate set membership is better done with a `HashSet<(int,int)>`.
6. `FillCachedCandidates` (5519–5577) builds `candidates` via `candidates.Add` only inside the dead `if (1 == 2)` branch; the live path adds only from `RacerToStats.OrderBy`. The preceding `candidates.Clear();` (5580) clears an already-empty list — harmless but signals that the `if(1==1){if(1==2){…}else{…}}` shape once had different logic; collapse in Goal 1.
7. `Racer.ProcessTick` catchup block (865–887): dead because of `1 == 0`, but if re-enabled, `Car.ApplyForceRelative(new Vector3(v, 0, 0))` passes lateral force on X, which under ApplyForceRelative is local — means lateral shove — fine, but the magic divisor `/1000` on a setting is undocumented.
8. `Memory.intention.Direction` is a `Vector3` field that is never assigned anywhere — the `Intention` class declares it but no writer sets it. Reads would always get `Vector3.Zero`. Likely dead field.