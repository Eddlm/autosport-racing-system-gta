# ARS Refactoring Audit

**Scope:** Three source files for the GTA V Autosport Racing System (ARS) mod — C# / .NET 4.8 / ScriptHookVDotNet v2.

| File | Lines | Role |
|---|---:|---|
| `AutosportRacingSystem.cs` | 6,280 | Script entry, menu, race lifecycle, route/grid/loading, free-cam, freecam/track-creator UI, native wrappers, settings. |
| `Racer.cs` | 1,633 | Per-car AI: steering, throttle/brake, avoidance, stuck recovery, debug draw. |
| `DataStructures.cs` | 238 | Shared types: `Memory`, `Rival`, `VehData`, `HandlingData`, `TrackPoint`, `CornerPoint`, `Corner`, `VehicleControl`, `Approach`, `Intention`, `AIData`, `BrakeStabilityStrat`. |
| `PersonalitySet.cs` | 10 | Empty stub — vestigial file from the recent personality cleanup. |
| `SkillSet.cs` | 9 | Empty stub — vestigial file from the recent personality cleanup. |

Net non-blank: **~8,150 lines** across three real files (plus 2 empty stubs).

---

## Top-level findings (one-screen summary)

| # | Severity | Area | Headline |
|---|---|---|---|
| 1 | 🔴 Critical | Architecture | The whole mod is a single 6,280-line god-class (`ARS`) plus one 1,600-line AI class. Almost everything is `public static` on `ARS`. |
| 2 | 🔴 Critical | Coupling | `Racer.cs` and `DataStructures.cs` reach into `ARS.*` statics for nearly every operation. The "data structures" file isn't independent — it's an extension of the god-class. |
| 3 | 🟠 Major | Dead code | At least **15** `1 == 1` / `1 == 2` gates, hundreds of lines of commented-out blocks (≥193 in ARS alone), and an entire `Settings`, `Options` enum and `OptionValues` enum most of which are unused. |
| 4 | 🟠 Major | Error handling | 16 `try { ... } catch (Exception) { }` (all with empty body) and 9 more with logging. The whole `OnTick` is wrapped in a single catch that hides bugs. |
| 5 | 🟠 Major | OnTick | `OnTick` is **~370 lines** and runs HUD draw, AI tick, leaderboard, free-cam, menu, traffic suppression, and chat output in one method. |
| 6 | 🟡 Medium | Bezier math | `ARS.Bezier2` is a literal **linear lerp** because the middle control point is hard-coded to `Vector3.Zero` — but it's used in the route creator. |
| 7 | 🟡 Medium | Magic numbers | `EngineTopSpeed(v) / 0.75f`, `Brain.intention.Speed ≤ EngineTopSpeed(Car) * 1.3f`, `2f * 0.5f` safety margins, plus ~50 unnamed tuning constants. |
| 8 | 🟡 Medium | Settings | `Options.ini` and `Developer Settings.ini` are read via 20 `ScriptSettings.GetValue<T>` calls with string-keyed sections — no central schema, no type-safety, no validation. |
| 9 | 🟡 Medium | Threading | `Task.Run(() => FillKnownDisciplines(...))` invokes SHVDN `Model`/`Hash` calls on a non-script thread (line 300). Race-condition latent. |
| 10 | 🟡 Medium | AI rate | The round-robin AI tick math (`OnTick` 1486–1495) is broken for grids >6: it gives 6 racers an effective ~55 Hz each but the spacing is wrong. |
| 11 | 🟢 Low | Per-entity work | `Racer.LookAheads` is a `Dictionary<enum, TrackPoint>` rebuilt every AI tick; would be a struct. |
| 12 | 🟢 Low | Duplication | `DrawPath` and `DrawSection` are 95% identical. `DrawStuff` repeats the same chevron block for `Driver.IsPlayer` true/false. `Racer.FollowLaneTrail` and `Racer.RawFollowLaneTrail` are duplicates. |
| 13 | 🟢 Low | Two RNGs | `static Random rnd` in `ARS` and a per-`Racer` `Random` — two different sources of randomness. `RandomTuning` uses the static; avoidance/rivals use the per-Racer. |

---

## 1. Code volume and density

- **8,151 lines** of C# for what is conceptually: a settings loader, a track/route loader, a grid loader, a per-car AI loop, a HUD draw layer, and a route creator.
- **`Function.Call(`** appears **107 times** — that's 107 raw native invocations, most of them done in helpers that don't always null-check the entity first.
- **`XmlDocument` / `XmlElement` / `XmlNode`** appear **117 times**. There's no XML helper class — every `SaveRoute` / `LoadTrack` / `CreateVehicle` / `CreateDriver` / `UpdateRoute` builds the tree by hand, in many cases repeating the same 7-line block (X/Y/Z/Wide + decimal-point replacement) **four or more times**.
- **`static` (public/internal/private combined)** is declared **124 times**. The `ARS` class alone has roughly **80 public statics**. Every one of them is global state.
- **193 comment-lines that look like commented-out code** (regex `^\s*//\s*[A-Za-z0-9_]+`) in `AutosportRacingSystem.cs` alone, on top of **24** `/* ... */` blocks of varying size (e.g. the 110-line commented-out trackside-spawner at lines 2788–2896, the 60-line commented-out "garage" at 3805–3831, the 130-line commented-out "ghost pairing" at 2564–2602).
- **6** `TODO` / `FIXME` / `HACK` markers across the codebase.

---

## 2. The static-monster anti-pattern

**`ARS` is 6,280 lines, 80+ public statics.** Examples (line numbers in `AutosportRacingSystem.cs`):

- State: `Racers`, `TrackPoints`, `CornerPoints`, `Path`, `WideDict`, `Angles`, `MultiplierInTerrain`, `KnownVehicleModels`, `RacerTags`, `OptionValuesList`, `OptionsList`, `LeaderboardFinish`, `FilteredTrackList`, `CustomProps`, `AutoGeneratedProps`, `TrackLimits`, `GlobalTraffic`, `FlareFX`, `HelpMessages`, `NeabyImmersiveJoins` (yes, misspelled), `MiniaturizedPath`, `ExhaustOffsets`, `Racers`, `catchupPos`, `IsPointToPoint`, `GridPositions`, `RaceReward`, `RaceStatus`, `HideHudMode`, `Loaded`, `IsLoadingScript`, `listenmode`, `DebugVisual`, `TracjectoryProjectionSeconds` (also misspelled), `CamIntendedHeight`, `TimeScale`, `IdealTimeScale`, `FreeCamMovement`, `FreeCamRotation`, `InFreeCam`, `routeEditMode`, `intendedOpponents`, `rnd`, …

- Static helpers that should be instance methods: `LeftOrRight`, `RotateDir`, `GetOffset` (two overloads), `EngineTopSpeed`, `map`, `mapGamma`, `Clamp`, `rad2deg`, `deg2rad`, `LerpDelta`, `Lerp`, `LerpByDistance`, `Bezier2`, `Bezier3` (instance), `ClosestNodeToPlace`, `GetCurveRadius`, `GetCurveRadius2D`, `GetPreciseRadius`, `GripGainLossElChange`, `GetHillGsLossAtCurrentTrackPoint`, `GetHillGsLossAtCurrentVelocityVector`, `GetHillGripMultiplierAtCurrentTrackPoint`, `GetHillGripMultiplierAtCurrentVelocityVector`, `GetSpeedForCorner`, `GetDirectionalBoundingBox`, `DrawDirectionalBoundingBox`, `GetWheelsPtr`, `GetNumWheels`, `GetWheelPtrs`, `GetWheelsPower`, `GetWheelInternalDownforceMod`, `GetWheelsGrip`, `GetWheelsWetgrip`, `GetWheelsMaxWheelspin`, `GetWheelsAvgWheelspin`, `GetWheelSkidmark`, `GetWheelSlippage`, `GetHandlingPtr`, `GetTRCurveLat`, `GetTRCurveMax`, `GetSteerLock`, `GetDownforce`, `GetModelFlags`, `GetHandlingFlags`, `SetDefMultiplier`, `SetGearRatio`, `DrawText` (two overloads), `DrawLine`, `DrawStats` (two overloads), `CanWeUse`, `WasCheatStringJustEntered`, `ParseToTimeSpan`, `GetPercent`, `MStoMPH`, `MPHtoMS`, `GetRandomInt`, `DrawText(Vector2,...)`, `DisplayHelpTextTimed`, `DisplayHelpText`, `RandomTuning`, `LoadTrackFile`, `GetChild`, `GetAttribute`, `NodeExists`, `LookForCornerAhead`, `MapIdealSpeedForDistance`, `GenerateBezier`, `GenerateCubicBezier`, `GenerateRouteInfo`, `GetRoadHeading`, `GetRoadOutOfBoundsX`, `GetRoadPos`, `GetSurfaceHash`, `IsBetweenRange`, `Project`, `OffsetByAngle`, `QuadraticBezier`, `GetColorFromRedYellowGreenGradient`, `GradientAtoB`, `GradientAtoBtoC`, `GetDownforceGsAtSpeed`, `IsBitSet`, `GetSpeedVector`, `Log`, `WarnPlayer`, …

**Why it hurts:**
- You can't have two `ARS` instances — but more importantly, two `ARS` instances running in the same SHVDN process (which never happens today but is plausible during tests) would corrupt each other's state instantly.
- `Racer` reads `ARS.TrackPoints`, `ARS.CornerPoints`, `ARS.Clamp`, `ARS.map`, `ARS.GetOffset`, `ARS.MPHtoMS`, `ARS.MStoMPH`, `ARS.EngineTopSpeed`, `ARS.GetRandomInt`, `ARS.GetWheelsGrip`, `ARS.GetHillGripMultiplierAtCurrentVelocityVector`, `ARS.GripGainLossElChange`, `ARS.GetCurveRadius`, `ARS.rad2deg`, `ARS.GetSpeedForCorner`, `ARS.MapIdealSpeedForDistance`, `ARS.LookForCornerAhead`, `ARS.GetDirectionalBoundingBox`, `ARS.GetWheelsMaxWheelspin`, `ARS.GetDownforce`, `ARS.GetTRCurveLat`, `ARS.GetSteerLock`, `ARS.GetHandlingFlags`, `ARS.CanWeUse`, `ARS.GetRandomInt`, `ARS.GetOffset`, `ARS.SetThrottle`, `ARS.SetBrakes`, `ARS.SetSteerAngle`, `ARS.SetSteerInput`, `ARS.DrawLine`, `ARS.DrawText`, `ARS.GradientAtoBtoC`, `ARS.MStoMPH`, `ARS.OptionValuesList`, `ARS.DevSettingsFile`, `ARS.SettingsFile`, `ARS.Racers`, `ARS.Log`, `ARS.MapIdealSpeedForDistance`, `ARS.IsPointToPoint`, `ARS.CornerPoints`, `ARS.TrackPoints`, `ARS.GetPercent`, `ARS.IsPointToPoint`, `ARS.GetOffset`, `ARS.LeftOrRight`, `ARS.WideDict`, `ARS.GetCurveRadius`, `ARS.GetPreciseRadius`, `ARS.Clamp`, `ARS.GetCurveRadius2D`, `ARS.TrackPoints`, `ARS.MultiplierInTerrain`, `ARS.QuadraticBezier`, `ARS.GetHillGsLossAtCurrentVelocityVector`, `ARS.GetHillGripMultiplierAtCurrentTrackPoint`…  — every method is at least 5 statics long.
- `DataStructures.Rival.Update` calls `ARS.GetOffset(me.Car, RivalRacer.Car)` — a "data" class that depends on the god class.

**The fix is a layered split** (see §14).

---

## 3. Vestigial / dead code

### 3.1 Empty files
- `PersonalitySet.cs` and `SkillSet.cs` are both empty (`namespace ARS { }`). They are still listed in the `.csproj` as `<Compile Include>`. **Delete the files and remove the project entries.**

### 3.2 Dead state on `ARS`
- `AccelerationVector` (line 1282) — declared, never assigned.
- `lSpeed` (line 1283) — declared, never assigned.
- `GsClamp` / `directionClamp` (line 1290–1291) — declared, never read.
- `LoadScriptTask` is checked but it's the only task ever started.
- `MultiplierInTerrain` — written by `Racer.UpdatePercievedGrip` (Racer.cs:1558) but **never read** anywhere.
- `ECharMismatches` — none, but the `distToPercent` dict (line 3219) is only assigned, never read.
- `MiniaturizedPath` (line 1195) and `DrawMiniaturizedPath` (line 1196) — caller is commented out at line 1392.

### 3.3 Dead fields on `Racer`
- `_countersteerBlend` (line 109) — never read or written after declaration.
- `CountersteerFullSeverityMult`, `CountersteerRecoveryRate` (lines 110–111) — only the constants exist; the logic is gone.
- `LocalSpdLimiter` (line 51) — declared, never read.
- `Traffic` list (line 47) — declared, never used.
- `BaseBehavior` has a value `FinishedStandStill` set in `OnTick` (line 1509) but no path actually transitions the racer to that state vs `FinishedRace` — both effectively stop the AI.
- `RiskFactorForGrip` / `RiskFactorForBrake` (lines 1621–1628) return `1f` — vestigial.
- `Brain.Corner.Approach` (defined in `DataStructures.cs:227`) is set up but never mutated after the constructor; `CheckedForImpediment` and `HoldDeviation` are never read.

### 3.4 Dead fields on `Rival`
- `OvertakeLane` (DataStructures.cs:109) — declared, never read.
- `AvoidStr` (line 110) — declared, never read.
- `Rivals` is pre-populated with 3 placeholder `Rival()` instances (lines 70–72) that are immediately overwritten by `Racer.UpdateRivals` (line 1590). The pre-population is dead.
- `UpdateRivals` iterates `Brain.Rivals.Count - 1` (line 1594) — off-by-one with intent. The intent was to leave the last slot as a placeholder, but the field is filled with the same pattern as the rest.

### 3.5 Dead code in the `Options` enum
- `RaceOptions`, `Brakepower`, `RestartRace`, `Start`, `Laps`, `LeaveRace`, `StopRace`, `LoadTrack`, `DebugLevel`, `SaveTrack`, `UpdateTrackFile`, `CreateTrack`, `ExitCreator`, `TrackNameFilter`, `TrackList`, `SaveDriverModel`, `Disciplines`, `FindCustomProps`, `ReloadSettings` — most of these exist in the enum but the corresponding menu items, handlers, or the `OnTick` references are absent. The menu now exposes only `Options.StartRace` and `Options.Freecam` (line 856).
- The `OptionValues` enum has only one value (`ShowAggression`) and nothing reads it.
- `MenuItemDefinitions` is initialized only for the route-editor and start-race paths; `AdjustMenuOption` is empty (line 839–842).

### 3.6 Dead catchup system
- `catchupPos` is read at line 867 with the gate `1 == 0` — i.e. **always false**. The entire `//Catchup` block in `ProcessTick` (lines 864–887) is dead.

### 3.7 Dead "outward-pointing" brake
- `SpeedTrack` line 766 contains `if (Brain.Corner.Valid && 1 == 2)` — the limiter is gated by a permanent false.

### 3.8 Dead "grip risk" computation
- The "Risk factor for grip" block (lines 786–798) computes `speedAdjust` and never uses it. The comment even says `// NOT active.`

### 3.9 Dead "rocket boost" condition
- `if (1 == 1 || !Brain.Corner.Valid || Brain.Corner.sToEntrance > 4)` at line 1372 — the `1 == 1` makes the OR trivially true. Cleaner as `if (true)` and the comment can go.

### 3.10 Dead auto-add new car
- The 3-second block at line 1638: `if (1==2 && CanWeUse(playerVeh) && !KnownVehicleModels.Contains(...))` — entire path is unreachable.

### 3.11 Dead `HandlePlayerDebugStuff`
- The whole method (lines 1104–1179) is body-less except for a never-reached `IsAttachedTo` branch and ~70 lines of `/* ... */` comment. The caller at line 1303 is also commented out.

### 3.12 Dead `AdjustMenuOption`
- Empty body and a comment "No adjustable items remain in the menu." (line 841). Delete the method.

### 3.13 Dead `OffsetByAngle`
- Draws inside a math helper (line 4820–4821) and is only called from the (also dead) `Project` path. Either delete or move the `DrawLine` to the caller.

---

## 4. Dead branches: `1 == 1` and `1 == 2`

There are **15** of these. They look like feature flags from in-progress refactors that were never removed. List (file:line — meaning):

| File:Line | Pattern | Real condition |
|---|---|---|
| AutosportRacingSystem.cs:722 | `else if (1 == 1)` | `else` |
| AutosportRacingSystem.cs:743 | `if (Brain.Corner.Valid &&1==2)` | never |
| AutosportRacingSystem.cs:750 | `else if (1 == 1)` | `else` |
| AutosportRacingSystem.cs:1380 | `if (1 == 1)` | always |
| AutosportRacingSystem.cs:1638 | `if (1==2 && CanWeUse...` | never |
| AutosportRacingSystem.cs:2071 | `if (1 == 1)` | always |
| AutosportRacingSystem.cs:2083 | `if (1 == 1)` | always |
| AutosportRacingSystem.cs:2556 | `if (... && 1 == 2)` | never |
| AutosportRacingSystem.cs:2560 | `if (SettingsFile.GetValue<bool>(...) && 1 == 2)` | never |
| AutosportRacingSystem.cs:2710 | `if (... == "true")` | dead variant of the flares feature |
| AutosportRacingSystem.cs:2966 | `if (count >= countmax \|\| 1 == 1)` | always |
| AutosportRacingSystem.cs:2988 | `if (1 == 1)` | always |
| AutosportRacingSystem.cs:3075 | `if (count >= countmax \|\| 1 == 1)` | always |
| AutosportRacingSystem.cs:3095 | `if (1 == 1)` | always |
| AutosportRacingSystem.cs:5523 | `if (1 == 1)` | always |

Replace each with the actual condition (or just the truth constant and remove the gate).

---

## 5. Error handling

There are **16** `try { ... }` blocks in the three files. Of those:
- **8** in `AutosportRacingSystem.cs` and **8** in `Racer.cs` use `catch (Exception) { }` with an **empty body** — they swallow everything (NRE, OOM, ThreadAbort, …) and never log.
- The remaining 9 (all in `AutosportRacingSystem.cs`) log via `Log(LogImportance.Error, ...)` or `UI.Notify`.

The two single-letter habits — `catch (Exception) { }` and `catch (Exception) { /* … */ }` — are everywhere. Examples:
- `Racer.cs:138, 145, 149, 159, 173, 176, 191, 129, 954, 958` (passengerize seat swap, name parsing, blip creation, etc.).
- `AutosportRacingSystem.cs:148, 873, 891, 915, 1674, 3170, 3260, 4863, 4865, 5241, 5267, …`

The `OnTick` wraps the entire body in a single try/catch (line 1295 / 1657) that logs only the message. Because the body is ~370 lines, a thrown exception means *anything* after the throw point silently doesn't happen that frame. This makes flaky behavior (e.g. a Racer that was about to call `Launch()`) hard to spot.

**Recommended:**
- Replace empty catches with at least `Log(LogImportance.Error, "methodName: " + ex.Message)` so a misbehaving Racer or a malformed XML file doesn't vanish into the void.
- For real recovery (e.g. `SetIntoVehicle` failing when a player is currently driving), narrow the catch: `catch (InvalidOperationException) { }`.
- Split `OnTick` into `OnTick_Input()`, `OnTick_AI()`, `OnTick_Hud()`, `OnTick_Leaderboard()` so a throw in one doesn't take the others down.

---

## 6. The `OnTick` god method (lines 1293–1661)

`OnTick` is **~370 lines** of `if (X) Y; if (Z) W; …` and does:

1. Load-task polling (`HandleLoadScriptTask`).
2. Player/character existence check.
3. Cheat handling (later in the call).
4. Free-cam-ride prop existence / spawn.
5. Free-cam input (`HandleFreecam`, ~225 lines on its own).
6. HUD draw: timer, prop markers, scaleform render.
7. Time scale lerp.
8. World traffic suppression (6 native calls).
9. Menu hotkey handling.
10. Menu rendering (`HandleMenu`).
11. Countdown start check.
12. Countdown logic (auto-jack into AI vehicles, audio cues, SCCountdown scaleform).
13. `Launch()` of all racers.
14. **AI round-robin** (see §10).
15. Per-racer process tick.
16. Lap-completion / leaderboard promotion.
17. Race-position sort (every 200 ms).
18. Leaderboard / HUD text composition.
19. HUD draw.
20. Long-tick (3 s) cleanup: help messages, new-vehicle detection (dead).
21. `Cheats()` (10+ cheat-string checks).

The free-cam alone is **225 lines** (2043–2269) and lives inside `HandleFreecam`. Most of the rest is in `OnTick` directly.

**Refactor:**
- Extract `OnTick_HandleRaceLifecycle()`, `OnTick_DrawHud()`, `OnTick_HandleInput()`, `OnTick_HandleCountdown()`, `OnTick_RunAI()`.
- Make `HandleFreecam` a separate class `FreecamController` that takes a `Prop ride` and `GameplayCamera` in its constructor.

---

## 7. AI / driving subsystem

### 7.1 `Racer.cs:1,633` lines for one class

The `Racer` class is doing seven jobs: input shaping, lane selection, speed selection, traction control, stuck recovery, debug visualization, and lifecycle. Method counts (approximate):

| Section | Lines | Notes |
|---|---:|---|
| Identity & state | 22–122 | |
| `ctor` / `Initialize` / `Launch` | 125–248 | |
| `SteerTrack` | 250–366 | 110 lines, includes a nested local function `TryGetSteerContext` |
| `ComputeCornerTargetLane` | 373–439 | |
| `ClampTargetLaneForAvoidance` | 453–529 | |
| `SteerApplyCorrections` / `DistToOutside` / `DistToInside` | 531–556 | |
| `SpeedToThrottleBrake` | 581–658 | |
| `SteerTranslateInput` | 664–682 | |
| `SpeedTrack` | 687–800 | 110 lines; contains a `#if false` block at 743–764 |
| `TractionControl` | 805–818 | |
| `UpdateTickData` | 819–848 | |
| `ProcessTick` | 852–889 | |
| `RunTimedCore` | 890–901 | |
| `UpdateDynamicBoundingBox`, `UpdateCornerInfo`, `UpdatePassengerize` | 905–960 | |
| `ApplyInputs` | 962–983 | |
| `DrawStuff` | 984–1106 | 122 lines, two near-identical branches for player vs AI |
| `UpdateFollowLaneTrail` / `DrawFollowLaneTrail` / `DrawRawFollowLaneTrail` | 1108–1181 | two near-identical trails |
| `DrawInputTrails` | 1183–1219 | |
| `OutOfTrackDistance`, `UpdateRivalInfo` | 1224–1232 | |
| `UpdateFollowTrack` | 1237–1324 | 90 lines |
| `ProcessTimedAI` | 1335–1385 | |
| `ProcessAI` | 1390–1421 | |
| Stuck recovery (`UpdateStuckCheck` / `UpdateStuckRecovery` / `ApplyStuckRecoveryOverride` / `HandleRecoveryAttemptEscalation`) | 1424–1532 | 108 lines for 4 methods |
| `UpdatePercievedGrip` | 1534–1578 | 45 lines, dense math |
| `UpdateRivals` | 1579–1600 | |
| `Delete`, `RiskFactorForGrip`, `RiskFactorForBrake` | 1602–1628 | |

**Refactor target: split `Racer` into:**
- `RacerCore` (id, vehicle, lifecycle, base behavior)
- `RacerInput` (Control struct, ApplyInputs, SpeedToThrottleBrake, SteerTranslateInput, TractionControl)
- `RacerSteering` (SteerTrack, SteerApplyCorrections, ComputeCornerTargetLane, ClampTargetLaneForAvoidance, PID)
- `RacerSpeed` (SpeedTrack, UpdatePercievedGrip, UpdateDynamicBoundingBox)
- `RacerRivals` (UpdateRivals, Rival state, avoidance, passengerize)
- `RacerRecovery` (stuck detection, recovery, override, escalation)
- `RacerDebugDraw` (DrawStuff + the three trail drawers)

This isn't a behavioral change — it makes each unit individually testable from a `Racer`-like façade.

### 7.2 `SteerTrack` is too long and contains a nested local function

Lines 250–366. The `TryGetSteerContext` local function is a 20-line closure that returns two out-params. Lift it to a `private bool TryGetSteerContext(out TrackPoint, out float)` — the body is identical, but the call site reads cleanly and the stack trace points to a real method.

### 7.3 `#if false` block in `SpeedTrack`

Lines 743–764 are wrapped in `#if false … #endif`. Delete them. If you want the steer-angle-based speed limiter, gate it on a settings key.

### 7.4 Speed limiter is mathematically wrong for low speeds

`SteerApplyCorrections` at line 537:
```csharp
float speedBasedSteeringLimit = (float)((VehicleData.BaseMechanicalGrip * Handling.Gravity * VehicleData.WheelBase) / Math.Pow(Car.Velocity.Length() + 0.01f, 2.01f));
speedBasedSteeringLimit = Math.Max(ARS.rad2deg(speedBasedSteeringLimit) * 0.9f, 1f);
```

For a car at 0.1 m/s with `grip=1`, `g=9.8`, `wheelbase=2.5`, this gives `(1·9.8·2.5) / 0.01^2.01 ≈ 245,000` rad/s², then deg2rad'd, then clamped to `max(22,000, 1)` = `22,000` degrees. The 1° floor is the only thing that prevents a control explosion at low speed. The `2.01f` exponent (instead of 2.0) is unexplained.

**Fix:** clamp the input velocity before the formula: `Math.Max(Car.Velocity.Length(), MinSpeedForSteering)`.

### 7.5 The `1°` minimum steering is silently huge

The `Math.Max(..., 1f)` at line 538 means the steering can never be less than 1° — but the steering lock is typically 30–40°. 1° is ~3% of lock, so the AI is *guaranteed* to be moving the wheel at all times. For a slow approach on a straight, this looks like nervous twitching.

### 7.6 `HeadingPID` is built but never used

`Racer.HeadingPID` (Racer.cs:35) is constructed, `SetValue(0f)` is called in `Launch` (line 573), but `Update()` is never called. The "PD" in `SteerTrack` (lines 326–330) is open-coded instead. Either delete the field or actually use it.

### 7.7 `_countersteerBlend` and friends

Lines 109–111 declare three fields and constants that are never read. The cross-check comment in memory says "ARS steering — single bias from clamped lane, no separate natural + avoidance split", which matches the code — the countersteer-blend feature was removed. Delete the three declarations.

### 7.8 Avoidance math has a per-frame hazard: 1-frame wall jumps

`ClampTargetLaneForAvoidance` (Racer.cs:453) has:
```csharp
if (leftConstrained)  _avoidLeftWall  = targetLeftWall;
else                  _avoidLeftWall  = Math.Max(_avoidLeftWall - openRate, -trackBound);
```
The "snap" branch fires when *any* rival is in `Left | Right | Ahead-with-sToReach<=4` range. There is no hysteresis. If a rival oscillates at the edge of those filters, the wall snaps and unsnaps every tick. Add a small dead zone (e.g. only release when rival is 1.5× further than the snap threshold).

### 7.9 `_avoidLiftOff` only checks the nearest ahead rival

Line 736:
```csharp
Rival threat = Brain.Rivals.FirstOrDefault(r => r.RivalRacer != null && r.relativePos == RelativePos.Ahead);
```
`FirstOrDefault` returns the first `Ahead` rival in `Brain.Rivals`. The list is filled by `UpdateRivals` (line 1579) sorted by distance — but `relativePos` is set in `Rival.Update` (DataStructures.cs:113), not by distance. If two rivals are ahead at different distances, the slower of the two isn't necessarily selected.

`FirstOrDefault` over `IEnumerable<Rival>` where `Brain.Rivals` is `List<Rival>` returns index 0, not the closest. There's no explicit "sort by distance" call before this. Make it `Brain.Rivals.Where(...).OrderBy(r => r.Distance).FirstOrDefault()` or expose `ClosestRivalAhead`.

### 7.10 Avoidance uses car model length for the buffer

`Rival.BoundingBoxTotal.Y` (DataStructures.cs:119) is `|Model.GetDimensions().Y / 2| + ...` — i.e. car-length/2. But `me.VehicleData.BoundingBox` is from `GetDirectionalBoundingBox` (ARS.cs:4428) which interpolates from width to length based on the angle between forward and velocity. The combined length buffer is therefore the sum of two very different things. The Racer's `carHalfWidth = VehicleData.BoundingBox * 0.5f` (line 272) is then half of that interpolated value. The semantics of `BoundingBoxTotal.Y` as "half-length ahead" is correct only when the car is moving forward — when sliding, it's somewhere between length and width.

### 7.11 `Rival.DirectionDiff` uses the wrong up vector

`DataStructures.cs:155`:
```csharp
DirectionDiff = Vector3.SignedAngle(me.Car.Velocity, RivalRacer.Car.Velocity, me.Car.UpVector);
```
`me.Car.UpVector` flips during stunts/rolls. The angle measured around a flipping axis is nonsense. Use `Vector3.WorldUp`.

### 7.12 `Racer.RunTimedCore` is round-robin scheduled with a broken interval

`OnTick` 1486–1495:
```csharp
if (GameTimeNextInLine <= Game.GameTime)
{
    int count = (int)Clamp(Racers.Count, 1, 6);
    for (int i = 0; i < count; i++)
    {
        Racers.GetRange(NextInLine, 1).FirstOrDefault()?.RunTimedCore();
        NextInLine++;
        if (NextInLine > Racers.Count - 1) NextInLine = 0;
        GameTimeNextInLine = Game.GameTime + (10 / (Racers.Count / count));
    }
}
```
For ≤6 racers this is fine: each one gets `RunTimedCore` every 10 ms (100 Hz). For >6 racers, the loop processes 6 racers in a single OnTick (which itself runs at ~16 ms ≈ 60 Hz), then waits 10 / (n/count) ms. So with n=20 and count=6:
- Step inside: `GameTimeNextInLine = GameTime + 10/(20/6) = GameTime + 10/3 = GameTime + 3` ms (integer division).
- 6 racers processed in 0 ms, then 3 ms wait, repeat. So 6 racers per 3 ms = 2 kHz internal rate, but the outer `OnTick` is itself at ~16 ms. The intent ("spread across frames") is lost.

Worse, `GameTimeNextInLine` is updated inside the loop, so the next OnTick call *won't re-enter* if the 3 ms haven't elapsed — but in practice OnTick fires every 16 ms so the `if` is always true and the loop runs every frame.

For 20 racers, the result is: 6 racers' AI is computed every frame, but the round-robin only rotates one slot per frame, so each racer is processed every 20/6 ≈ 3.3 frames ≈ 55 ms. That's 18 Hz. The math works, but the *spacing* the comment claims ("spread evenly across 6 racers") is illusory — it depends on the integer-divide that wasn't intentional.

**Fix:** Replace with `NextInLine = (NextInLine + 1) % Racers.Count;` and process a fixed slice per frame (e.g. `Racers.Count / 6` per frame, fractional accumulation in a remainder counter).

### 7.13 `DrawStuff` has duplicate code paths

Lines 1030–1087 (AI branch) and 1088–1106 (Player branch) repeat the same `if (showTrack && Brain.Corner.Valid && Lap > 0)` chevron block — same three `DrawMarker` calls, only the side differs. Extract to a helper `DrawCornerChevrons(CornerPoint c)`.

### 7.14 `FollowLaneTrail` and `RawFollowLaneTrail` are duplicates

`Racer.cs:92–93` declares two lists; both are appended identically with `laneOffset = 0` (lines 1123–1124). The comment at 1120–1122 says "restore lane-offset trail when racing line bias is added" — the lane offset is zero because there's no bias yet. Until that feature returns, `RawFollowLaneTrail` is dead. Either delete it or actually differentiate (e.g. show the racing line with bias in one, the heading-error steering vector in the other).

### 7.15 `DrawInputTrails` uses car length to size the chevron

`Racer.cs:1200`:
```csharp
float dimension = Car.Model.GetDimensions().Y + 1f;
Vector3 chevronScale = new Vector3(dimension / 2f, dimension / 4f, -(dimension / 2f));
```
The chevron is sized from car length, not from `input` value. Input magnitude only colors the chevron. A trail of full-throttle input produces the same-sized chevrons as a trail of zero input. The Y scale is set to `dimension/4` and Z to `-(dimension/2)` (negative scale, which flips the marker — the chevron points down on the ground). The intent is unclear; this likely wants to be scaled by `|input|` so brake trails look bigger than coast trails.

### 7.16 `PID` exists but is unused

`PID` class (ARS.cs:58–177) is referenced exactly once — by `Racer.HeadingPID` which is never updated. Either wire it into `SteerTrack` or remove the class.

### 7.17 `VehicleControl` has stale fields

`BrakeStabilityStrat` (DataStructures.cs:17) is referenced from `Corner.stabilityStrat` (line 219) but never set anywhere. `MaxThrottle` (Racer.cs:172) is read but only adjusted by `+ 2 * TickScale` (line 654). `HandBrakeTime` (line 176) and `ThrottleOffset` (line 171) are read but only one is written. Audit field-by-field for what is read vs written.

### 7.18 Magic numbers with no constants

| Location | Constant | Comment |
|---|---|---|
| Racer.cs:466 | `2m/s` open rate | "slowly open at 2m/s" — but multiplied by `TickScale` so it's actually 2 m/s × 0.001 × `TimeSinceLastCoreTick` ms — could overshoot at 200 ms tick. |
| Racer.cs:491 | `2f` ↔ `0.25f` aggro buffer | "0 aggro = 2m gap, 100 aggro = 0.25m gap" — magic numbers with no central tuning file. |
| Racer.cs:521 | `1f` in `carTotalWidth` | `carHalfWidth * 2f + 1f` — "must be 1 m clearance" but no comment. |
| Racer.cs:813 | `2.0f` allowed wheelspin | "Allowed wheelspin = 2.0 + aggression offset" — no comment explaining why 2.0. |
| Racer.cs:1075 | `TrackWide * 2.5f` chevron scale | |
| ARS.cs:599 | `* 1.3f` engine top speed cap | "Cars can surpass defined engine top speed in V" — unexplained 1.3. |
| ARS.cs:4792 | `* 0.5f` decel safety | "90% of max decel as safety margin" — but `0.5` is not 0.9. |
| ARS.cs:4792 | `4` multiplier on braking ability | "brakingAbility * 4" — no source. |
| ARS.cs:4792 | `10f` in `(c.Node - c.LengthStart) - r.CurrentTrackPoint.Node - 10f` | "10m safety" but Racer memory says "30m safety". |
| Racer.cs:300 | `2.0f` in `map(speedMps, 10f, 50f, 10f, 2f)` | recoveryDeg magnitude — asymmetric. |
| Racer.cs:520 | `1.5f` hysteresis | none, no hysteresis at all. |

A `Tuning` static class (or a per-rider `Racer.Tuning` struct) would centralize these.

---

## 8. Route / track loading

### 8.1 `LoadTrack` is 200 lines and does 7 things

Lines 3724–3914:
1. XML parse safety check.
2. Pre-existing prop deletion.
3. Object/Prop deserialization (lines 3752–3833).
4. Route point deserialization with width clamping (lines 3844–3880).
5. `GenerateRouteInfo()` (line 3883).
6. `SpawnTrackLimits` (line 3892).
7. Camera / fade / player position (lines 3895–3897).

Split into:
- `RouteXml.Load(XmlDocument)` → returns `RouteData { List<TrackPoint> Points, List<CornerPoint> Corners, Dictionary<int,float> WideDict }`.
- `PropXml.Instantiate(XmlElement)` → returns `Prop`.
- `TrackLoader.Load(RouteData, IPropFactory)` — orchestrates, handles fades.

### 8.2 `GenerateRouteInfo` is a 280-line cliff

Lines 3917–4200. It does:
- Fills `TrackPoints` and `CornerPoints` from `Path`.
- Computes per-node curve radius and direction.
- Marks key corners.
- Computes per-key-corner span.
- Resolves overlapping key corners.
- **Solves an apex-anchored quadratic Bézier** for racing line (lines 4086–4194) with up to 300 attempts of factor solving.

The Bézier solver alone is 100 lines and has 11 named tuning constants (lines 4094–4104). The logic is correct but should live in `RacingLineSolver` with a clear input/output contract:
```csharp
public static class RacingLineSolver {
    public static Dictionary<int, float> ComputeLaneBias(
        List<TrackPoint> points, List<CornerPoint> keyCorners);
}
```

### 8.3 `Bezier2` is a linear lerp

`ARS.cs:4721`:
```csharp
public static Vector3 Bezier2(Vector3 Start, Vector3 End, float t)
{
    return (((1 - t) * (1 - t)) * Start) + (2 * t * (1 - t) * Vector3.Zero) + ((t * t) * End);
}
```
The middle term is `Vector3.Zero` — so the function reduces to:
```csharp
(1-t)² * Start + t² * End
```
That is **not** a quadratic Bézier. A real quadratic Bézier is `(1-t)²·P0 + 2t(1-t)·P1 + t²·P2`. The middle control point is missing entirely. The "curve" generated by `GenerateBezier` (which calls `Bezier2`) is therefore not the curve the comments imply.

The function is also used inside `GenerateRouteInfo`'s apex solver — so the racing-line math is **silently using a different curve than the author thought**.

**Fix:** add a real `Bezier2(Vector3 a, Vector3 b, Vector3 c, float t)` (a.k.a. `QuadraticBezier`, which is already defined at line 1977 — **duplicated**) and use it consistently.

### 8.4 `QuadraticBezier` is defined twice

- `ARS.cs:1977`: `public static Vector3 QuadraticBezier(Vector3 a, Vector3 b, Vector3 c, float t)` — the correct version.
- `ARS.cs:4721`: `public static Vector3 Bezier2(Vector3 Start, Vector3 End, float t)` — the broken version.

Two names for the same concept, one of which is wrong. Use one (`QuadraticBezier`) and delete `Bezier2`.

### 8.5 `DrawPath` and `DrawSection` are 95% identical

`DrawPath` is 111 lines (2941–3051), `DrawSection` is 94 lines (3054–3147). The only differences:
- color (Blue vs Green in some blocks)
- `ph % 5` vs `ph % 6`
- a single `if (IsClose)` block in `DrawPath`
- a few `DrawLine` calls in `DrawSection` that aren't in `DrawPath`

Extract a single `DrawRouteNodes(List<Vector3> nodes, Dictionary<int,float> wide, DrawRouteMode mode)` parameterized by color and density.

### 8.6 `SpawnTrackLimits` is mostly dead code

`ARS.cs:2658–2931` is called from `LoadTrack`. The real work is:
- Laying out `GridPositions` (lines 2754–2785).
- The flares at start/finish lines (lines 2674–2730).
- One "Track stats" UI notify (line 2930).

Everything else (lines 2731–2741, 2743–2752, 2788–2896) is either literal commented-out code or vestigial — `barriers`, `terrain`, `dd` (delta-delta) counters that are never used after the comment block was killed.

`TrackLimits.Add(gate)` then tracks the prop, but the prop spawn loop is dead. The only "TrackLimits" that actually exist are the two flares per start/finish.

**Fix:** reduce `SpawnTrackLimits` to a `BuildGridPositions` + `BuildStartFinishFlares`.

### 8.7 `FlareFX` is never cleaned up except in `OnAbort`

The list is appended to in `AttachFlare` and cleared in `OnTick` if not 0. The actual `STOP_PARTICLE_FX_LOOPED` is in `OnAbort` (line 4850) and `CleanEverything` (line 1084). Between races, the same flares are re-created and the list grows. Track which prop owns which FX and stop them on prop delete.

### 8.8 `WideDict` indexing assumptions

`SpawnTrackLimits` reads `WideDict[0]` (lines 2683, 2691, 2715, 2723) without checking existence. `LoadTrack` always adds node 0 first, but defensive coding should `WideDict.TryGetValue(0, out var w)`. Same in `SaveRoute` (line 3588).

### 8.9 `1 == 2` in the `prop_mp_repair_01` block

`ARS.cs:3805`: `if (hash == Game.GenerateHash("prop_mp_repair_01") && 1 == 2)` — this is a 30-line block of "Garage stuff, never used" that the original author tried to kill with `1 == 2`. Just delete it.

### 8.10 `LoadTrack` mutates thread culture

`ARS.cs:3750`: `Thread.CurrentThread.CurrentCulture = CultureInfo.GetCultureInfo("en-US");`

This is a side effect on the entire thread that will affect every subsequent XML/parse on that thread. It's also done again in `LoadSettings` (line 4893). Since SHVDN's `Script` is single-threaded, this is "fine" but the smell is wrong — it should be a `using` block with `CultureInfo` and `CultureInfo.InvariantCulture` passed to `XmlDocument.Load(string)` or used to format numbers via `ToString(CultureInfo.InvariantCulture)` when serializing (which it isn't — `Math.Round(v.X, 2).ToString()` uses the thread culture).

**Better:** Use `XmlDocument` and pass floats through `ToString("F2", CultureInfo.InvariantCulture)`, then replace `,` with `.` if you really need to keep the decimal-point format. (That itself is a smell — use invariant culture end-to-end.)

### 8.11 `Info.InnerText.Replace(",", ".")` is everywhere

The XML writer uses `Math.Round(x, 2).ToString()` which on a European locale yields `"1,23"`. The code then `Replace(",", ".")` to keep the file locale-stable. This is 19 occurrences in `UpdateRoute` and `SaveRoute` alone. A single `FormatFloat(float f)` helper that does `f.ToString("0.00", CultureInfo.InvariantCulture)` removes all of them.

---

## 9. Memory offsets

The pattern-based offset learning (`SetSteerInput`, `SetSteerAngle`, `SetThrottle`, `SetBrakes`, `GetWheelsPtr`, `GetHandlingPtr`, `GetSteerLock`, `GetTRCurveLat`, `GetDownforce`, `GetHandlingFlags`, `GetModelFlags`) is a 700-line tightrope walk across `ARS.cs:612–5122`. Observations:

- All offsets are read at runtime the first time the function is called, then cached in a `static ulong`. The pattern is duplicated 10+ times.
- `FindPattern` scans the entire `.exe` memory. If `LogLevel` is set to `Info`, you'll spam the log once per offset discovered.
- The "learned" offsets are not version-checked. If a GTA update shifts the struct layout, the mod will silently write to the wrong memory and likely crash.
- `MemoryOffsets.ini` is read in `LoadSettings` to pre-load the offsets from a file (line 4930). If both the file and the learned offset are present, the file wins, but there's no warning that the file overrides the learned one.
- `SetSteerInput` (line 638) and `GetSteerInput` (line 684) use a different cached offset (`steeroffset`) than `SetSteerAngle` (uses `steerAngle`, set as `steerAngle = *(uint*)(addr + 6) + 8`). The two functions are confused: the `steeroffset` is set in `SetSteerInput` but `Racer` calls `ARS.SetSteerAngle(Car, 0.5f)` in its constructor (line 169), so `steeroffset` is never read. The "steer" native writes to the right field but the comment in `SetSteerAngle` says "Learned the steer offset" while it learned the steer-angle offset. The two fields are at different addresses.

**Refactor:**
```csharp
internal static class NativeMemory {
    private static ulong _steerInputOffset, _steerAngleOffset, _throttleOffset, _brakeOffset, _handlingPtr, _wheelsPtr;
    public static unsafe void SetSteerInput(Vehicle v, float value);
    public static unsafe void SetSteerAngle(Vehicle v, float value);
    public static unsafe float GetSteerInput(Vehicle v);
    public static unsafe void SetThrottle(Vehicle v, float value);
    public static unsafe void SetBrake(Vehicle v, float value);
    public static unsafe IntPtr GetHandlingPtr(Vehicle v);
    public static unsafe int GetNumWheels(Vehicle v);
    public static unsafe List<IntPtr> GetWheelPtrs(Vehicle v);
}
```
With one `LearnOffsets(string iniPath = null)` method, called once at startup.

### 9.1 Three "wheel" helpers are near-duplicates

`GetWheelsPower`, `GetWheelInternalDownforceMod`, `GetMoreShit`, `GetWheelsGrip`, `GetWheelsWetgrip`, `GetWheelsMaxWheelspin`, `GetWheelsAvgWheelspin`, `GetWheelSkidmark`, `GetWheelSlippage` are 9 functions (lines 4491–4651) that all do:
```csharp
foreach (var wheel in GetWheelPtrs(handle))
    yield *((float*)(wheel + offset));
```
They differ only in the offset and the aggregation. Replace with:
```csharp
public static List<float> ReadWheelFloats(Vehicle v, uint offset, WheelAggregate agg = WheelAggregate.None);
public static float ReadWheelFloat(Vehicle v, uint offset, WheelAggregate agg = WheelAggregate.MaxAbs);
```

### 9.2 `SetGearRatio` is private and unused

`ARS.cs:5132` is a private method that's never called.

### 9.3 `SetDefMultiplier` is unused

`ARS.cs:5123` is `public static`, never called.

---

## 10. Settings & configuration

`ScriptSettings.GetValue<T>(section, key, default)` is called 20 times. Each call repeats a string-section string-key pair. Sample:

```csharp
ARS.DevSettingsFile.GetValue<int>("RACERS", "AIRacerAutofix", 1)        // Racer.cs:143
ARS.DevSettingsFile.GetValue<int>("RACERS", "TimeoutSeconds", 30)        // ARS.cs:1510
ARS.DevSettingsFile.GetValue<int>("RACERS", "GridSorting", "Power")      // ARS.cs:2432
ARS.DevSettingsFile.GetValue<int>("RACERS", "AITuningLevel", 1)         // ARS.cs:2549
ARS.DevSettingsFile.GetValue<bool>("GENERAL", "LoadAtStart", true)      // ARS.cs:1307
ARS.DevSettingsFile.GetValue<bool>("GENERAL", "Hotkeys", true)          // ARS.cs:1408
ARS.DevSettingsFile.GetValue("CREATOR_DEFAULTS", "TracksideModel", ...) // ARS.cs:3504
ARS.SettingsFile.GetValue("GENERAL_SETTINGS", "Laps", 5)                 // 7+ places
ARS.SettingsFile.GetValue("CATCHUP", "OnlyLoners", true)                // ARS.cs:869
```

Worse, `ARS.DevSettingsFile` is *also* the source of logging level (`Log(LogImportance i, ...)` at line 4950) and of the freecam behavior (`ARS.DevSettingsFile.GetValue<bool>("TRACK", "SpawnTracksideProps", true)` at line 2740) — so a missing Developer Settings file silently changes behavior across the mod.

**Refactor:** a typed settings façade:
```csharp
public sealed class Settings {
    public ScriptSettings Raw { get; }
    public T Get<T>(string section, string key, T fallback);
    public string GetStr(string section, string key, string fallback = null);
    public bool GetBool(string section, string key, bool fallback = false);
    public int GetInt(string section, string key, int fallback = 0);
    public float GetFloat(string section, string key, float fallback = 0f);
    public TEnum GetEnum<TEnum>(string section, string key, TEnum fallback) where TEnum : struct;
}
```
At minimum, move the magic strings into `const string` declarations at the top of each file so a typo in the key name fails at compile time when the strings are concatenated via a const expression.

### 10.1 `LoadSettings` has triple `if File.Exists … else Notify` blocks

Three nearly-identical blocks (lines 4896–4925) for `Options.ini`, `Developer Settings.ini`, `MemoryOffsets.ini`. Extract a `TryLoad(string path, out ScriptSettings file)` helper.

### 10.2 `SettingsFile.GetValue("CATCHUP", "OnlyBehindPlayer", true)` mixed with bool

Line 898. The default value `true` is the third arg, and the type is `bool`, but the code at line 871 calls `GetValue("CATCHUP", "CatchupSpeed", 100)` with `int` 100. SHVDN's `ScriptSettings` infers type from the default — so both calls work, but you have to read the default value to know the type. Add a typed wrapper as above.

---

## 11. Code that lies

### 11.1 `SpeedVectorGlobal` / `Local` updated by `UpdateTickData` are different

`UpdateTickData` (Racer.cs:819) sets both:
```csharp
VehicleData.SpeedVectorGlobal = cSpeed;            // global
VehicleData.SpeedVectorLocal = Function.Call<Vector3>(Hash.GET_ENTITY_SPEED_VECTOR, Car, true); // local
```
But the snapshot to `LastSpeed` is also `cSpeed` (global), and `AccelerationVector` is built from `cSpeed - LastSpeed / dt` (global). So acceleration is computed in global coordinates but the UI displays `avgGs` from `AccelerationVector` — which is global. Most consumers want local. Pick one and stick with it.

### 11.2 `BrakeStabilityStrat` exists but is never assigned

Defined at `DataStructures.cs:17`, stored on `Corner.stabilityStrat` (line 219), but `Invalid` is the only value it ever holds and the code never checks it.

### 11.3 `EngineTopSpeed(v) / 0.75f` — what is 0.75?

`ARS.cs:583`. The 0.75 is "to convert from in-game m/s to real m/s". It's not a unit conversion — it's a 25% margin. No comment, no name. A `const float EngineTopSpeedCalibration = 0.75f;` with a comment would help.

### 11.4 `Brain.intention.Speed ≤ EngineTopSpeed(Car) * 1.3f` is a magic cap

`Racer.cs:599`. The 1.3 means the AI is allowed to be 30% faster than the engine's measured top speed. Combined with the 0.75 calibration, the effective cap is `measuredTopSpeed × 1.3 / 0.75 ≈ 1.73 × measuredTopSpeed`. That number should be `Brain.intention.MaxSpeed` from the start of the AI; the cap is doing a job the cap should already do.

### 11.5 `Car.Velocity.Length() + 0.01f` in steering limiter

`Racer.cs:537`. The 0.01f is to avoid div-by-zero, but for a car stopped at the grid that's a 100× error in the formula. The 1° floor (line 538) papers over the bug, but only because the angle-to-rad conversion happens to be small at low speeds. A `Math.Max(speed, MinSpeedForSteering)` would be both safer and faster.

### 11.6 `if (Controls handled)` checks reference `0 == 1`

No occurrence found. Just noting that `1 == 1` is the inverse lie.

### 11.7 `FreeCamRotation` is declared, never used

`ARS.cs:790`. Assigning to it would do nothing.

### 11.8 `TracjectoryProjectionSeconds` (sic) is set to 1 and never read

`ARS.cs:184`. Misspelling + dead.

### 11.9 `MiniaturizedPath` is built but its only caller is commented out

`ARS.cs:1195` declares the list; `DrawMiniaturizedPath` (line 1196) is called from a commented-out site at line 1392. The list grows, the renderer is unreferenced, and there's no leak because the list is local to the draw. But it's still dead.

### 11.10 `MiniMap` is referenced but never declared

The commented-out call at line 1392 references `MiniMap`, which is a vector that doesn't exist in the codebase. If you uncomment, the code won't compile.

### 11.11 `SetSPLVisibility` iterates every prop in the world

`ARS.cs:1677`:
```csharp
foreach (Prop p in World.GetAllProps()) if (p.Model == "prop_mp_max_out_lrg") ...
```
`World.GetAllProps()` is the heaviest enumerator in SHVDN — it allocates and walks every loaded prop. Called from menu cancel + every Load. Cache the prop list once or use `World.GetClosestProp` (doesn't exist — would need your own cache).

### 11.12 `Notify` is defined but unused

`ARS.cs:3164` defines `Notify(string, float)` which is never called. Use `UI.Notify`.

### 11.13 `ParsedEnum` is defined but unused

`ARS.cs:801`. The menu gets names via `GetOptionName` which calls `option.ToString()` directly.

### 11.14 `OffsetByAngle` and `Project` are unused

`ARS.cs:4799` and `ARS.cs:6262`. Both have body code; neither has a caller.

### 11.15 `GetDirVsHeading` doesn't exist

Comment at line 1155 references `GetDirVsHeading(v, 1)` — function doesn't exist in the codebase. The comment is also commented out.

### 11.16 `LoadDriver` allocates a `List<dynamic> info` it never uses

`ARS.cs:5228` declares `List<dynamic> info` and adds `XMLFile` to it, but the function returns the XML file directly. The list is dead.

---

## 12. Concurrency

### 12.1 `Task.Run` from a SHVDN script

`ARS.cs:300`:
```csharp
LoadScriptTask = Task.Run(() =>
{
    FillKnownDisciplines(false);
    FillKnownTracks(false);
    ReFilterKnownTracks(TrackFilter);
});
```
SHVDN is single-threaded for the GTA scripting API. Calling `new Model(model)` (line 539) and `Directory.GetDirectories(...)` (line 522) from a `Task.Run` worker thread may or may not crash — SHVDN's wrapper classes hold no synchronization, and the model hash table is global. The pattern works in practice because the calls are mostly file-I/O, but it's a latent bug. `FillKnownDisciplines` and `FillKnownTracks` already do `Yield()` inside, so they *expect* to be on the script thread. The `Task.Run` defeats that.

**Fix:** Either keep everything on the script thread (drop `Task.Run`, just call them synchronously and rely on `Yield()`) or do only the file enumeration on the worker and dispatch the model-loading back to the script thread via a queue.

### 12.2 `LoadScriptTask.Exception?.GetBaseException()` swallows first-chance exceptions

`ARS.cs:316`. `Task.Exception` is an `AggregateException`. Using `GetBaseException()` unwraps, but the original stack is still in `InnerExceptions`. Log the full thing for debuggability.

### 12.3 `Racer.Random` is per-instance and not thread-safe

`Racer.cs:98`: `Random Random = new Random();`. Used by `Rival.Update`? No — `Rival` is in `DataStructures.cs` and uses no random. The `Racer.Random` is also unused. The only RNG in `Racer` is `ARS.GetRandomInt(...)` which uses `static Random rnd` (line 4825). The two RNGs are disconnected and the per-instance one is dead.

### 12.4 `static Random rnd` is shared

If anything in ARS ever moved to a background thread, this `Random` (line 4825) is not thread-safe. Move to `[ThreadStatic]` or use `RandomNumberGenerator.Create()` for cryptographic, or `Random.Shared` if you can move to .NET 6+. (You can't, because SHVDN2 targets .NET 4.8 — keep the [ThreadStatic].)

---

## 13. Performance hot spots

### 13.1 `Racer.UpdateFollowTrack` rebuilds `LookAheads` every AI tick

`Racer.cs:1253` clears the dictionary and re-adds 7 entries each call. With 6 racers at 100 Hz, that's 600 dict-ops/s — trivial. But the dict is overkill; replace with 7 fields.

### 13.2 `FindCustomProps` is O(Props × Path.Count)

`ARS.cs:3306`:
```csharp
foreach (Prop propchecked in World.GetAllProps().ToList())
    ...
    Vector3 d = Path.OrderBy(v => propchecked.Position.DistanceTo(v)).ToList().First();
    for (int i = 0; i < Path.Count; i++) if (d == Path[i]) if (WideDict.ContainsKey(i)) maxDist = WideDict[i] + 200f;
```
For 5,000 path nodes and 10,000 props, this is 50M distance calculations per call. It's called from `UpdateRoute(true, true, true)` and inside `SaveRoute`. For a typical 1 km track with 5,000 nodes and 5,000 nearby props, that's 25M ops — about 200 ms on a desktop. Add a `KDTree` of path nodes (or a bucketed grid) for O(log n) nearest.

### 13.3 `OnTick` calls `World.GetAllVehicles().ToList()` every 200 ms

`ARS.cs:1519`. Use a `HashSet<Vehicle>` of racers to subtract, or only do this when a new racer is added.

### 13.4 `World.GetAllProps()` from `SetSPLVisibility`

`ARS.cs:1674` and `1679` — both iterate every prop in the world. See §11.11.

### 13.5 `Racers.GetRange(NextInLine, 1).FirstOrDefault()?.RunTimedCore();`

`ARS.cs:1491` allocates a `List<Racer>` per iteration. Use `Racers[NextInLine]` with a null check.

### 13.6 `ARS.Racers.OrderBy(...)` in the leaderboard sort

`ARS.cs:1526, 1534, 1543, 1559, 1597` — repeated `OrderBy` and `Reverse` over the same list every 200 ms. The list is small (≤20) so this is fine, but if the grid grows to 30+, prefer one pass that bins by lap.

### 13.7 `DrawPath` and `DrawSection` walk ±50/100 nodes every frame

`ARS.cs:2947–2948, 3060–3061`. For a 5,000-node track, only 100 nodes near the player are drawn per frame — that's fine. But `DrawPath` is called every frame from `OnTick` (line 1344) regardless of whether route editor is active. The early-out is `if (routeEditMode) DrawPath(...)` — so it's only run in editor mode. Good. `DrawSection` is the same.

### 13.8 `Rival.Update` is O(rivals) per Racer per AI tick

`DataStructures.cs:113`. For 6 racers × 6 rivals × 100 Hz = 3,600 `Rival.Update` calls/s. Each does ~5 trig + 1 distance + 1 signed angle. Total ~21,600 trig ops/s. Trivial.

### 13.9 The "GenerateRouteInfo" Bézier solver runs once per `LoadTrack`

`ARS.cs:4086–4162`. For a 5,000-node track with 30 key corners, the inner loop runs 30 × 300 = 9,000 iterations worst-case, each allocating a `List<Vector3>` of `bezierSamples + 1` entries (≥24). 30 × 9,000 × 25 = 6.75M `Vector3` allocations. Allocate one `Vector3[]` per corner and reuse it.

---

## 14. Recommended refactor roadmap

The work splits naturally into three waves. None of this requires behavior changes — pure restructuring.

### Wave 1 — Quick wins (1-2 evenings, no behavior change)

| # | Task | Risk | Payoff |
|---|---|---|---|
| 1.1 | Delete `PersonalitySet.cs`, `SkillSet.cs`, the `.csproj` entries. | None | Two files gone. |
| 1.2 | Replace all 15 `1 == 1` / `1 == 2` gates with the real condition. | Low (verify each) | Removes a misleading pattern. |
| 1.3 | Delete the `#if false` block in `SpeedTrack` (Racer.cs:743–764). | None | -22 lines. |
| 1.4 | Delete `HeadingPID` (Racer.cs:35) — unused — or actually use it. | Low | -1 field. |
| 1.5 | Delete `_countersteerBlend` and its two constants (Racer.cs:109–111). | None | -3 lines. |
| 1.6 | Delete `LocalSpdLimiter`, `Traffic` (Racer.cs:47, 51). | None | -2 fields. |
| 1.7 | Delete `RiskFactorForGrip`, `RiskFactorForBrake` (Racer.cs:1621–1628). | None | -8 lines. |
| 1.8 | Delete `OvertakeLane`, `AvoidStr` (DataStructures.cs:109–110). | None | -2 fields. |
| 1.9 | Delete the pre-populated 3 `Rival()` instances in `Memory` ctor (DataStructures.cs:70–72). `UpdateRivals` overwrites them. | None | -3 lines. |
| 1.10 | Delete dead `MultiplierInTerrain` writes (Racer.cs:1558–1561) and field (ARS.cs:255). | None | -5 lines. |
| 1.11 | Delete dead `AccelerationVector` (ARS.cs:1282), `lSpeed` (1283), `GsClamp`/`directionClamp` (1290–1291), `FreeCamRotation` (790), `MiniaturizedPath`/`DrawMiniaturizedPath` (1195–1237), `TracjectoryProjectionSeconds` (184), `distToPercent` (3219), `notify` (3164), `ParsedEnum` (801), `OffsetByAngle` (4799), `Project` (6262), `LoadDriver`'s `info` list (5251), `SetDefMultiplier` (5123), `SetGearRatio` (5132), the `prop_mp_repair_01` block (3805–3831), the `1==2` "auto-detect new car" block (1638–1644). | None | ~200 lines. |
| 1.12 | Add `Log(LogImportance.Error, "method: " + ex.Message)` to the 8 empty `catch (Exception) { }` in `Racer.cs`. | None | Bug visibility. |
| 1.13 | Add an invariant-culture `FormatFloat` helper. Replace 19+ `Replace(",", ".")` calls. | None | Locale safety. |
| 1.14 | Replace the broken `Bezier2` with a wrapper that calls the existing `QuadraticBezier` (or fix the formula and call it correctly). | Medium (verify curve shape) | Racing line accuracy. |
| 1.15 | Remove the `1 == 0` catchup gate (Racer.cs:867). Either restore the feature or delete the whole block. | Low | Removes dead code or a useful feature. |
| 1.16 | Fix `Rival.DirectionDiff` up vector (`Car.UpVector` → `WorldUp`). | Low | Correctness during stunts. |
| 1.17 | Make `_avoidLiftOff` pick the slowest ahead rival by distance. | Low | Correctness when >1 rival ahead. |
| 1.18 | In `OnTick`, the `if (1 == 1 \|\| !Brain.Corner.Valid \|\| ...)` "rocket boost" gate (line 1372) — fix the comment, drop the `1 == 1`. | None | Clarity. |

### Wave 2 — Local refactors (3-5 evenings, no behavior change)

| # | Task | Risk | Payoff |
|---|---|---|---|
| 2.1 | Extract a `Settings` façade wrapping `ScriptSettings`. Centralize all 20 `GetValue` call sites. | Low | Single source of truth for keys. |
| 2.2 | Extract a `NativeMemory` static class consolidating the 10 offset-learning helpers and 9 wheel-read helpers. | Medium | Testability + version-resilience. |
| 2.3 | Merge `DrawPath` and `DrawSection` into one parameterized `DrawRouteNodes`. | Low | -100 lines. |
| 2.4 | Merge `FollowLaneTrail` and `RawFollowLaneTrail` until the racing-line feature returns. | Low | -30 lines. |
| 2.5 | Extract `RacingLineSolver` from `GenerateRouteInfo`. | Medium | Testability. |
| 2.6 | Extract `OnTick` into per-frame subsystems (lifecycle, AI round-robin, HUD, menu, traffic). | Medium | -200 lines from `OnTick`. |
| 2.7 | Extract `LoadTrack` into a `RouteXml` reader + a `PropXml` reader. | Medium | -100 lines. |
| 2.8 | Extract `FillCachedCandidates` into tag-parsing + filtering + dedup + shuffle. | Medium | -200 lines. |
| 2.9 | Extract a `FreecamController` class. | Low | -225 lines from `HandleFreecam`. |
| 2.10 | Extract `LoadGrid`'s nested local functions into instance methods or a `GridLoader` class. | Medium | Testability. |
| 2.11 | Extract `Racer` into 6–7 role classes (Core, Input, Steering, Speed, Rivals, Recovery, DebugDraw). | Higher | Each unit becomes testable. |
| 2.12 | Replace `Racer.LookAheads` (Dictionary) with a struct of 7 fields. | Low | Speed + clarity. |
| 2.13 | Add a `Tuning` const class for the ~50 magic numbers (avoidance buffer, wheelspin tolerance, decel safety margin, route window, …). | Low | Centralized tuning. |
| 2.14 | Round-robin AI fix: use fractional accumulator for >6 racers. | Low | Predictable AI rate. |
| 2.15 | Fix `EngineTopSpeed` / `* 1.3f` / `0.75f` confusion — single source of truth for "max velocity". | Low | Removes the magic. |
| 2.16 | Replace `if (CanWeUse(s))` with a single helper that takes a `Func<T>` and returns the result. | Low | Removes 50+ `CanWeUse` calls. |
| 2.17 | Fix `FindCustomProps` O(N×M) with a `KDTree` or grid. | Low (if grid is simple) | Save-route time drops from seconds to ms. |
| 2.18 | Remove the `1 == 2` / `if (1 == 1)` "freeze" / "airspeed" patterns from `OnTick`. | None | Removes misleading code. |

### Wave 3 — Architectural (1-2 weeks, behavior-preserving)

| # | Task | Risk | Payoff |
|---|---|---|---|
| 3.1 | Move all `static` state on `ARS` into a `GameSession` instance owned by the `Script`. Convert all `public static` helpers to instance methods on the new classes. | Higher | Single source of truth, testable. |
| 3.2 | Convert the SHVDN-`Script` into a thin entry-point that builds an `AppHost` containing the new subsystems (Route, Grid, Race, Freecam, HUD, Cheats, RouteCreator). | Higher | Layered architecture. |
| 3.3 | Replace the 4 ad-hoc XML writers (`UpdateRoute`, `SaveRoute`, `CreateVehicle`, `CreateDriver`, `CreateVehicleFromHash`) with a single `XmlDocumentWriter` (or `XmlWriter`). | Medium | Removes 600+ lines of repetitive XML building. |
| 3.4 | Replace per-call `Function.Call<...>(Hash.XXX, ...)` with a thin native-call wrapper. | Medium | Removes 107 `Function.Call` sites from the hot path. |
| 3.5 | Add a `Lock` around `LoadScriptTask` + a `[ThreadStatic]` RNG. | Low | Removes a latent crash. |
| 3.6 | Move the route creator (lines 1682–1872, 1919–1975) into a `RouteCreator` class. | Medium | -200 lines from `OnTick`. |
| 3.7 | Replace the 4 corner-related classes (`TrackPoint`, `CornerPoint`, `Corner`, `Approach`) with a single `TrackNode` class holding the data. `Corner` becomes a query over `TrackPoint`s. | Medium | Cleaner graph. |
| 3.8 | Move `GetValue<bool>`-with-magic-strings to a typed settings record per section (Roslyn source generators or just a static class with `public static int Laps = Settings.GetInt(...);`). | Low | Compile-time safety. |
| 3.9 | Add a `Racer.Update` virtual method (or strategy pattern) so the per-`Racer` AI can be swapped for a "PlayerInputPassthrough" variant — currently the player is a special-cased `Racer` whose `ProcessAI` is gated by `if (!ControlledByPlayer)`. | Medium | Removes the special case. |
| 3.10 | Convert the dozens of `1 == 2` style gates to a `FeatureFlag` system or just delete. | None | Codebase honesty. |

---

## 15. Numeric summary

| Metric | Count |
|---|---:|
| Lines (3 real files) | 8,151 |
| Public statics on `ARS` | ~80 |
| `Function.Call(` raw native calls | 107 |
| `XmlDocument`/`XmlElement`/`XmlNode` | 117 |
| `static` method/field declarations | 124 |
| `try {` blocks | 16 |
| `catch (Exception) { }` (empty body) | 8 |
| `catch` with logging only | 9 |
| `1 == 1` / `1 == 2` dead gates | 15 |
| Comment-lines that look like commented-out code (ARS only) | 193 |
| `/* … */` block markers (ARS only) | 24 |
| `TODO`/`FIXME`/`HACK` markers | 6 |
| Empty source files | 2 (`PersonalitySet.cs`, `SkillSet.cs`) |
| `Racer` ctor call sites | 4 |
| `ScriptSettings.GetValue<T>` call sites | 20 |
| `Task.Run` / `Thread.` / `Yield()` / `Script.Wait` | 28 |
| `DrawPath` + `DrawSection` near-duplication | 95% |
| `Bezier2` and `QuadraticBezier` duplicate math | 1 broken copy |
| Total methods on `ARS` class | ~120 |
| `ARS` class line count | 6,280 |
| `Racer` class line count | 1,633 |
| `DataStructures` class line count | 238 |

The codebase is a working racing mod held together by an enormous `OnTick` and a forest of `static` state. The hot path (per-frame AI for ≤6 racers) is fine in terms of cycles; the cold path (load, save, route-gen) has an O(N×M) search and is the most likely cause of any "save hangs" reports. The right refactor is to peel the mod apart in layers — config → model → service → presentation — without changing any user-visible behavior. Most of the wins in Wave 1 are mechanical and safe.
