# ARS Refactoring Audit (minimax)

Source files audited end-to-end:
- `Racer.cs` (1633 lines)
- `AutosportRacingSystem.cs` (6280 lines)
- `DataStructures.cs` (238 lines)

Nothing below changes runtime behavior unless explicitly placed in the Appendix.

---

## GOAL 1 — Simplify the code, keeping the behavior

### 1.1 Dead enums and types to delete

- `enum Decision { LateBrake, Flatout, NoOvertake, FastCorner, EarlyExit, AttackInside }` (`AutosportRacingSystem.cs:25`) — no symbol in the three files references `Decision.`; enum is dead.
- `enum Mistake { ForgetSteeringLimiter, ForgetTCS, ForgetABS, ForgetCounterSteer, ForgetSpinoutPrevention }` (`AutosportRacingSystem.cs:29`) — never referenced. Dead.
- `enum OptionValues { ShowAggression }` (`AutosportRacingSystem.cs:44`) — never referenced (show-aggro state lives in `Options.ShowAggro` / `OptionValuesList`). Dead.
- `enum CameraTransition { None, ToAir, AirToAir, AirToPlayer }` (`AutosportRacingSystem.cs:54`) — never referenced. Dead.
- `enum DebugDisplay { None, Inputs, Speed, Positioning, PropEdit }` (`AutosportRacingSystem.cs:50`) — used only by `DebugVisual`/comparison against `PropEdit`; could keep for typing but the only live member is `PropEdit`. Note in passing.
- `enum BrakeStabilityStrat { Invalid, Checking, Checked }` (`DataStructures.cs:17`) — only used as the type of `Corner.stabilityStrat`, which itself is never read (see 1.2). Dead once 1.2 is applied.

### 1.2 Dead fields and never-read members

`Racer.cs`:
- `public Dictionary<…,TrackPoint> LookAheads` keep; `public List<Vehicle> Traffic` (`Racer.cs:47`) — written never, read never. Delete.
- `public float MaxLeftLane`, `MaxRightLane` (`Racer.cs:49–50`) — never read or written.
- `public int LocalSpdLimiter` (`Racer.cs:51`) — never read or written.
- `public List<string> DebugText` and `public void AddDebugText(string)` (`Racer.cs:79, 1326`) — declared and exposed, but `AddDebugText` is never called from any of the three files and `DebugText` is never read. Dead.
- `PID HeadingPID = new PID(1.0f, 0.6f, 0);` (`Racer.cs:35`) — declared and `HeadingPID.SetValue(0f)` is called once in `Launch()`, but `Update`/`SetTarget`/`GetValue`/`IsClose`/root shared are never called, and PID output is never consumed (steering uses its own PD in `SteerTrack`). Delete the field plus its launch line.
- `float TorqueMult = 1.0f;` (`Racer.cs:97`) — written in `ProcessTick`, never read.
- `float DistToOutside(Vector3)` / `float DistToInside(Vector3)` (`Racer.cs:546–556`) — `DistToInside` is never called; `DistToOutside` is only referenced inside the `1==2` block at `SpeedTrack` (`Racer.cs:766`). Both die once 1.4 is applied.
- `public float RiskFactorForGrip()` / `public float RiskFactorForBrake()` (`Racer.cs:1621–1628`) — both return `1f` and are never called.
- `void UpdateFollowLaneTrail()`, `Vector3 GetFollowLaneTrailPoint(...)`, `Vector3 GetRawFollowLaneTrailPoint(...)`, `void DrawFollowLaneTrail()`, `void DrawRawFollowLaneTrail()` (`Racer.cs:1108–1181`) — `UpdateFollowLaneTrail` is never invoked; both trail-draw methods are never invoked; `FollowLaneTrail`/`RawFollowLaneTrail`/`LastFollowLaneTrailNode` are only touched by these dead methods. The whole trail feature is dormant (its lane offsets are hardcoded `0f`). Delete the methods and their backing fields.
- `int LastFollowLaneTrailNode = -1;` is also redundant with the above.

`AutosportRacingSystem.cs`:
- `public static float TracjectoryProjectionSeconds = 1;` (`:184`) — never read.
- `bool IsDroneMode = true;` — live (used for freecam). Keep.
- `Dictionary<int, int> DistToPercent` (`:3219`) — never read.
- `List<Vector3> AccelerationVector` and `Vector3 lSpeed` instance fields on `ARS` (`:1282–1283`) — never read or written (Racer has its own). Delete.
- `Vector3 GsClamp = new Vector3(1,1,1f);` and `Vector3 directionClamp = new Vector3(1,1,1f);` (`:1290–1291`) — never read.
- `Vehicle debugTrailer;` and `Dictionary<int,Vector3> ExhaustOffsets;` (`:1102–1103`) — `HandlePlayerDebugStuff` is the only user, and that method is only invoked from the commented-out line `//HandlePlayerDebugStuff(v);` in `OnTick`. All three are dead.
- `HandlePlayerDebugStuff(Vehicle v)` (`:1104–1179`) — entry point unreachable (commented out at `:1303`). Delete.
- `void HandleImmersiveJoins()` (`:1250–1279`) and `Dictionary<Vector3,string> NeabyImmersiveJoins` (`:1248`) plus `secInteval` (`:1247`) — the only call site (`OnTick:1304`) is `//HandleImmersiveJoins();`. Even `ImmersiveJoins` populates only for that path; `ImmenseJoins` should be inspected before deletion, but since the call is dead the whole immersive-join cluster is dormant. Dead.
- `List<Vector3> MiniaturizedPath` and `void DrawMiniaturizedPath(Vector3)` (`:1195–1237`) — only invoked from the commented `//if (Path.Count > 20 && MiniMap != Vector3.Zero) DrawMiniaturizedPath(MiniMap);` (`:1392`). Dead.
- `void PlaceOnGround(Prop p) { }` (`:2648–2651`) — empty stub. Delete.
- `void OffsetByAngle(...)` (`:4799–4823`) — never called.
- `public static float LaneSelectionApproachCorner(Racer, Corner, bool)` (`:4732–4735`) — returns `0f`, never called.
- `public static float LerpDelta(...)` (`:768–774`) — never called.
- `public static float Lerp(float a, float b, float t)` (`:1239–1242`) — never called anywhere in the project; `Vector3.Lerp` is used instead.
- `public static float GetColorFromRedYellowGreenGradient(float)` (`:1985–1994`) — never called.
- `public static Color GradientAtoB(...)` (`:1996–2006`) — never called (only `GradientAtoBtoC` is used).
- `static public float mapGamma(...)` (`:594–603`) — never called.
- `public static bool IsBitSet(int, int)` (`:3301–3304`) — never called.
- `public static bool IsBetweenRange(float, float, float)` (`:6258–6261`) — never called.
- `public static Vector3 GetXfromPosInDirection(...)` (`:4756–4762`) — never called.
- `public static Vector3 LerpByDistance(Vector3 A, Vector3 B, float x)` (`:4751–4755`) — never called.
- `public static Vector3 RotateDir(Vector3 d, float angle, Vector3 axis)` (`:567–570`) — never called.
- `public static bool IsRoadBusy(Vector3, int)` (`:4763–4778`) — never called.
- `public float GetRoadHeading(...)`, `public float GetRoadOutOfBoundsX(...)` (`:4654–4688`) — never called.
- `public bool IsAhead(...)`, `public bool HasArrived(...)` (`:4874–4882`) — never called.
- `static public void DrawDirectionalBoundingBox(Entity, float)` (`:4434–4441`) — never called.
- `unsafe private void SetGearRatio(...)` (`:5132–5141`) — never called.
- `public static void SetDefMultiplier(Vehicle, float)` (`:5123–5131`) — never called.
- `public static unsafe int GetModelFlags(Vehicle)` (`:5101–5111`) — never called.
- `public static unsafe float GetTRCurveMax(Vehicle)` (`:5066–5076`) — never called (only `GetTRCurveLat` is).
- `static public unsafe List<float> GetWheelsPower(Vehicle)` (`:4491–4502`) — never called.
- `static public unsafe List<float> GetWheelInternalDownforceMod(Vehicle)` (`:4505–4516`) — only used by commented UI.ShowSubtitle at `:1175`. Dead.
- `static public unsafe List<float> GetMoreShit(Vehicle)` (`:4517–4528`) — never called (profane name; also delete).
- `static public unsafe List<float> GetWheelsWetgrip(Vehicle)` (`:4542–4553`) — never called.
- `static public unsafe List<float> GetWheelSkidmark(Vehicle)` (`:4579–4591`) — never called.
- `static public unsafe float GetWheelsAvgWheelspin(Vehicle)` (`:4567–4578`) — never called.
- `static public unsafe List<float> GetWheelSlippage(Vehicle)` (`:4640–4651`) — never called.
- `static public void DrawStats(Racer)` and the second `DrawStats(...)` overload (`:4593–4638`) — never called.
- `public static float GetDownforceGsAtSpeed(Racer, float)` (`:5021–5036`) — never called.
- `void WarnPlayer(string, string, string)` (`:4955–4960`) — never called.
- `void Notify(string text, float timeMult)` (`:3164–3171`) — `UI.Notify` is used directly elsewhere; this overload is never called.
- `public XmlDocument LoadDriver(string DriverName)` (`:5228–5253`) — called from `FillCachedCandidates`'s `CreateDriverPed`. Live. Keep.
- `List<dynamic> LoadVehicle(string name, Vector3 place)` (`:5364–5429`) — never called (the constructor path uses `CreateVehicle` and `LoadGrid`). Dead.

`DataStructures.cs`:
- `VehData.Understeer` — written nowhere, read nowhere.
- `VehData.CurrentDownforce` — written nowhere, read nowhere.
- `VehData.PerformanceIndex` / `TextPerformanceIndex` — written in `Initialize()`, read in `OnTick` leaderboard text. Live.
- `VehicleControl.SteerStabilityCorrection` — never read or written.
- `VehicleControl.SteerMax` — never read or written.
- `VehicleControl.FollowLane` — never read or written.
- `VehicleControl.ThrottleOffset` — never read or written.
- `VehicleControl.CurrentLockupLimiter` — never read or written.
- `Rival.OvertakeLane` — never read or written.
- `Rival.AvoidStr` — never read or written.
- `Rival.sToRear` — computed in `Update`, never read.
- `Corner.Approach` field — set with `new Approach()`, never read.
- `Corner.sToEntrance` — compared at `Racer.cs:1372` (`Brain.Corner.sToEntrance > 4`) but never assigned anywhere; it is the constant default `0f`, so the predicate is always false and the `1==1 ||` short-circuits it anyway. Field dead.
- `Corner.stabilityStrat` — written nowhere else, read nowhere.
- `Approach` class (`Valid`, `CheckedForImpediment`, `HoldDeviation`) — all three fields never read nor written outside its own constructor default. Delete the class.

### 1.3 Disabled-by-constant blocks (`1 == 1`, `1 == 2`, `1 == 0`, `#if false`)

Racer.cs:
- `SpeedTrack` block `if (Brain.Corner.Valid && 1 == 2) { … }` (`:766–781`) — dead branch; remove the whole `if`.
- `SpeedTrack` `#if false … #endif` "Steer-angle speed limiter — disabled. Kept for reference." (`:743–764`).
- `SpeedTrack` stale "Risk factor for grip… NOT active." block whose result is computed into a dead `speedAdjust` (`:784–798`) — variable never consumed. Remove.
- `ProcessTick` `if (RacePosition > ARS.catchupPos && 1 == 0)` (`:867`) — entire `catchupPos` branch (lines `:867–887`) is unreachable. Note `ARS.catchupPos` itself is still written in `RunTimedCore`/`StartRace`/`StartCoundown`, but is only consumed in dead branches — see 1.5.

AutosportRacingSystem.cs:
- `SetThrottle` `else if (1 == 1)` (`:722`) — just collapse to `else` (or remove the `if` guard).
- `SetBrakes` `else if (1 == 1)` (`:750`) — same.
- `ProcessTimedAI` `if (1 == 1 || !Brain.Corner.Valid || Brain.Corner.sToEntrance > 4)` (`:1372`) — simplify to `if (true)` ⇒ unconditional block; remove the dead alternatives.
- `HandleFreecam` `if (1 == 1)` (`:2071`, `:2083`) and the nested `if (1 == 1)` (`:2083–2120`) — unconditional wrappers.
- `DrawPath` `if (count >= countmax || 1 == 1)` (`:2966`) ⇒ unconditional; `if (1 == 1)` (`:2988`, `:3095`).
- `DrawSection` same `|| 1 == 1` (`:3075`).
- `OnTick` leaderboards: `else if (Function.Call<bool>(...) || 1 == 1)` (`:1570`) and `if (... && (Function.Call<bool>(...) || 1 == 1))` (`:1616`) — the radar-enabled OR is short-circuited to `true`; the `|| 1 == 1` collapses to unconditional and the `bool` call becomes dead. Drop the `bool` call.
- `OnTick` `if (1==2 && CanWeUse(playerVeh) && !KnownVehicleModels.Contains(...))` (`:1638`) — dead `if`. Delete the block and the `GametimerefLong` block becomes only help-message flashing; keep the help-message portion.
- `SetupRace` "Ghosting cars…" block `if (... && 1 == 2)` (`:2560–2602`) — dead.

### 1.4 Commented-out and historically-disabled code

- Long `/* */` block in `OnTick` (`:1314–1327`) encoding a debug curve plot. Delete.
- `/* void LoadAndRace(string track) { … } */` (`:2402–2419`). Delete.
- `/* float min = 0; … UI.ShowSubtitle(...); */` block (`:1314` etc.).
- `SetupRace` `/* float maxacc = 0f; foreach … r.Car.EnginePowerMultiplier = mul; */` block (`:2511–2530`). Delete.
- `LoadTrack` `//CamVerticalPlayer.Position…` and `//Function.Call(Hash.RENDER_SCRIPT_CAMS, ...)` etc. (`:3903–3912`). Delete.
- The huge `/* for (int ph = 0; …) { barriers == frecuency && ((Model)ModelOne).IsValid) … } */` block in `SpawnTrackLimits` (`:2788–2896`). Delete.
- `LoadRace` `/* … */` and trailing `//UI.Notify(h.ToString() ...)` and `// UI.ShowSubtitle` etc. throughout.
- `LoadTrack` `//if (Math.Abs(oldW) > Math.Abs(W) + 0.5f) W = oldW - 0.5f; //1` (`:3866–3867`).
- The whole garage-creation block in `LoadTrack` `if (hash == Game.GenerateHash("prop_mp_repair_01") && 1 == 2)` (`:3805–3831`) — already covered by 1.3.
- `RandomTuning` `/* veh.SetNeonLightsOn(...) */` block (`:5195–5200`).
- `PlaceCars` `/* Prop p = World.CreateProp("prop_start_grid_01", …) */` (`:2491–2496`).
- `DrawPath`/`DrawSection` hundreds of `// DrawLine(...)`, `//  World.DrawMarker(...)`, `//Quaternion.RotationAxis(...)` leftovers — delete as part of comment-removal (Goal 3) but worth enumerating here because they are dead alternative implementations.
- `OnAbort` `// protected override void Dispose(bool dispose)` and `// base.Dispose(dispose);` (`:4836, 4872`). Delete.
- Many `//Control.MaxThrottle = Math.Min(...)` (`Racer.cs:649`), `//VehicleData.CurrentMechanicalGrip += GsLoss;` (`Racer.cs:1556`), `//stabilityThrottleLimit` (`Racer.cs:649`) — comment-disabled statements. Delete.

### 1.5 Collapsible copy-paste / helpers worth extracting

- **Wheel-field readers.** `GetWheelsPower`, `GetWheelsWetgrip`, `GetWheelSkidmark`, `GetWheelsAvgWheelspin`, `GetWheelsGrip`, `GetWheelsMaxWheelspin`, `GetWheelInternalDownforceMod`, `GetMoreShit`, `GetWheelSlippage` — nine near-identical functions that differ only by `offset` and (min/avg/max) reduction. Collapse to two helpers:
  - `List<float> GetWheelFloatField(Vehicle, ulong offset)`
  - `float GetWheelFloatFieldMax(Vehicle, ulong offset)` (the only variant that returns a scalar).
- **XML track/racer tag loaders.** `GetTrackTags`, `GetTrackStartPos`, `GetRacerTags`, `GetRacerModel` repeat the same `new XmlDocument(); document.Load(path); while (document == null && pat < 1000) { ...; document.Load(path); }` pattern. The `while (document == null ...)` loops are dead — `XmlDocument.Load` either loads successfully or throws; `document` is never `null` after a successful call. Extract a single `XmlDocument LoadManifest(string path)` helper and have each tag-reader call it.
- **`DrawPath` vs `DrawSection`** (`AutosportRacingSystem.cs:2941–3051` and `:3054–3147`). The two methods share the same loop skeleton, the same `pos/oldpos/oldw/w/GetPerpendicular` plumbing and the same `if (count >= countmax || 1 == 1) { … }` wrapper. Extract a single `DrawNodeRange(nodes, widedict, start, end, drawEndCap, step)` helper; `DrawPath` and `DrawSection` collapse to two thin call sites with mode flags.
- **Hill grip siblings.** `GetHillGsLossAtCurrentTrackPoint` and `GetHillGsLossAtCurrentVelocityVector` are byte-identical except for the input vector from which `climbAngleRad` is derived (`to.Z - from.Z` vs `v.Z`). Same for `GetHillGripMultiplierAtCurrentTrackPoint` vs `GetHillGripMultiplierAtCurrentVelocityVector`. Extract one helper taking a `(from, to)` pair and have the four public methods delegate.
- **XML element writing.** `SaveRoute`, `UpdateRoute`, `CreateVehicle`, `CreateVehicleFromHash` all repeat the pattern of creating `<X>`, `<Y>`, `<Z>`, parsing floats, calling `.Replace(",", ".")`. Extract `void AppendXYZ(XmlElement parent, Vector3 v)` and `XmlElement AppendTextElement(XmlNode parent, string name, string text)`.
- **Track-corner chevron drawing.** The AI branch and the player branch of `DrawStuff` (`Racer.cs:1068–1105`) render the same three `ChevronUpx1` markers from start/apex/end nodes. Extract `void DrawCornerChevrons(CornerPoint c)`.
- **`GradientAtoBtoC`.** The `if (percentage <= 50) { ... } else { ... }` halves duplicate `ARS.map` lines; the `if/else` can collapse to a `float pct2 = (percentage <= 50) ? percentage/50 : 2 - percentage/50;` with one end of the color pair chosen. Optional polish, not high-value.
- **Lookahead lookups in `UpdateFollowTrack`.** The seven `LookAheads.Add(eLookAheads.X, ResolveLookAhead(n))` calls can become a `for` over `(eLookAheads, multiplier)` pairs, since each multiplier is a literal next to the call. The `ResolveLookahead` local is also buggy (`:1266` returns `TrackPoints[offset]` when past the end — see Appendix) but that is behavior, not simplification.

### 1.6 Other simplifications

- `VehicleControl.SteerManeuver` is set indirectly via `Control.SteerManeuver` checks in `SteerTranslateInput` but never assigned a non-zero value anywhere in the three files. It is read at `Racer.cs:668` (NaN guard), then ignored. Equivalent to dead.
- `Control.TCSThrottle` is read (`SpeedToThrottleBrake`) and `TractionControl` writes it. Live. Keep.
- `Random Random = new Random();` in `Racer.cs:98` — field shadows type name; only used in `Racer` constructor for `GetRandomInt`. The whole field is actually unused because `Racer` calls `ARS.GetRandomInt`, not its own `Random`. Delete the field.
- `Racer` constructor still calls `ARS.GetRandomInt(10, 50)` — keep, that's the static helper.
- `eLookAheads` enum also has `QuarterSec, HalfSec, ThreeQuarterSec, OneSec, OneHalfSec, TwoSec`. All used in `UpdateFollowTrack`. `SteerRef` used in `SteerTrack`. `SteerInRef` (`eLookAheads.SteerInRef`, line 44) has no usage anywhere in the three files. Delete that enum member.

---

## GOAL 2 — Rename inventory (Current → Proposed)

### `Racer.cs`

| Current | Proposed | Reason |
|---|---|---|
| `Memory Brain = new Memory();` | `RacerBrain Brain` (or `Memory` → `RacerBrain` type) | Vague |
| `public void SteerTrack()` | `public void ComputeSteering()` | Vague; method computes a steering target, it doesn't "track" |
| `public void SpeedTrack()` | `public void ComputeTargetSpeed()` | Same |
| `void SpeedToThrottleBrake()` | `void ConvertSpeedToThrottleBrake()` | Reads as a noun phrase |
| `void SteerTranslateInput()` | `void TranslateSteeringToInput()` | Word order, clarity |
| `void SteerApplyCorrections()` | `void ApplySteeringLimit()` | "Corrections" plural is vague |
| `void DrawStuff()` | `void DrawRacerDebug()` | Profanity-adjacent "Stuff" |
| `void UpdatePercievedGrip()` | `UpdatePerceivedGrip` | Typo |
| `void UpdateCornerInfo()` | keep | OK |
| `void UpdatePassengerize()` | keep (or `UpdatePassengerSeat`) | OK |
| `RaceState RCStatus` | `RaceState Status` (or `RacerState`) | Cryptic; collides visually with `ARS.RaceStatus` |
| `enum eLookAheads` | `enum LookAheadKind` (and members `SteerInRef` is dead) | `e` Hungarian prefix non-idiomatic |
| `Random Random = new Random();` | delete (unused) | — |
| `HalfSecondTick`, `OneSecondTick`, `LastCoreTick` (private fields, PascalCase) | `_halfSecondTick`, `_oneSecondTick`, `_lastCoreTick` | Convention drift (private ⇒ `_camelCase`) |
| `HeadingPID` (private) | `_headingPid` | Convention drift; also dead in Goal 1 |
| `LastSpeed`, `TorqueMult`, `Random`, `TrailSamples`, `FollowLaneTrail`, `RawFollowLaneTrail`, `LastFollowLaneTrailNode` (private PascalCase) | `_lastSpeed` etc. (delete the dead ones) | Convention drift |
| `LastStuckGameTime`, `IsRecoveringFromStuck`, `StuckRecoveryEndTime`, `StuckRecoveryAttempts`, `StuckRecoveryAttemptsNow` | `_lastStuckGameTime`, `_isRecoveringFromStuck`, `_stuckRecoveryEndTime`, etc. (keep public `IsRecoveringFromStuckNow` PascalCase) | Convention drift on privates |
| `IsStuckByThrottle` (public) | keep | OK |
| `Random Random = new Random();` field | (delete) | shadows type name, unused |
| `DistToOutside`/`DistToInside` | delete (per Goal 1) | — |

### `AutosportRacingSystem.cs`

| Current | Proposed | Reason |
|---|---|---|
| `TracjectoryProjectionSeconds` | `TrajectoryProjectionSeconds` | Typo; also dead per Goal 1 |
| `FreecCamRide` | `FreeCamRide` | Typo (extra `c`) |
| `GametimerefLong` | `GameTimeRefLong` | camelCase drift / capitalization typo |
| `secInteval` | `secInterval` | Typo |
| `NeabyImmersiveJoins` | `nearbyImmersiveJoins` (or `_` prefix since private) | Typo + convention |
| `List<int> Other`, `Road`, `Dirt`, `Sand` (terrain hash lists) | stable as-is for hash lookup, but prefix with `TerrainHashOther` etc. | Names `Other`/`Road`/`Dirt`/`Sand` pollute class namespace ambiguously |
| `static public ulong steeroffset` | `SteerOffset` | public static field ⇒ PascalCase; also lowercase drift |
| `static public ulong throttleOffset` | `ThrottleOffset` | Same |
| `static public ulong brakeOffset` | `BrakeOffset` | Same |
| `static ulong steerAngle` | `SteerAngleOffset` (private static `_steerAngleOffset` or PascalCase if kept public) | Vague; this is the angle-field offset, distinct from `steeroffset` |
| `public static ulong handlingPtr` | `HandlingPtr` | Public static ⇒ PascalCase |
| `public static ulong wheelsPtr` | `WheelsPtr` | Public static ⇒ PascalCase |
| `public static ulong numwheelsoffset` | `NumWheelsOffset` | Public static ⇒ PascalCase |
| `Scaleform scaleform = new Scaleform(...)` | `InstructionalScaleform` | Field shadows type name |
| `Scaleform racertext` | `RacerTextScaleform` | Same |
| `Scaleform debugFrontend` | `DebugFrontendScaleform` | Inconsistent casing |
| `Scaleform floatingtext` | `FloatingTextScaleform` | camelCase static public |
| `Scaleform SCCountdown` | `CountdownScaleform` | Inconsistent casing |
| `public static float map(...)` | `Remap` | Vague; "map" is too generic; matches Arduino's `map()` but C# idiom is `Remap` |
| `public static float mapGamma(...)` | `RemapGamma` (delete per Goal 1) | Same |
| `VehicleColor[] randomcolors` | `RandomColors` (private ⇒ `_randomColors`) | Casing drift |
| `static Random rnd` | `_random` (or `_rnd`) | Convention drift |
| `Dictionary<int,int> DistToPercent` | delete (dead) | — |
| `void SetSPLVisibility(bool)` / `void ToggleSPLVisibility()` | `SetSplVisibility` / `ToggleSplVisibility` (or expand SPL → `TrafficPropVisibility`) | Acronym casing inconsistent with C# idiom |
| `frecuency` (local var and XML node `Frecuency`) | `frequency` / node `<Frequency>` | Typo (also affects saved XML attribute name) |
| `List<int> FlareFX` | `FlareFx` (or keep) | Inconsistent acronym casing |
| `IsDroneMode`/`InFreeCam` / `listenmode` | `IsDroneMode`, `InFreeCam`, `ListenMode` | `listenmode` casing drift |
| `bool Loaded`/`IsLoadingScript`/`Task LoadScriptTask` | `_loaded`/`_isLoadingScript`/`_loadScriptTask` | Private fields PascalCase convention drift |
| Scaleform-local `dir` (string for height-arrow) | `heightDeltaLabel` | Vague |
| `public XmlDocument LoadDriver(string DriverName)` param `DriverName` | `driverName` | Public parameter should be camelCase |
| `intendedOpponents` private field | keep (or `_intendedOpponents`) | fine |
| `MenuItemDefinition` keep | — | OK |
| `XmlNode getname` local | `nameNode` | Inconsistent casing |
| `XmlDocument memOffexts` (local var `menOffexts`, line 4930) | `memoryOffsets` | Typo (`menOffexts`) |
| `bool AddPlayerToGrid()` | keep | OK |
| `static public unsafe float GetWheelsMaxWheelspin` | `GetMaxWheelspin` | "WheelsMaxWheelspin" redundant |
| `void PlaceOnGround(Prop p)` empty | delete | — |
| All `unsafe List<float> Get…(Vehicle)` returning the same shape | collapse to `GetWheelFloatField` per Goal 1; remaining ones PascalCase-correct | Convention |

### `DataStructures.cs`

| Current | Proposed | Reason |
|---|---|---|
| `public class Memory` | `RacerBrain` | Matches the fieldname `Brain`; "Memory" is ambiguous |
| `public Data data = new Data();` | `Data Data` | Public field ⇒ PascalCase |
| `public Intention intention = new Intention();` | `Intention Intention` | Same |
| `public class Intention.Speed` | `TargetSpeed` | "Speed" alone is ambiguous (current vs target); the controller uses it as the goal |
| `public float Intention.MaxSpeed` | `MaxSpeedCap` | Same |
| `public float IntendedSpdChangeGs` | `IntendedAccelGs` | `Spd` abbreviation; combined as `IntendedSpdChangeGs` reads oddly |
| `public Corner Corner = null;` field on `Memory` | `Corner CurrentCorner` | Field shadows type name |
| `public class Corner.OG` (CornerPoint OG) | `CornerPoint Point` (or `Corner CornerRef`) | Cryptic |
| `public float sToEntrance` | delete (dead) | — |
| `enum BrakeStabilityStrat` | delete | — |
| `Approach Approach = new Approach();` field on `Corner` | delete | — |
| `public RelativePos relativePos` | `RelativePos RelativePos` | Public field ⇒ PascalCase |
| `public Vector3 rPos` | `LocalOffset` | Cryptic; this is `GetOffset(me.Car, rival.Car)` — local-space offset |
| `public float sToReach` | `SecondsToReach` | `s` is ambiguous (could be seconds, distance, score) |
| `public float sToRear` | delete dead | — |
| `Rival.OvertakeLane`, `Rival.AvoidStr` | delete dead | — |
| `Rival.BoundingBoxTotal` | `CombinedBounds` | Vague; "total" of what? |
| `TrackPoint.TrackWide` | `TrackWidth` (or `HalfWidth`?) | "Wide" is non-standard; semantic is half-width (used as `radius` in clamps at `roadWide - carHalfWidth`). Confirm semantics during rename. |
| `CornerPoint.LengthStart`, `CornerPoint.LenghtEnd` | `LengthStart`, `LengthEnd` | Typo `Lenght` |
| `CornerPoint.OG` accessor | —— once `OG` is renamed | — |
| `VehData.YawRotationPerSecondDegrees` | keep | OK |
| `VehData.SlideAngle` | keep | OK |
| `VehData.Gs` | `AverageAcceleration` | `Gs` collides with gravity usage; "Gs" local is `AccelerationVector.Aggregate(...)/Count/2` (average) |
| `VehData.Understeer`, `CurrentDownforce` | delete | — |
| `VehicleControl.SteerTrackDegrees` | keep | OK |
| `VehicleControl.SteerStabilityCorrection`, `SteerMax`, `FollowLane`, `ThrottleOffset`, `CurrentLockupLimiter` | delete dead | — |
| `VehicleControl.SteerManeuver` | delete (effectively dead) | — |
| `public static class AIData` | keep | OK |
| `AIData.MaxSpeed`/`MinSpeed` | keep | OK |
| `AIData.SpeedToInput` | `SpeedToThrottleInput` (vague; never called in three files either — confirm before renaming vs deleting) | — |

### Cross-file notes

- Once `TracjectoryProjectionSeconds` is renamed, no other file references it.
- `LenghtEnd` reads in `Racer.cs:1074,1096` and `AutosportRacingSystem.cs:4085,4407`. Rename to `LengthEnd` in one place.
- `map` is referenced heavily across `Racer.cs` and `AutosportRacingSystem.cs`. Renaming to `Remap` will touch many call sites; do it with a single find/replace after the enum/type renames land.

---

## GOAL 3 — Remove all comments

Categories of comments present (with file and approximate line region). After Goal 2 makes names self-documenting, these categories are noise.

### 3.1 Empty/stub XML `<summary>` tags
- `Racer.cs:543–545` — `<summary></summary><returns></returns>` before `DistToOutside` (no text).
- `Racer.cs:662–663` — empty `<summary></summary>` before `SteerTranslateInput`.
- `Racer.cs:1221–1223` — empty `<summary></summary><returns>Distance in meters</returns>` before `OutOfTrackDistance` (the `<returns>` is the obvious restatement).
- `Racer.cs:1332–1334` — `<summary>Processes AI logic that works on slow (500ms - 2000ms) cycles.</summary>` — narrative restatement.
- `Racer.cs:1387–1389` — `<summary>Runs Speeding and Steering logic.</summary>` — obvious restatement.
- `Racer.cs:802–804` — `<summary>Limits Control.Throttle and Control.Brake inputs…</summary>` — describes what `TractionControl`'s name already says.
- `DataStructures.cs:24–25`, `:28–31` — empty `<summary></summary>` on `YawRotationPerSecondDegrees`, and a paragraph on `BaseMechanicalGrip` describing tuning (`Hardcoded to reach an equilibrium…`). Restatement.
- `DataStructures.cs:60–62` — `<summary>The AI brain.</summary>` on `Memory` — obvious.

### 3.2 Stale "removed X" / disabled-feature notes
- `AutosportRacingSystem.cs:844` — `// Removed: OpenRaceOptionsMenu() and OpenRaceSetupMenu() — no longer needed.`
- `Racer.cs:743–764` (`#if false` "Steer-angle speed limiter — disabled. Kept for reference.")
- `Racer.cs:784–798` "Risk factor for grip… NOT active."
- `AutosportRacingSystem.cs:1392` `//Never really used` over `DrawMiniaturizedPath`.
- `AutosportRacingSystem.cs:875` `AdjustMenuOption` body comment `// No adjustable items remain in the menu.`

### 3.3 Section banners (decorative dividers and section headings)
- `Racer.cs:23`, `:32`, `:37`, `:43`, `:53`, `:61`, `:67`, `:78`, `:96`, `:100`, `:104`, `:108`, `:113`, `:118`, `:122` — section headers like `// Identity and runtime references.`, `// Core controller/memory.`, `// Countersteer state (GodotRace-style).`, etc.
- `Racer.cs:344` — `// ── Local helpers ──────────────────────────────────────────────` ASCII divider.
- `AutosportRacingSystem.cs:217` (`//Freecam`), `:228` (`//offsets`), `:236` (`//Terrain hashes`), `:247` (`//AI racers…`), `:252` (`//Route info`), `:610` (`//Scaleforms`), `:810` (`//Menu`), `:1246` (`//Immersive joins`), `:776` (`//Route Creator active section`), `:1330` (`//Priority, anticrash checks`), `:1349` (`//Scaleforms`), `:1369` (`//Timescale control`), `:1405` (`//Create the menu on key inputs`), `:1427` (`//Handle the countdown`), `:1499` (`//Where the magic happens.`), `:1515` (`//Handle the racing positions`), `:1546` (`//Configure the leaderboard and handle lapping logic`), `:1615` (`//Draw the leaderboard positions`), `:4890` (`/// TOOLS ///`).
- Inline narrative headings like `//AI Inputs` (`Racer.cs:965`), `//Catchup` (`Racer.cs:864`), `//Slow checks` (`Racer.cs:1346`), `//Drawing and GUI stuff` and many `//Info & Tips`, `//Drawing and GUI stuff`.

### 3.4 Obvious restatements (narrate the line just below)
- `Racer.cs:225` `Control.Brake = 0f;` preceded by `Control.Brake = 0f;` (no, the restatement): `Control.Brake = 0f;` preceded by `// Constructor` style.
- `AutosportRacingSystem.cs:172` (`PID.cs` region inside ARS):
  - `// Fields` (`:60`)
  - `// Constructor` (`:71`)
  - `// Update method - advances the controller by dt seconds` (`:90`)
  - `// Update with external derivative input (e.g. yaw rate).` block (`:96–99`)
  - `// Clamp acceleration to maxAccel` (`:114`)
  - `// Clamp velocity to maxSpeed` (`:122`)
  - `// Snap to target if close enough` (`:130`)
  - `// Set target value with clamping` (`:140`)
  - `// Set current value and reset velocity and integral` (`:146`)
  - `// Get current value` (`:154`)
  - `// Get target value` (`:160`)
  - `// Modify target value with clamping` (`:166`)
  - `// Check if close to target within threshold` (`:172`)

### 3.5 Inline math narration
- `Racer.cs:258–269` "1) Heading error…", "Scale down the heading error…", "2) Compute target lane…" through "8) Slide countersteer…". The eight comments walk through the body of `SteerTrack` like a tutorial.
- `Racer.cs:378–388` (`ComputeCornerTargetLane`) — `// Corner direction: SignedAngle(pre, fut, up) is negative for right turns. // cornerDir = -1 for right turn, +1 for left turn. // For a right turn (cornerDir = -1): Outside = left … Apex = right …` — narration that disappears once names are clear.
- `Racer.cs:419–431` `// 2s→1s before apex: lerp from outside to inside.`, `// 5s→2s before apex: hold outside.`
- `Racer.cs:489–528` `// Aggression-scaled buffer: 0 aggro = 2m gap, 100 aggro = 0.25m gap.` etc.
- `AutosportRacingSystem.cs:4780–4782` (summary of `MapIdealSpeedForDistance`) — *"Returns the max speed (m/s) the car can be doing now and still brake down to the corner speed by the time it reaches the corner entry. Uses the kinematic braking equation: v₀ = √(vTarget² + 2·decel·distance)"* — this is the **single exception I'd keep**, since the closed-form braking equation is non-obvious and not derivable from a method name without re-deriving the physics. The body's internal `// 90% of max decel as safety margin (aggression-tunable later).` (`:4791`) and `// Distance to corner entry (apex node - LengthStart), plus 10m safety.` (`:4785`) are instead obvious restatements of nearby literals and should go.
- `AutosportRacingSystem.cs:4258–4261`, `:4298–4301`, `:4327–4330`, `:4349–4353`, `:4379–4383`, `:4384–4388` — the hill-grip family has summary blocks with the formula narrative "Linear model: 0 degrees → x1, 90 degrees → x0." and "Upward velocity implies uphill." Once the method names become `HillGripMultiplierFromElevation` / `…FromVelocity`, these are restatements.
- `AutosportRacingSystem.cs:4219–4233` — `// Calculate slope of line perpendicular…` block comment lines inside `GetCurveRadius2D` explaining basic geometry.

### 3.6 Terrain-hash annotation comments
- `AutosportRacingSystem.cs:236–241` — `//Terrain hashes` plus inline `//-1286696947<grass` `//-461750719` `//Concrete` `//WetTarmac` `//Gravel` `//LooseGravel` etc. inline annotations on hash list members.
- `AutosportRacingSystem.cs:273–287` — `TerrainTypes` enum has `MoreTarmac = 1187676648, //Concrete`, `WetTarmac = …`, `Grass = …` etc. inline hash annotations.

### 3.7 Disabled-feature / "never used" / leftover cheat-mode comments
- `AutosportRacingSystem.cs:1392` `//if (Path.Count > 20 && MiniMap != Vector3.Zero) DrawMiniaturizedPath(MiniMap);` `//Never really used`
- `AutosportRacingSystem.cs:3249–3267` block of `//UI.Notify("~b~[" + ScriptName + "]:~w~ Reloading settings…");` etc., narrating cheat handlers
- `AutosportRacingSystem.cs:4558–4583` `if (Game.Version <= ...) offset = 0x1B8;` redundant re-assignment comment
- `AutosportRacingSystem.cs:5195–5200` neonlights disabled block (`/* veh.SetNeonLightsOn(VehicleNeonLight.Front, true); */` etc.)
- `Racer.cs:1419` `//If cool, the track is closed, no need to render more` — section narration in `HandleTrackCreator`. (file is wrong: that one is in `AutosportRacingSystem.cs:1686`.) Same category.

### 3.8 Counterstater `// blip creation failed, non-critical`
- `Racer.cs:191` `/* blip creation failed, non-critical */` — obvious catch handler.

### 3.9 Cited references to other systems ("GodotRace") or external projects
- `Racer.cs:259` `// not model forward (where car is pointing). Matches GodotRace.`
- `Racer.cs:108` `// Countersteer state (GodotRace-style).`
- `Racer.cs:325` `// 7) GodotRace-style PD: P on heading error, D on yaw rate (subtracted).`
These are external-implementation breadcrumbs whose value is gone after names are clear. Remove.

### The one exception to keep
I would keep exactly **one** comment: the method-summary block on `MapIdealSpeedForDistance` (`AutosportRacingSystem.cs:4780–4782`), specifically the kinematic braking equation `v₀ = √(vTarget² + 2·decel·distance)`. It encodes a non-obvious physics identity not recoverable from method/parameter names alone. Even there, the body's inline narration lines (`:4785`, `:4791`) go. If the only-summaries convention is preferred, that one summary becomes the sole comment in the codebase.

---

## Appendix — Behavior-level findings noticed in passing (NOT part of the three goals)

This appendix is outside the three goals; items here may be bugs or smell-policy issues to confirm separately. None of them are to be changed under the refactor.

1. **`ResolveLookAhead` wraparound is wrong.** `Racer.cs:1264–1268`: when `CurrentTrackPoint.Node + offset >= TrackPoints.Count`, it returns `TrackPoints[offset]` (a positions near the *start*) instead of a wrapped or clamped node at the front of the lap. On closed circuits this silently teleports the lookahead to early-track coordinates mid-lap, corrupting `LookAheads` for laps ≥ 2. Likely should return `TrackPoints[(Node + offset) % TrackPoints.Count]` or clamp to last index.

2. **`UpdateRivals` skips last slot.** `Racer.cs:1594` loop bound `i < Brain.Rivals.Count - 1` (`for` runs `Brain.Rivals.Count - 1` iterations) writes into `[0..Count-2]`; the last `Rival` object is never assigned a `RivalRacer`, even when more candidates exist. Either off-by-one in the bound or intentional "one free slot" — needs confirmation.

3. **`trackWidth` semantics of `TrackWide` are half-width.** All clamps use `roadWide = steerRefPoint.TrackWide` and then `trackBound = roadWide - carHalfWidth`, treating `TrackWide` as radius-yet-clamping-with-half. The field name implies full width. Renaming in Goal 2 (`TrackWide` → `TrackWidth` or `HalfWidth`) should resolve the semantic before widespread use.

4. **`Position` field shadowing.** `OffsetByAngle` (`:4799–4823`) declares a local `Vector3 Position = v.Position;` using PascalCase identical to the `Entity.Position` property, plus `Vector3 Goal` (`:4808`) etc. Dead per Goal 1 anyway.

5. **`OptionValues.ShowAggression` is dead** (typed in dead enum `OptionValues`); meanwhile the live toggle is `Options.ShowAggro`. They were probably renamed at some point and never cleaned.

6. **`Rider lap-counting when `IsPointToPoint`** at `Racer.cs:1283`: the OR short-circuits track-rewind (`ARS.GetPercent(...) < 10`) ahead of the point-to-point branch; for point-to-point, this can register a phantom "lap" the moment the racer drives near the start node. Confirm against target behavior.

7. **`ParseToTimeSpan(int)` returns TimeSpan and comment notes the format string was removed; `TimeSpan.FromMilliseconds(gameTime).ToString("m':'ss'.'f")` was the old call site.** Live, not a refactor issue; just noting the trailing `//…` comment to delete under Goal 3.

8. **Frequency of `try { ... } catch (Exception) {}` swallowing** is high in `Racer` constructor and model/seat manipulation. Not dead — the parent instructions said don't touch behavior — but flagged for future review.

---

End of audit.