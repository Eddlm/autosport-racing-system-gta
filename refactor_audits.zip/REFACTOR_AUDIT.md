# ARS Refactoring Audit

Re-audited from scratch reading all three source files end-to-end:
`Racer.cs` (1633l), `AutosportRacingSystem.cs` (≈6280l), `DataStructures.cs` (238l).
Also checked `SkillSet.cs` and `PersonalitySet.cs` — both are empty namespace stubs.

Goals:
1. Simplify code, preserve behavior.
2. Improve clarity via better names (fields, methods, types).
3. Remove all comments — code must be self-documenting.

---

## 1. File structure

### 1.1 `AutosportRacingSystem.cs` is a ≈6280-line god class

`ARS : Script` holds: enums, the PID controller, all static global state, memory-hack helpers, track loading, corner baking, the entire menu system, race lifecycle, per-tick loop, drawing helpers, vehicle spawning/tuning, freecam, track creator, cheats, and XML I/O. Nothing is separated.

**Plan:** Split into files/regions by responsibility:
- `ARS.cs` — the `Script` subclass, OnTick, lifecycle, cheats. Keeps the SHVDN entry point.
- `TrackLoader.cs` — `LoadTrackFile`, `LoadTrack`, `GenerateRouteInfo`, `SaveRoute`, `SpawnTrackLimits`, XML helpers.
- `CornerBaking.cs` — the key-corner detection, span computation, Bezier lane-bias baking (the ~200 lines inside `GenerateRouteInfo`).
- `RaceManager.cs` — `StartRace`, `SetupRace`, `LoadGrid`, `PlaceCars`, countdown, leaderboard, position tracking.
- `MenuSystem.cs` — `MenuItemDefinition`, `HandleMenu`, `OpenMenuFromContext`, `EnsureMenuItemDefinitions`.
- `MemoryAccess.cs` — all `unsafe` pattern scans + wheel offset readers.
- `VehicleFactory.cs` — `FillCachedCandidates`, `CreateVehicle`, `RandomTuning`, `GetNearbyCandidates`.
- `Drawing.cs` — `DrawText`, `DrawLine`, `DisplayHelpText*`, `DrawStats`, scaleform helpers.
- `MathUtils.cs` — `map`, `Clamp`, `rad2deg`, `deg2rad`, `LeftOrRight`, `GetCurveRadius`, bezier, `LerpByDistance`.
- `Freecam.cs` — `HandleFreecam`, `ToggleFreeCam`.
- `TrackCreator.cs` — `HandleTrackCreator` and route editor.

`PID` belongs in its own file (`PID.cs`) or in `DataStructures.cs` — not floating above the `ARS` class.

### 1.2 `Racer.cs` (1633 lines) is borderline

One class doing identity, handling init, steering, speed, avoidance, passengerize, stuck recovery, grip perception, rivals, debug drawing, and trail sampling. Acceptable as one file but the methods should be grouped into clear `#region`s during the rename pass, and the debug-drawing block (`DrawStuff`, `DrawInputTrails`, trail helpers) is a strong candidate for extraction into a `RacerDebugDrawer` that takes a `Racer`.

### 1.3 `DataStructures.cs` (238 lines)

Fine in size. Mostly needs the dead-field purge (section 3) and comment removal.

### 1.4 `SkillSet.cs` and `PersonalitySet.cs`

Both are empty stubs (`namespace ARS { }`). Delete them.

---

## 2. Bugs found

### 2.1 Lookahead wrap bug (`Racer.cs:1266`)

```csharp
TrackPoint ResolveLookAhead(int offset)
{
    if (CurrentTrackPoint.Node + offset >= ARS.TrackPoints.Count) return ARS.TrackPoints[offset];
    return ARS.TrackPoints[CurrentTrackPoint.Node + offset];
}
```
When the node wraps past the end it returns `TrackPoints[offset]` (node index = bare offset), not the wrapped-around node. Should be modulo: `ARS.TrackPoints[(CurrentTrackPoint.Node + offset) % ARS.TrackPoints.Count]`. This bug has existed unnoticed either because tracks are large enough or wrap-around never happens (point-to-point near finish).

### 2.2 GridSort parse is broken (`AutosportRacingSystem.cs:2431`)

```csharp
foreach (GridSort g in Enum.GetValues(typeof(GridSort)))
{
    g.ToString().ToLowerInvariant().Contains(DevSettingsFile.GetValue<string>("RACERS", "GridSorting", "Power").ToLowerInvariant());
    sort = g;  // Always overwrites — result of Contains() is discarded
}
```
`sort` always ends as the last enum value (`Random`). Fix: use `Enum.TryParse`.

### 2.3 `SteerApplyCorrections` sign comparison loses precision (`Racer.cs:535`)

```csharp
if (Math.Sign(Control.SteerTrackDegrees) == Math.Sign((int)VehicleData.YawRotationPerSecondDegrees))
```
Casting yaw rate to `int` truncates values between -0.99 and +0.99 to zero, giving `Math.Sign(0) = 0`. This produces false sign-matches at low yaw rates, triggering the speed limiter when it shouldn't be active.

### 2.4 `_avoidLeftWall` / `_avoidRightWall` start at 0 (`Racer.cs:115-116`)

These are declared as `float _avoidLeftWall = 0f; float _avoidRightWall = 0f;`. The decay logic (2 m/s) will open them from 0 toward the track bounds over several ticks. On the very first tick of a race, both walls are clamped to center, meaning `clampLeft ≈ carHalfWidth` and `clampRight ≈ -carHalfWidth` — forcing the car to a center-lane width of zero until the decay finishes. This likely causes a one-frame or few-frame steering jerk at race start, quickly corrected. Should initialize to track bounds in `Launch()` or `Initialize()`.

### 2.5 Rocket boost always active (`Racer.cs:1372`)

```csharp
if (1 == 1 || !Brain.Corner.Valid || Brain.Corner.sToEntrance > 4)
```
The `1 == 1` is always true; the corner-condition OR branch is dead. The rocket boost native fires on every 1-second tick for every AI racer going straight with throttle > 90%. Simplify to the intended condition or delete the dead branch.

---

## 3. Dead code — delete outright

### 3.1 Disabled-by-constant blocks

| File | Line | Block | Action |
|---|---|---|---|
| `Racer.cs` | ~743 | `#if false … #endif` steer-angle limiter | Delete |
| `Racer.cs` | ~766 | `if (Brain.Corner.Valid && 1==2) { … }` outward-limiter | Delete |
| `Racer.cs` | ~867 | `if (RacePosition > ARS.catchupPos && 1 == 0)` catchup block | Delete |
| `Racer.cs` | ~1372 | `if (1 == 1 \|\| !Brain.Corner.Valid …)` rocket boost dead branch | Simplify |
| `AutosportRacingSystem.cs` | ~1638 | `if (1==2 && CanWeUse(playerVeh) …)` new-vehicle-detection | Delete |
| `AutosportRacingSystem.cs` | ~1570,1616 | `\|\| 1==1` after radar-native check | Simplify (always true) |
| `AutosportRacingSystem.cs` | ~3805 | `if (hash == … && 1 == 2)` garage prop block | Delete |
| `AutosportRacingSystem.cs` | ~2402 | `/* void LoadAndRace … */` commented method | Delete |
| `AutosportRacingSystem.cs` | ~1314 | `/* float min/max … */` debug block | Delete |
| `AutosportRacingSystem.cs` | ~1457,1589,1598,1604 | Commented-out leaderboard/roof lines | Delete |
| `AutosportRacingSystem.cs` | ~3903-3912 | Commented cam/render natives | Delete |

### 3.2 Unused enums

| Enum | Reason |
|---|---|
| `Decision` | Declaration only. Delete. |
| `Mistake` | Declaration only. Delete. |
| `OptionValues` | Only `ShowAggression`, never referenced. `OptionValuesList` uses `Options` as key. Delete. |
| `CameraTransition` | Declaration only. Delete. |
| `BrakeStabilityStrat` | Referenced only by `Corner.stabilityStrat`, which is never read. Delete both. |
| `DebugDisplay` | Only `PropEdit` value used for `DebugVisual` check. Verify if PropEdit mode is still needed; if not, delete enum and `DebugVisual`. |

### 3.3 Unused/never-read fields (DataStructures.cs)

| Field | Reason |
|---|---|
| `Rival.AvoidStr` | Never written or read. Delete. |
| `Rival.OvertakeLane` | Never written or read. Delete. |
| `VehicleControl.SteerStabilityCorrection` | Never used. Delete. |
| `VehicleControl.SteerMax` | Never used. Delete. |
| `VehicleControl.CurrentLockupLimiter` | Never used. Delete. |
| `Corner.stabilityStrat` | Assigned `Invalid` in ctor, never read. Delete field + enum. |
| `Approach.CheckedForImpediment` | Never used. Delete. |
| `Approach.HoldDeviation` | Never used. Delete. |
| `Approach.Valid` | Only ever `true`. Delete or keep if wiring is planned. |
| `CornerPoint.FullAngle` | Never written. Delete. |
| `VehData.Understeer` | Never written or read. Delete. |

### 3.4 Unused/never-read fields (Racer.cs)

| Field | Reason |
|---|---|
| `_countersteerBlend` | Never read. Delete. |
| `CountersteerFullSeverityMult` | Const, never referenced. Delete. |
| `CountersteerRecoveryRate` | Const, never referenced. Delete. |
| `_cornerPhase` | Assigned 4 times in `ComputeCornerTargetLane`, never read. Delete or wire into debug text. |
| `TorqueMult` | Written in `ProcessTick`, never read. Delete. |
| `LocalSpdLimiter` | Never used. Delete. |
| `MaxLeftLane`, `MaxRightLane` | Never used. Delete. |
| `RiskFactorForGrip()`, `RiskFactorForBrake()` | Stubs returning 1f, never called. Delete. |
| `FollowLaneTrail`, `RawFollowLaneTrail`, `LastFollowLaneTrailNode`, `UpdateFollowLaneTrail`, `GetFollowLaneTrailPoint`, `GetRawFollowLaneTrailPoint`, `DrawFollowLaneTrail`, `DrawRawFollowLaneTrail` | The draw methods are never called. The lists are populated in `RunTimedCore` → `UpdateFollowTrack` → `UpdateFollowLaneTrail`? Wait — verify if `UpdateFollowLaneTrail` is called anywhere (it's not in `ProcessAI` or `ProcessTick`). If truly dead, delete the entire subsystem. |

### 3.5 Unused/never-read statics (ARS)

| Static | Reason |
|---|---|
| `TracjectoryProjectionSeconds` | 1 hit (declaration). Delete. |
| `RaceReward` | Written once (0), read once. Verify; likely delete or wire properly. |
| `GlobalTraffic` | Rebuilt every 200ms, only used to filter racers from itself. Delete. |
| `MultiplierInTerrain` | Written in `UpdatePercievedGrip`, never read. Delete. |
| `EditWideDict` | Never read. Delete. |
| `Angles` | Rebuilt in `LoadTrack`, never read. Delete. |

### 3.6 Unused methods

| Method | Notes |
|---|---|
| `GetMoreShit` | Offensive name, never called. Delete. |
| `DrawDirectionalBoundingBox` | Never called. Delete. |
| `GetRoadHeading`, `GetRoadOutOfBoundsX`, `IsRoadBusy` | Never called. Delete. |
| `LerpByDistance`, `GetXfromPosInDirection` | Never called. Delete. |
| `LaneSelectionApproachCorner` | Returns 0f, never called. Delete. |
| `ToggleSPLVisibility` | Never called. Keep `SetSPLVisibility`. |
| `AIData.SpeedToInput` | Never called. Delete. |
| `mapGamma` | Verify; likely dead. |
| `DrawStats(Racer)` overload | Verify; likely dead. |
| `GetWheelInternalDownforceMod`, `GetWheelsWetgrip`, `GetWheelSkidmark`, `GetWheelSlippage`, `GetWheelsAvgWheelspin`, `GetWheelsPower` | Verify each. Keep only what `TractionControl`/`UpdateGrip` consume. |

---

## 4. Naming — typos and inconsistencies

### 4.1 Typos to fix

| Current | Fix |
|---|---|
| `CornerPoint.LenghtEnd` | `LengthEnd` |
| `UpdatePercievedGrip` | `UpdatePerceivedGrip` |
| `GametimerefLong` | `GameTimeRefLong` |
| `FreecCamRide` | `FreecamRide` |
| `SCCountdown` | `CountdownScaleform` |
| `Cool` (local in `HandleTrackCreator`) | `circuitClosureState` |
| `Racer.RCStatus` | `RacerRaceStatus` |

### 4.2 Style inconsistency

Newer code uses `_camelCase` for private instance fields (`_avoidLeftWall`, `_isPassengerized`), older code uses bare `PascalCase` (`LastSpeed`, `HalfSecondTick`, `HeadingPID`). Standardize: private instance fields → `_camelCase`, public fields → `PascalCase`, constants → `PascalCase`.

### 4.3 Vague names → suggested renames

| Current | Suggested | Reason |
|---|---|---|
| `Memory` | `RacerBrain` | Matches how it's referenced: `Brain` |
| `Memory.Data` | `RacerBrain.Perception` | Holds perceived route/grip data |
| `Memory.Intention` | `RacerBrain.DriveIntent` | Speed, MaxSpeed, Direction, IntendedSpdChangeGs |
| `VehData` | `VehicleState` | Holds runtime vehicle dynamics |
| `HandlingData` | `HandlingProfile` | Static handling properties |
| `VehicleControl` | `ControlInputs` | Driver output values |
| `Brain.data.DeviationFromCenter` | `Brain.Perception.LaneOffset` | Signed meters from track center |
| `Brain.data.CurveRadiusToFollowPoint` | `Brain.Perception.RouteRadius` | Radius computed from route window |
| `Brain.data.FollowPoint` | `Brain.Perception.RouteTarget` | Track point at end of route window |
| `Rival.rPos` | `Rival.RelativeOffset` | Offset in local car space |
| `Rival.sToReach` / `sToRear` | `Rival.SecondsToReach` / `SecondsToRearBumper` | Time-based gap |
| `Rival.BoundingBoxTotal` | `Rival.CombinedSize` | X=width, Y=length+pad |
| `Rival.OccupiedLane` | `Rival.LaneOffset` | Rival's deviation from center |
| `Rival.OccupiedLaneWidth` | `Rival.CarWidth` | Width of rival |
| `Rival.DirectionDiff` | `Rival.VelocityAngleDiffDeg` | Degrees between velocity vectors |
| `TrackPoint.TrackWide` | `TrackPoint.HalfWidth` | It's a half-width (used as `* 2` everywhere) |
| `TrackPoint.Angle` | `TrackPoint.TurnAngleDeg` | Local turn angle at this point |
| `CornerPoint.Angle` | `CornerPoint.CornerAngleDeg` | Total corner angle |
| `CornerPoint.LengthStart` / `LengthEnd` | `CornerPoint.EntrySpan` / `ExitSpan` | Node counts |
| `Corner.OG` | `Corner.Definition` | The corner point that defines this corner |
| `Corner.sToEntrance` | `Corner.SecondsToEntry` | Time until corner entry |
| `Path` | `RouteNodes` | Positions only, not a computed path |
| `WideDict` | `NodeHalfWidths` | Track half-width per node |
| `NodeScalarData` | `NodeLaneOffsets` | The Bezier-baked lane bias per node |
| `catchupPos` | `CatchupThresholdPosition` | |
| `intendedOpponents` | `GridSize` | |
| `TrackFilter` / `DisciplineFilter` | `TrackTagFilter` / `VehicleTagFilter` | |
| `FilteredTrackList` | `FilteredTracks` | |
| `OptionValuesList` | `DebugToggles` | Keyed by `Options` enum |
| `Options` enum | `MenuOption` | |
| `Options.ShowAggro` | `MenuOption.ShowAvoidance` | |
| `Options.ShowTrackAnalysis` | `MenuOption.ShowCorners` | |

### 4.4 Method names → suggested renames

| Current | Suggested |
|---|---|
| `SteerTrack` | `ComputeSteering` |
| `SteerApplyCorrections` | `ApplySteeringLimits` |
| `SteerTranslateInput` | `SteerAngleToInput` |
| `SpeedTrack` | `ComputeTargetSpeed` |
| `SpeedToThrottleBrake` | `SpeedToThrottleBrakeInputs` |
| `UpdateFollowTrack` | `UpdateTrackPosition` |
| `UpdatePercievedGrip` | `UpdateGrip` |
| `UpdateDynamicBoundingBox` | `UpdateSlideAndBoundingBox` |
| `UpdateCornerInfo` | `UpdateCornerValidity` |
| `ProcessAI` | `UpdateDriving` |
| `ProcessTimedAI` | `UpdateSlowRateAI` |
| `ProcessTick` | `UpdateEveryFrame` |
| `RunTimedCore` | `UpdateCore` |
| `MapIdealSpeedForDistance` | `BrakingDistanceToMaxSpeed` |
| `GetSpeedForCorner` | `CornerApexSpeed` |
| `LookForCornerAhead` | `FindNextCorner` |
| `GetCurveRadius` | `Circumradius3D` |
| `GetCurveRadius2D` | `Circumradius2D` |
| `GripGainLossElChange` | `HillGripDeltaGs` |
| `GetHillGripMultiplierAtCurrentVelocityVector` | `HillGripMultiplierFromVelocity` |
| `GetWheelsMaxWheelspin` | `MaxWheelSlip` |
| `GetWheelsGrip` | `WheelGripMultipliers` |
| `GetDirectionalBoundingBox` | `SlidingBoundingBoxWidth` |
| `LeftOrRight` | `SignedLaneOffset` |
| `GetOffset` | `EntityRelativeOffset` |
| `MStoMPH` / `MPHtoMS` | `MpsToMph` / `MphToMps` |
| `rad2deg` / `deg2rad` | `RadToDeg` / `DegToRad` |
| `map` | `Remap` |
| `GetPercent` | `Percent` |
| `ParseToTimeSpan` | `MillisToTimeSpan` |
| `CleanEverything` | `TearDownRace` |

---

## 5. Comments — to remove

Goal: zero comments. Self-documenting code via good names.

Categories found:
1. **Empty or restating XML summaries** (`/// <summary></summary>`, `/// The AI brain.`, `/// Pure, precise data`, `/// Context aware data`) — delete.
2. **Stale "what I changed" notes** (`// Removed: OpenRaceMenuOptions…`, `// ghosting cars... removed`) — delete.
3. **Section banners** (`// ── Local helpers ──`, `//Where the magic happens.`, `//Priority, anticrash checks`) — delete; rely on method extraction.
4. **Obvious restatements** (`// Set target value with clamping`, `// Get current value`, `// Constructor`) — delete.
5. **Disabled-feature notes** (`// Steer-angle speed limiter — disabled.`) — the whole block goes with the dead code.
6. **Inline math narration** (`// Simple approximation (angle must be in RADIANS)`, `// Convert to degrees/sec`) — delete; method names should carry meaning.
7. **Terrain-hash inline notes** (`//-1286696947<grass`, `//Concrete`) — delete; `TerrainTypes` enum already maps names to hashes.

---

## 6. Structural simplifications

### 6.1 Duplicated XML-load retry loop

`GetTrackTags`, `GetTrackStartPos`, `GetRacerTags` all contain:
```csharp
XmlDocument document = new XmlDocument();
document.Load(path);
int pat = 0;
while (document == null && pat < 1000) { pat++; document.Load(path); }
```
`document.Load` never returns null, so the loop is dead code. Extract `LoadXmlDoc(string path)` and drop the loop. Also, `GetTrackStartPos` builds a `tags` list it never returns — delete that local.

### 6.2 Wheel-offset readers are copy-paste

`GetWheelsPower`, `GetWheelInternalDownforceMod`, `GetMoreShit`, `GetWheelsGrip`, `GetWheelsWetgrip`, `GetWheelSkidmark`, `GetWheelSlippage`, `GetWheelsAvgWheelspin` are identical except offset and rounding. Collapse into:
```csharp
static List<float> ReadWheelFloats(Vehicle v, ulong offset, int round = -1)
```
Keep thin named wrappers only for the ones actually used (`GetWheelsGrip`, `GetWheelsMaxWheelspin`).

### 6.3 Pattern-scan boilerplate

`SetSteerInput`, `SetSteerAngle`, `GetSteerInput`, `SetThrottle`, `SetBrakes`, `GetWheelsPtr`, `GetNumWheels` each re-run `FindPattern` and cache a static offset. Extract:
```csharp
static ulong ResolveOffset(string pattern, string mask, int add)
```
and `MemWriteFloat(Vehicle, ulong offset, float value)` / `MemReadFloat` pair.

### 6.4 `Memory.Rivals` hardcoded to 3

Constructor adds three empty `Rival`s. `UpdateRivals` then clears all and fills `Rivals.Count - 1` (i.e. index 0 and 1 — a probable off-by-one: index 2 is never assigned). Replace with a `List<Rival>` sized dynamically or a clear `MaxTrackedRivals` constant.

### 6.5 `SpeedTrack` is hard to follow

After dead-code removal the flow is: base speed → corner speed → route-curve speed → hill-grip-adjusted route speed → `min(corner, route)` → avoidance lift-off. Pull the hill-grip block into `ComputeHillAdjustedRouteSpeed()` and the avoidance block into `ApplyAvoidanceSpeedLimit()`.

### 6.6 Leaderboard string formatting

Four near-identical string formats with commented-out alternates in `OnTick` (~line 1547-1631). Extract `FormatLeaderboardLine(Racer, bool sprintHeld, bool finished)`.

### 6.7 Racer constructor

~80 lines with nested try/catch silently swallowing exceptions. Split into `ConfigurePed`, `ConfigureVehicle`, `AddBlip`. Replace `catch (Exception) {}` with targeted catches or a single logged catch.

### 6.8 `GenerateRouteInfo` is ~280 lines

Four passes: trackpoints, cornerpoints, key-corner detection, span computation, overlap removal, Bezier lane bake. Split into named sub-methods.

### 6.9 `OnTick` main loop

~370 lines. After extracting leaderboard/countdown/freecam/traffic-density into named methods, the body should be ~40 lines of orchestration.

---

## 7. Magic numbers → named constants

Key bare numbers in `Racer.cs` are documented in memory.md. During the rename pass, extract these into a static `Tuning` class, organized by system:

| System | Numbers |
|---|---|
| Avoidance | `2f` (wall open rate m/s), `1f` (lift-off gap), `2f→0.25f` (aggro buffer range), `0.25f` (lane bias scale), `20f` (direction-diff gate °), `4f` (sToReach gate) |
| Corner line | `5f`/`2f`/`1f` (phase thresholds), `50f`/`300f` (curve radius map), `0.1f`/`1f` (inside intensity) |
| Braking | `4f` (brakingAbility mult), `0.5f` (decel safety), `30f` (entry safety meters) |
| TCS | `2.0f` (base wheelspin), `±0.2f` (aggro offset), `8f` (gain) |
| Steering | `0.5f` (heading error scale), `0.35f` (steerKD base), `0.9f` (limiter scale), `1f` (min steer °), `0.25f` (lane bias scale) |
| Grip | `0.1f`/`5f` (handlingGrip clamp), `5f` (z-stability threshold) |
| Rivals | `200f` (candidate distance), `2f` (BB pad) |

---

## 8. Other observations

- `VehData.YawRotationPerSecondDegrees = 1f` default — should be `0f`; leaks fake yaw into first tick before `UpdateGrip` overwrites it.
- `VehData.SlideAngle = 22f` default — same issue; should be `0f`.
- `PID.Update` snap threshold (`error < 0.1 && velocity < 0.1`) is hidden; name it `const float SnapThreshold`.
- `Rival.Update` uses sentinel `909f` for no-contact; replace with `const float NoContact = float.PositiveInfinity`.
- `Brain.intention.MaxSpeed` starts at 0 and increases by `15 * TickScale` until it asymptotically approaches `AIData.MaxSpeed` (300mph). This is likely intentional as a "ramp up" from standstill but is subtle. Add a named method `RampMaxSpeedToward(AIData.MaxSpeed)`.
- Several `catch (Exception) {}` blocks silently hide blip/seat/radio failures in the `Racer` ctor. Keep the outer OnTick guard, make inner ones specific or logged.
- `Racer.cs:126-129` display name resolution is three nested try/catches. Extract `ResolveDisplayName(Vehicle)` helper.

---

## 9. Suggested order of operations

1. **Purge dead code** (section 3). Compile. Commit.
2. **Fix the bugs** (section 2: lookahead wrap, GridSort, sign truncation, wall init). Compile, test, commit.
3. **Remove all comments** (section 5). Compile. Commit.
4. **Delete empty stubs** (`SkillSet.cs`, `PersonalitySet.cs`). Compile. Commit.
5. **Rename pass — DataStructures.cs** (sections 4.3, 4.4). Compile. Commit.
6. **Rename pass — Racer.cs methods + fields**. Compile. Commit.
7. **Rename pass — AutosportRacingSystem.cs methods + statics**. Compile. Commit.
8. **Extract files** (section 1.1) — mechanical move, no behavior change. Compile per file. Commit.
9. **Extract methods** inside `OnTick`, `GenerateRouteInfo`, `SpeedTrack`, `SteerTrack`, `Racer` ctor (section 6). Compile, test, commit.
10. **Magic-number → Tuning constants** (section 7). Compile, test, commit.
11. Final review for residual comments or stale names.

Each step compiles and commits independently, so the mod stays playable at all times.
